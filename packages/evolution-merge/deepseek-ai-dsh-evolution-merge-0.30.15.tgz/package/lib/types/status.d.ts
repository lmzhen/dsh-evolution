/**
 * Read-only status projections for the merge command/panel. Pure formatting over rows; no
 * writes, no report reads. The UI and command parser share this vocabulary.
 */
import type { MergeQueue, MergeRow } from './contracts.ts';
export interface MergeCounts {
    readonly verify: number;
    readonly pending: number;
    readonly fuse: number;
    readonly skipped: number;
}
export declare function countRows(rows: readonly MergeRow[]): MergeCounts;
export declare function formatStatus(rows: readonly MergeRow[]): string;
export declare function formatQueue(rows: readonly MergeRow[], queue: MergeQueue): string;
//# sourceMappingURL=status.d.ts.map