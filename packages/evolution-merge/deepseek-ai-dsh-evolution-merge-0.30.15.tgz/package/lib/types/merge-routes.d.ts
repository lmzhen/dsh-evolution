/**
 * Four read-only merge routes: view / rows / run / runs. The host loads rows and runs; these
 * handlers only project. A missing merge service answers 503 instead of pretending empty.
 */
import type { RunRecord } from '@deepseek-ai/dsh-evolution-core';
import { type ConnectionFetchRouteLike, type DecisionAudit } from '@deepseek-ai/dsh-evolution-core/http-routes';
import type { MergeRow } from './contracts.ts';
export declare const MERGE_ROUTES: {
    view: `/api/dsh-evolution/${string}`;
    rows: `/api/dsh-evolution/${string}`;
    body: `/api/dsh-evolution/${string}`;
    history: `/api/dsh-evolution/${string}`;
};
export interface MergeHistoryItem {
    readonly name: string;
    readonly kind: 'merged' | 'deleted' | 'split' | 'other';
    readonly reason: string;
    readonly lastVersion: number;
    readonly archivedAt: string;
    readonly sourceRunId?: string;
}
export interface MergeRouteSource {
    rows(): Promise<readonly MergeRow[]>;
    run(id: string): Promise<RunRecord | undefined>;
    runs(cursor?: string, limit?: number): Promise<readonly RunRecord[]>;
    body(id: string, side: 'a' | 'b'): Promise<string | null>;
    history(): Promise<readonly MergeHistoryItem[]>;
    commands(): readonly string[];
    approval?(): boolean;
}
export declare function makeMergeRoutes(deps: {
    getSource: () => MergeRouteSource | undefined;
}, _audit: DecisionAudit): ConnectionFetchRouteLike[];
//# sourceMappingURL=merge-routes.d.ts.map