/**
 * Round2 with a NEW child (approval after the pending window). The child gets the round2
 * prompt and writes the staging tree; the plugin then runs the same gate/commit path.
 */
import type { EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
import type { MergeDecision, MergeRow } from './contracts.ts';
import type { SkillCard } from './skill-card.ts';
import type { ConversationChannelLike } from './channel-port.ts';
import { type CommitPort } from './commit-execute.ts';
import type { StageToolContext } from './stage-tool.ts';
import type { ScanRound2Outcome } from './scan-run.ts';
export interface NewChildAuthoringOptions {
    readonly io: EvolutionIoLike;
    readonly home: string;
    readonly runId: string;
    readonly cards: readonly SkillCard[];
    readonly channel: ConversationChannelLike;
    readonly parent: unknown;
    readonly allow: readonly string[];
    readonly cwd?: string;
    readonly timeoutMs: number;
    readonly commitPort: CommitPort;
    readonly now: () => number;
    readonly onChild?: (context: StageToolContext) => void;
    readonly onChildClosed?: (childId: string) => void;
}
export declare function runNewChildAuthoring(options: NewChildAuthoringOptions, row: MergeRow, decision: MergeDecision, signal: AbortSignal): Promise<ScanRound2Outcome>;
export declare function createNewChildRound2(options: Omit<NewChildAuthoringOptions, 'runId'>): (row: MergeRow, decision: MergeDecision, signal: AbortSignal, runId: string) => Promise<ScanRound2Outcome>;
//# sourceMappingURL=new-child-authoring.d.ts.map