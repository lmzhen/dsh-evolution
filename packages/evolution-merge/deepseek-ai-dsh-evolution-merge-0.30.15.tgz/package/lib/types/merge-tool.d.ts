/**
 * Model-facing merge_stage tool definition. The plugin shell supplies the context factory;
 * this module owns the argument schema and the JSON result. All policy remains in applyStageTool.
 */
import type { EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
import { type StageToolContext } from './stage-tool.ts';
export declare const MERGE_STAGE_TOOL_NAME = "merge_stage";
export interface ToolDefinitionLike {
    readonly name: string;
    readonly description: string;
    readonly parameters: Record<string, unknown>;
    readonly output: {
        readonly schema: Record<string, unknown>;
        readonly render: (args: unknown, value: string) => readonly {
            readonly type: 'text';
            readonly text: string;
        }[];
    };
    readonly execute: (args: Record<string, unknown>, exec: unknown) => Promise<string>;
}
export declare function createMergeStageTool(io: EvolutionIoLike, home: string, context: (exec: unknown) => StageToolContext | undefined): ToolDefinitionLike;
//# sourceMappingURL=merge-tool.d.ts.map