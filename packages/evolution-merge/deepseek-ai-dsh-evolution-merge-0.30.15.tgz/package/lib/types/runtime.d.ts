/**
 * The merge command runtime: cards -> screening -> channel ports -> scan/approve.
 * Plugin wiring supplies the channel, model and library; this module keeps the orchestration
 * out of apply() and makes the mutating verbs testable with fakes.
 */
import { type EvolutionIoLike, type SkillLibrary } from '@deepseek-ai/dsh-evolution-core';
import { type MergeCandidate } from './contracts.ts';
import type { MergeParams } from './params.ts';
import type { SkillCard } from './skill-card.ts';
import type { MergeRegistryPort } from './run-shell.ts';
import type { MergeCommandService } from './merge-command.ts';
import type { StageToolContext } from './stage-tool.ts';
import type { ConversationChannelLike } from './channel-port.ts';
export interface MergeStageBindingPort {
    bind(context: StageToolContext): void;
    unbind(childId: string): void;
}
export interface MergeRuntimeDeps {
    readonly io: EvolutionIoLike;
    readonly home: string;
    readonly registry: MergeRegistryPort;
    readonly skills: SkillLibrary;
    readonly now: () => number;
    readonly params: MergeParams;
    readonly platformWrite: boolean;
    readonly channel: ConversationChannelLike;
    readonly parent: unknown;
    readonly allow: readonly string[];
    readonly cwd?: string;
    readonly timeoutMinutes: number;
    /** Start scan/pair in the background and return the run id immediately. */
    readonly detached?: boolean;
    readonly cards: (signal: AbortSignal) => Promise<readonly SkillCard[]>;
    /** Run-scoped engine screening. */
    readonly screeningForRun: (cards: readonly SkillCard[], runId: string, signal: AbortSignal) => Promise<readonly MergeCandidate[]>;
    readonly stage?: MergeStageBindingPort;
}
export declare function createMergeRuntime(deps: MergeRuntimeDeps): MergeCommandService;
//# sourceMappingURL=runtime.d.ts.map