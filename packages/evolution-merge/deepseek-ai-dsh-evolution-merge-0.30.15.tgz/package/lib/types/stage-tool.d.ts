/**
 * The pure half of the model-facing merge_stage tool.
 *
 * Registration/session binding lives in the plugin shell; this function owns the rules a
 * caller cannot bypass: only the bound merge child, and only the author phase may write.
 */
import type { EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
import { type StageArea } from './staging-files.ts';
export type StagePhase = 'decide' | 'author';
export interface StageToolContext {
    readonly runId: string;
    readonly childId: string;
    readonly expectedChildId: string;
    readonly phase: StagePhase;
}
export type StageToolOp = {
    readonly op: 'list';
    readonly area: StageArea;
    readonly path?: string;
    readonly source?: string;
} | {
    readonly op: 'read';
    readonly area: StageArea;
    readonly path: string;
    readonly source?: string;
} | {
    readonly op: 'write';
    readonly path: string;
    readonly content: string;
} | {
    readonly op: 'copy';
    readonly source: string;
    readonly from: string;
    readonly to: string;
};
export type StageToolResult = {
    readonly ok: true;
    readonly value?: unknown;
} | {
    readonly ok: false;
    readonly code: 'not-merge-child' | 'phase' | 'not-found' | 'io' | 'bad-path';
    readonly message: string;
};
export declare function applyStageTool(io: EvolutionIoLike, home: string, ctx: StageToolContext, op: StageToolOp): Promise<StageToolResult>;
//# sourceMappingURL=stage-tool.d.ts.map