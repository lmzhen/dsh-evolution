/**
 * Turn a fully written staging tree into a CommitMergePlan.
 *
 * Source bodies come from the LIVE tree (the plan's CAS baseline), the target body from
 * the merged tree. This function is pure except for the injected reads; it never commits.
 */
import type { CommitMergePlan, WriteOrigin } from '@deepseek-ai/dsh-evolution-core';
import type { EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
export interface CommitAssemblyPort {
    /** Current SKILL.md body, or null when the skill is not live. */
    readSkill(name: string): Promise<string | null>;
    /** Whether the name is already occupied by an archived (tombstoned) skill. */
    isArchived?(name: string): Promise<boolean>;
}
export interface CommitAssemblyOptions {
    readonly origin: WriteOrigin;
    readonly summary: string;
}
export type CommitAssemblyResult = {
    readonly ok: true;
    readonly plan: CommitMergePlan;
} | {
    readonly ok: false;
    readonly message: string;
};
export declare function assembleStagedCommit(io: EvolutionIoLike, home: string, runId: string, port: CommitAssemblyPort, options: CommitAssemblyOptions): Promise<CommitAssemblyResult>;
//# sourceMappingURL=commit-assembly.d.ts.map