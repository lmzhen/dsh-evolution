/**
 * pair command: one explicit candidate through the same scan shell.
 */
import type { EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
import type { ScanPorts } from './scan-run.ts';
import type { MergeRegistryPort, WithMergeRunResult } from './run-shell.ts';
export interface RunPairCommandOptions {
    readonly io: EvolutionIoLike;
    readonly home: string;
    readonly registry: MergeRegistryPort;
    readonly ports: ScanPorts;
    readonly a: string;
    readonly b: string;
    readonly approval: boolean;
    readonly platformWrite: boolean;
    readonly timeoutMinutes?: number;
    readonly now: () => number;
}
export declare function runPairCommand(options: RunPairCommandOptions): Promise<WithMergeRunResult>;
//# sourceMappingURL=pair-command.d.ts.map