/**
 * Channel adapter for round 1. It opens the merged child, parses the decision, and exposes
 * an author callback for round 2 when the same child continues. Commit is deliberately
 * outside this adapter: the caller owns staging -> commitStagedRun.
 */
import type { MergeDecision, MergeRow } from './contracts.ts';
import type { SkillCard } from './skill-card.ts';
import type { ScanRound1Outcome } from './scan-run.ts';
export interface ChannelTurnLike {
    readonly text: string;
    readonly stopReason: string;
}
export type ChannelTurnOutcome = {
    readonly kind: 'ok';
    readonly childId: string;
    readonly turn: ChannelTurnLike;
} | {
    readonly kind: 'unavailable';
    readonly code: string;
    readonly reason: string;
} | {
    readonly kind: 'aborted';
};
export interface ConversationChannelLike {
    open(spec: {
        readonly parent: unknown;
        readonly label: string;
        readonly promptText: string;
        readonly kind: 'reviewer' | 'maintainer';
        readonly allow: readonly string[];
        readonly cwd?: string;
        readonly timeoutMs: number;
        readonly signal?: AbortSignal;
    }): Promise<ChannelTurnOutcome>;
    continueTurn(childId: string, promptText: string, options?: {
        readonly timeoutMs?: number;
        readonly signal?: AbortSignal;
    }): Promise<ChannelTurnOutcome>;
    dispose(childId: string): Promise<void>;
}
export interface ChannelRound1Options {
    readonly channel: ConversationChannelLike;
    readonly parent: unknown;
    readonly cards: readonly SkillCard[];
    readonly allow: readonly string[];
    readonly cwd?: string;
    readonly timeoutMs: number;
    readonly onChildOpened?: (childId: string) => void;
}
export interface ChannelRound1Result {
    readonly outcome: ScanRound1Outcome;
    readonly childId?: string;
    /** Same-child round 2; absent for keep/fail/unavailable. */
    readonly author?: (row: MergeRow, decision: MergeDecision, signal: AbortSignal) => Promise<string>;
    readonly dispose: () => Promise<void>;
}
export declare function runRound1OverChannel(options: ChannelRound1Options, candidate: {
    readonly a: string;
    readonly b: string;
}, signal: AbortSignal): Promise<ChannelRound1Result>;
//# sourceMappingURL=channel-port.d.ts.map