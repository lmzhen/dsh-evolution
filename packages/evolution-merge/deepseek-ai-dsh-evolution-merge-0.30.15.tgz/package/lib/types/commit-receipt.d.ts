import type { EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
export interface CommitReceipt {
    readonly runId: string;
    readonly parentRunId?: string;
    readonly unitId: string;
    readonly target: string;
    readonly create: boolean;
    readonly sources: readonly string[];
    readonly pairKey?: string;
    readonly archived: readonly string[];
    readonly at: number;
}
export declare function commitReceiptPath(home: string, runId: string): string;
export declare function durableReceiptDir(home: string, parentRunId: string): string;
export declare function durableReceiptPath(home: string, parentRunId: string, stageKey: string): string;
export declare function writeCommitReceipt(io: EvolutionIoLike, home: string, receipt: CommitReceipt): Promise<string>;
export declare function readCommitReceipts(io: EvolutionIoLike, home: string): Promise<readonly CommitReceipt[]>;
export declare function readCommitReceipt(io: EvolutionIoLike, home: string, runId: string, target?: string): Promise<CommitReceipt | null>;
//# sourceMappingURL=commit-receipt.d.ts.map