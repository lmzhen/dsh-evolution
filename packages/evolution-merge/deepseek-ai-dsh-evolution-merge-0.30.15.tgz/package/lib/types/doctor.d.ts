import { type EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
export declare const MERGE_DOCTOR_SCHEMA_VERSION = 3;
export interface MergeDoctorRow {
    readonly key: string;
    readonly label: string;
    readonly status: 'ok' | 'warn' | 'unknown';
    readonly detail: string;
}
export declare function mergeDoctor(io: EvolutionIoLike, home: string, configuredRoot?: string): Promise<readonly MergeDoctorRow[]>;
//# sourceMappingURL=doctor.d.ts.map