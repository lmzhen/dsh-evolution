/**
 * Round-1/round-2 prompt builders. B draft body, with only the file-tool ->
 * merge_stage substitution and the fresh-mode bridge sentence.
 */
import type { MergeDecision, MergeRow } from './contracts.ts';
import type { SkillCard } from './skill-card.ts';
export declare const MERGE_PROMPT_VERSION = "merge-b/v1";
export declare const STANDBY_PROMPT = "You are a merge worker. Wait for instructions.";
export declare function buildRound1Prompt(candidate: {
    readonly a: string;
    readonly b: string;
}, cards: readonly SkillCard[]): string;
export declare function buildRound2Prompt(row: MergeRow, decision: MergeDecision, mode?: 'continue' | 'fresh'): string;
export declare function buildStandbyPrompt(): string;
//# sourceMappingURL=prompts.d.ts.map