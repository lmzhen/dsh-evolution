import z from '@deepseek-ai/schemastery';
import type { Context } from '@deepseek-ai/cordis';
/** E3 knobs are volatile (user layer); the E2 pair timeout is deployment-only. */
export declare const Config: z<Schemastery.ObjectS<NoInfer<{
    mergeApproval: z<boolean, boolean, "volatile-defined">;
    mergeSkippedTtlDays: z<number, number, "volatile-defined">;
    mergeRunTimeoutMinutes: z<number, number, "volatile-defined">;
    mergePairTimeoutMinutes: z<number, number, "defined">;
    mergeModelsRoot: z<string, string, "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    mergeApproval: z<boolean, boolean, "volatile-defined">;
    mergeSkippedTtlDays: z<number, number, "volatile-defined">;
    mergeRunTimeoutMinutes: z<number, number, "volatile-defined">;
    mergePairTimeoutMinutes: z<number, number, "defined">;
    mergeModelsRoot: z<string, string, "defined">;
}>>, "plain">;
export interface MergePresentationScope {
    effect(run: () => () => void, label?: string): unknown;
    settings?: {
        configure?: (presentation: {
            auto?: boolean;
        }, owner?: unknown) => unknown;
    };
}
export declare function engineConfigFromEnv(configuredRoot?: string): Record<string, unknown> | undefined;
export interface MergePresentationContext {
    inject(names: string[], run: (scope: MergePresentationScope) => void): void;
    readonly fiber?: unknown;
}
/** Suppress the platform auto form; the registry renders the merge card instead. */
export declare function configureMergePresentation(ctx: MergePresentationContext): void;
export * from './contracts.ts';
export * from './skill-card.ts';
export * from './state.ts';
export * from './coordinator.ts';
export * from './report.ts';
export * from './staging.ts';
export * from './staging-files.ts';
export * from './rules.ts';
export * from './commit-plan.ts';
export * from './stage-tool.ts';
export * from './stage-tool-registry.ts';
export * from './staged-tree.ts';
export * from './commit-assembly.ts';
export * from './commit-receipt.ts';
export * from './commit-execute.ts';
export * from './undo-merge.ts';
export * from './adapters/library.ts';
export * from './adapters/model-runner.ts';
export * from './adapters/channel.ts';
export * from './adapters/engine-screen.ts';
export * from './adapters/undo.ts';
export * from './run-shell.ts';
export * from './scan-run.ts';
export * from './pending-actions.ts';
export * from './scan-command.ts';
export * from './round2-outcome.ts';
export * from './approve-command.ts';
export * from './pair-command.ts';
export * from './resume-command.ts';
export * from './decision.ts';
export * from './prompts.ts';
export * from './channel-port.ts';
export * from './authoring-flow.ts';
export * from './merge-tool.ts';
export * from './commands.ts';
export * from './scan-ports.ts';
export * from './new-child-authoring.ts';
export * from './status.ts';
export * from './skipped.ts';
export * from './read-commands.ts';
export * from './routes.ts';
export * from './merge-routes.ts';
export * from './merge-command.ts';
export * from './params.ts';
export * from './doctor.ts';
export * from './supersede.ts';
export * from './runtime.ts';
export declare const inject: string[];
export declare function apply(ctx: Context, rawConfig?: Record<string, unknown>): void;
//# sourceMappingURL=index.d.ts.map