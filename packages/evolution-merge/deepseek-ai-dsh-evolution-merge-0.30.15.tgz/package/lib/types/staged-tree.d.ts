import { type EvolutionIoLike, type Probe } from '@deepseek-ai/dsh-evolution-core';
import type { StagedTree } from './rules.ts';
export declare function readStagedTree(io: EvolutionIoLike, home: string, runId: string): Promise<Probe<StagedTree>>;
//# sourceMappingURL=staged-tree.d.ts.map