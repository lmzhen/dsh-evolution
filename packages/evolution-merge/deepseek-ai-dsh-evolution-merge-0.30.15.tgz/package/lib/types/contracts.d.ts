/**
 * Frozen merge-domain vocabulary. No io, no host, no imports from the plugin shell.
 *
 * The data layer keeps four states; the user face collapses verify/fuse into one retry
 * queue and keeps the stage as a chip. The API queue must never expose the raw state.
 */
export declare const MERGE_STATE_VERSION = 2;
export type MergePairState = 'verify' | 'pending' | 'approved' | 'fuse' | 'skipped';
export type MergeQueue = 'verify' | 'pending' | 'fuse' | 'skipped';
export type MergeStage = 'verify' | 'decide' | 'author' | 'commit';
export type MergeCommand = 'scan' | 'pair' | 'approve' | 'resume';
export declare const MERGE_PAIR_STATES: readonly MergePairState[];
export declare const MERGE_QUEUES: readonly MergeQueue[];
/** User-facing queue of one data state. verify/fuse share retry, not two tabs. */
export declare function queueOf(state: MergePairState): MergeQueue;
/** Coarse stage chip; skipped has no active stage. */
export declare function stageOf(state: MergePairState): MergeStage | null;
/** Stable pair identity; NUL cannot appear in a skill name. */
export declare function pairKey(a: string, b: string): string;
/** Deterministic, URL-safe id derived from the pair key (FNV-1a 32). */
export declare function rowIdOf(key: string): string;
export interface MergeFailure {
    readonly stage: 'screening' | 'decide' | 'author' | 'validate' | 'commit';
    readonly code: string;
    readonly message: string;
    readonly retryable: boolean;
    readonly retryFrom: 'agent1' | 'agent2' | 'none';
}
/** One persisted pair. The id is stable for the UI; the pairKey is the natural key. */
export interface MergeGateFact {
    readonly level: 'L0' | 'L1' | 'L2';
    readonly verdict: 1 | 0 | -1;
    readonly reason: string;
    readonly cached?: boolean;
    readonly auditOverride?: boolean;
}
export interface MergeCandidate {
    readonly a: string;
    readonly b: string;
    readonly score?: number;
    readonly arms?: readonly string[];
    readonly reason?: string;
    readonly gate?: MergeGateFact;
    readonly source?: 'lexical' | 'proposed' | 'engine';
}
export interface MergeDecision {
    readonly shouldMerge: boolean;
    readonly mode: 'merge-into-existing' | 'create-umbrella' | 'keep';
    readonly target: string;
    readonly sources: readonly string[];
    readonly rationale: string;
    readonly confidence?: number;
    readonly aSummary?: string;
    readonly bSummary?: string;
}
export interface MergeUsage {
    readonly inputTokens?: number;
    readonly outputTokens?: number;
    readonly totalTokens?: number;
    readonly costCny?: number;
}
export interface MergeTiming {
    readonly screeningMs?: number;
    readonly gateMs?: number;
    readonly agentMs?: number;
    readonly commitMs?: number;
}
export type MergeRunCommand = MergeCommand;
export interface MergeReportPair {
    readonly id: string;
    readonly pairKey: string;
    readonly a: string;
    readonly b: string;
    readonly queue: MergeQueue;
    readonly candidate?: MergeCandidate;
    readonly gate?: MergeGateFact;
    readonly decision?: MergeDecision;
    readonly outcome: 'merged' | 'kept' | 'pending' | 'failed' | 'cancelled';
    readonly target?: {
        readonly requested: string;
        readonly actual: string;
        readonly created: boolean;
    };
    readonly archived: readonly string[];
    readonly unitId?: string;
    readonly failure?: MergeFailure;
    readonly usage?: MergeUsage;
    readonly timing?: MergeTiming;
}
export interface MergeReport {
    readonly schemaVersion: 2;
    readonly runId: string;
    readonly kind: 'merge';
    readonly command: MergeRunCommand;
    readonly startedAt: number;
    readonly endedAt: number;
    readonly stopReason: 'completed' | 'failed' | 'cancelled' | 'timeout';
    readonly approval: {
        readonly platformWrite: boolean;
        readonly mergeApproval: boolean;
    };
    readonly scope: {
        readonly candidatePairs: number;
        readonly queueBefore: Record<MergeQueue, number>;
    };
    readonly pairs: readonly MergeReportPair[];
    readonly totals: Record<'merged' | 'kept' | 'pending' | 'failed', number>;
    readonly notes: readonly string[];
    readonly remaining?: readonly {
        readonly pairKey: string;
        readonly queue: MergeQueue;
    }[];
}
export interface MergeRow {
    readonly id: string;
    readonly pairKey: string;
    readonly a: string;
    readonly b: string;
    readonly state: MergePairState;
    readonly queue: MergeQueue;
    readonly expired?: 'target-taken' | 'source-changed';
    readonly reason?: string;
    readonly target?: {
        readonly requested: string;
        readonly actual?: string;
        readonly created?: boolean;
    };
    readonly failure?: MergeFailure;
    /** Round-1 decision, persisted for the later approve round. */
    readonly decision?: MergeDecision;
    readonly sourceRevision?: string;
    readonly targetRevision?: string;
    readonly runId?: string;
    readonly unitId?: string;
    readonly origin?: 'agent' | 'human' | 'system';
    readonly attempts?: number;
    readonly stagingRef?: string;
    readonly stagingExpiresAt?: number;
    readonly createdAt: string;
    readonly updatedAt: string;
}
export interface MergeState {
    readonly schemaVersion: typeof MERGE_STATE_VERSION;
    readonly rows: readonly MergeRow[];
}
export declare function emptyMergeState(): MergeState;
/** One record can be retried only when the failure says so and names a stage. */
export declare const MERGE_MAX_ATTEMPTS = 3;
export declare function canRetry(record: Pick<MergeRow, 'state' | 'failure' | 'attempts'>): boolean;
//# sourceMappingURL=contracts.d.ts.map