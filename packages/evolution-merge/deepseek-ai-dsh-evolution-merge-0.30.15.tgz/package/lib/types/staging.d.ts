import { type EvolutionIoLike, type Probe } from '@deepseek-ai/dsh-evolution-core';
export declare const STAGING_SCHEMA_VERSION = 1;
export declare function stageKeyOf(runId: string, pairKey: string): string;
export declare function stagingRoot(home: string, runId: string): string;
export interface StagingSource {
    readonly name: string;
    readonly body: string;
    readonly files: readonly {
        readonly path: string;
        readonly content: string;
    }[];
}
export interface StagingManifest {
    readonly schemaVersion: typeof STAGING_SCHEMA_VERSION;
    readonly runId: string;
    readonly target: string;
    readonly mode?: 'merge-into-existing' | 'create-umbrella' | 'keep';
    readonly sources: readonly string[];
    readonly promptVersion: string;
    readonly createdAt: number;
    readonly expiresAt: number;
}
export interface CreateStagingInput {
    readonly runId: string;
    readonly target: string;
    readonly mode?: 'merge-into-existing' | 'create-umbrella' | 'keep';
    readonly sources: readonly StagingSource[];
    readonly promptVersion: string;
    readonly ttlDays: number;
    readonly now: () => number;
}
export type CreateStagingResult = {
    readonly ok: true;
    readonly path: string;
    readonly manifest: StagingManifest;
} | {
    readonly ok: false;
    readonly message: string;
};
export declare function createStaging(io: EvolutionIoLike, home: string, input: CreateStagingInput): Promise<CreateStagingResult>;
export interface StagedView {
    readonly path: string;
    readonly manifest: StagingManifest;
}
export declare function readStaging(io: EvolutionIoLike, home: string, runId: string): Promise<Probe<StagedView>>;
export declare function ensureStaging(io: EvolutionIoLike, home: string, input: CreateStagingInput): Promise<CreateStagingResult>;
export declare function setStagingTarget(io: EvolutionIoLike, home: string, stageKey: string, target: string, mode?: 'merge-into-existing' | 'create-umbrella' | 'keep'): Promise<boolean>;
export declare function dropStaging(io: EvolutionIoLike, home: string, stageKey: string): Promise<void>;
export interface StagingCleanupResult {
    readonly removed: readonly string[];
    readonly kept: readonly string[];
    readonly unknown: readonly string[];
}
/** Remove expired run-level staging trees; `keep` names runs a live row still points at. */
export declare function cleanupExpiredStaging(io: EvolutionIoLike, home: string, now: number, keep?: ReadonlySet<string>): Promise<StagingCleanupResult>;
//# sourceMappingURL=staging.d.ts.map