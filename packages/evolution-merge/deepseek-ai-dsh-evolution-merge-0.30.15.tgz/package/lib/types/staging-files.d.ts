import { type EvolutionIoLike, type Probe } from '@deepseek-ai/dsh-evolution-core';
export type StageArea = 'sources' | 'merged';
export type StageWriteResult = {
    readonly ok: true;
    readonly path: string;
} | {
    readonly ok: false;
    readonly message: string;
};
export declare function writeStagedFile(io: EvolutionIoLike, home: string, runId: string, path: string, content: string, source?: string): Promise<StageWriteResult>;
export declare function readStagedFile(io: EvolutionIoLike, home: string, runId: string, path: string, area: StageArea, source?: string): Promise<Probe<string>>;
export declare function listStagedFiles(io: EvolutionIoLike, home: string, runId: string, area: StageArea, path?: string, source?: string): Promise<Probe<readonly string[]>>;
/** Copy one source file into the merged target; the only cross-area operation allowed. */
export declare function copyStagedFile(io: EvolutionIoLike, home: string, runId: string, source: string, from: string, to: string): Promise<StageWriteResult>;
//# sourceMappingURL=staging-files.d.ts.map