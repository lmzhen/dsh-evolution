/**
 * Read-only view models for the four merge routes. Pure functions; the host loads rows and
 * runs, the client renders these shapes. No io, no write paths.
 */
import type { RunRecord } from '@deepseek-ai/dsh-evolution-core';
import type { MergeQueue, MergeRow } from './contracts.ts';
import { type MergeCounts } from './status.ts';
export interface MergeRowView {
    readonly id: string;
    readonly pairKey: string;
    readonly a: string;
    readonly b: string;
    readonly state: MergeRow['state'];
    readonly queue: MergeQueue;
    readonly stage: string | null;
    readonly label: string;
    readonly updatedAt: string;
    readonly createdAt: string;
    readonly target?: string;
    readonly confidence?: number;
    readonly failure?: {
        readonly stage: string;
        readonly code: string;
        readonly message: string;
        readonly retryable: boolean;
    };
    readonly attempts?: number;
    readonly origin?: 'agent' | 'human' | 'system';
    readonly stagingExpiresAt?: number;
    readonly expired?: 'target-taken' | 'source-changed';
    readonly reason?: string;
    readonly summary?: readonly string[];
    readonly actions: readonly string[];
}
export declare function toRowView(row: MergeRow): MergeRowView;
export interface MergeView {
    readonly schemaVersion: 2;
    readonly counts: MergeCounts;
    readonly tabs: readonly {
        readonly queue: MergeQueue;
        readonly count: number;
    }[];
    readonly commands: readonly string[];
    readonly latestRun?: MergeRunFact;
    readonly approval?: boolean;
}
export declare function buildMergeView(rows: readonly MergeRow[], commands: readonly string[], latestRun?: MergeRunFact, approval?: boolean): MergeView;
export interface QueuePage {
    readonly queue: MergeQueue;
    readonly items: readonly MergeRowView[];
    readonly nextCursor?: string;
}
export declare function pageQueue(rows: readonly MergeRow[], queue: MergeQueue, cursor?: number, limit?: number): QueuePage;
export interface MergeRunFact {
    readonly id: string;
    readonly state: RunRecord['state'];
    readonly command?: RunRecord['command'];
    readonly stage?: RunRecord['stage'];
    readonly progress?: RunRecord['progress'];
    readonly startedAt: number;
    readonly endedAt?: number;
    readonly resultRef?: string;
    readonly failure?: string;
    readonly supersededAt?: number;
}
export declare function toRunFact(run: RunRecord): MergeRunFact;
//# sourceMappingURL=routes.d.ts.map