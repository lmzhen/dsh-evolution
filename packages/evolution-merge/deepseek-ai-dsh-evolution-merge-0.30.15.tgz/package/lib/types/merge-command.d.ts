/**
 * Model/CLI-facing /merge command definition. The host shell registers it; this module owns
 * parsing, read-only verb dispatch and the uniform error/success envelope.
 */
import type { EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
import { type MergeCliCommand } from './commands.ts';
export interface MergeCommandResult {
    readonly ok: boolean;
    readonly text: string;
}
export interface MergeCommandContext {
    /** The invoking agent, when a command (not a route) initiated the run. */
    readonly parent?: unknown;
}
export interface MergeCommandService {
    execute(command: MergeCliCommand, context?: MergeCommandContext): Promise<MergeCommandResult>;
}
export interface CommandInvocationLike {
    readonly rawInput: string;
    readonly agent?: unknown;
}
export interface CommandResultLike {
    readonly kind: 'success' | 'error';
    readonly text: string;
}
export interface MergeCommandDefinitionLike {
    readonly name: string;
    readonly description: string;
    readonly input: {
        readonly hint: string;
    };
    readonly handler: (invocation: CommandInvocationLike) => Promise<CommandResultLike>;
}
export declare function createReadOnlyMergeService(io: EvolutionIoLike, home: string): MergeCommandService;
export declare function runMergeCommand(service: MergeCommandService, rawInput: string, invocation?: {
    readonly agent?: unknown;
}): Promise<MergeCommandResult>;
export declare function createMergeCommand(service: MergeCommandService): MergeCommandDefinitionLike;
//# sourceMappingURL=merge-command.d.ts.map