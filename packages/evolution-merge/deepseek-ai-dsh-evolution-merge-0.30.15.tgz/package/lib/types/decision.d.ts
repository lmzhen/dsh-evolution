/**
 * Round-1 decision parser. The child returns text; the plugin owns strict shape checks.
 * Accepts a whole JSON object or a fenced json block; everything else is decision-invalid.
 */
import type { MergeDecision } from './contracts.ts';
export type DecisionParse = {
    readonly ok: true;
    readonly decision: MergeDecision;
} | {
    readonly ok: false;
    readonly code: 'decision-invalid';
    readonly message: string;
};
export declare function parseDecision(text: string | undefined, pair: {
    readonly a: string;
    readonly b: string;
}): DecisionParse;
//# sourceMappingURL=decision.d.ts.map