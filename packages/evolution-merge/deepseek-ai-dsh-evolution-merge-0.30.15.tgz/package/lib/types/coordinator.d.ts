/**
 * Pure merge transition table. No io, no run shell, no subagents.
 *
 * Every transition returns the whole next row (or a drop), so the caller can persist it
 * through mutateMergeState in one transaction. Invalid transitions are refused by name;
 * a caller never "repairs" a row by guessing which state the operator meant.
 */
import { type MergeDecision, type MergeFailure, type MergeRow } from './contracts.ts';
export type MergeEvent = {
    readonly type: 'candidate';
    readonly a: string;
    readonly b: string;
    readonly at: string;
} | {
    readonly type: 'round1-keep';
    readonly at: string;
} | {
    readonly type: 'round1-merge';
    readonly approval: 'on' | 'off';
    readonly decision?: MergeDecision;
    readonly stagingRef?: string;
    readonly stagingExpiresAt?: number;
    readonly at: string;
} | {
    readonly type: 'round1-fail';
    readonly failure: MergeFailure;
    readonly at: string;
} | {
    readonly type: 'approve';
    readonly runId?: string;
    readonly at: string;
} | {
    readonly type: 'reject';
    readonly at: string;
} | {
    readonly type: 'round2-fail';
    readonly failure: MergeFailure;
    readonly at: string;
} | {
    readonly type: 'round2-cancel';
    readonly at: string;
} | {
    readonly type: 'round2-success';
    readonly unitId?: string;
    readonly at: string;
} | {
    readonly type: 'restore';
    readonly at: string;
} | {
    readonly type: 'source-gone';
    readonly at: string;
} | {
    readonly type: 'gate-keep';
    readonly a: string;
    readonly b: string;
    readonly reason?: string;
    readonly at: string;
};
export type TransitionResult = {
    readonly ok: true;
    readonly row: MergeRow | null;
} | {
    readonly ok: false;
    readonly code: 'invalid-transition';
    readonly message: string;
};
export declare function transition(current: MergeRow | undefined, event: MergeEvent): TransitionResult;
//# sourceMappingURL=coordinator.d.ts.map