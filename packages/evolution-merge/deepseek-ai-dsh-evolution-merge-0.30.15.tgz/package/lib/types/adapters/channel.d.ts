/**
 * Adapt the platform SubagentChannel to the merge ConversationChannelLike. The optional
 * two-turn methods are checked at call time so an older channel degrades to E-323 instead
 * of throwing a TypeError.
 */
import type { ConversationChannelLike } from '../channel-port.ts';
interface PlatformTurn {
    readonly childId: unknown;
    readonly stopReason: string;
    readonly text: string;
}
type PlatformOutcome = {
    readonly kind: 'ok';
    readonly childId: unknown;
    readonly turn: PlatformTurn;
} | {
    readonly kind: 'unavailable';
    readonly code: string;
    readonly reason: string;
} | {
    readonly kind: 'aborted';
};
export interface SubagentChannelLike {
    open?(spec: {
        parent: unknown;
        label: string;
        promptText: string;
        kind: 'reviewer' | 'maintainer';
        allow: readonly string[];
        cwd?: string;
        timeoutMs: number;
        signal?: AbortSignal;
    }): Promise<PlatformOutcome>;
    continueTurn?(childId: string, promptText: string, options?: {
        timeoutMs?: number;
        signal?: AbortSignal;
    }): Promise<PlatformOutcome>;
    dispose?(childId: string): Promise<void>;
}
export declare function subagentChannelAdapter(channel: SubagentChannelLike): ConversationChannelLike;
export {};
//# sourceMappingURL=channel.d.ts.map