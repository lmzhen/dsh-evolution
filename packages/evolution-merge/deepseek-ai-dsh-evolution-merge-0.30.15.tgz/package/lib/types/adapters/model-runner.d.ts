/**
 * DeepSeek judge runner over the platform llm service. The engine calls
 * runner(prompt, cfg) and expects raw model text; the platform owns provider
 * selection, usage accounting and transport.
 */
export interface ModelRoute {
    readonly provider: string;
    readonly model: string;
}
export interface LlmChunkLike {
    readonly type: string;
    readonly text?: string;
    readonly reason?: {
        readonly kind?: string;
        readonly failure?: {
            readonly message?: string;
        };
    };
}
export interface LlmServiceLike {
    stream?(options: Record<string, unknown>): AsyncIterable<LlmChunkLike>;
    prepareCall?(config: Record<string, unknown>, signal?: AbortSignal): Promise<{
        readonly config: Record<string, unknown>;
        stream(input: Record<string, unknown>): AsyncIterable<LlmChunkLike>;
    }>;
}
export declare function createEngineRunner(llm: LlmServiceLike, route: () => ModelRoute): (prompt: string) => Promise<string>;
//# sourceMappingURL=model-runner.d.ts.map