import type { CandidateSelection } from './engine-screen.ts';
export declare function selectWithErrors(report: Record<string, unknown>): CandidateSelection;
//# sourceMappingURL=select.d.ts.map