/**
 * SkillLibrary-backed undo sink. Blobs are content-addressed but the library exposes them by
 * version, so the first readBlob call indexes all version bodies once; an undo is rare enough
 * that this is preferable to adding a second hash index.
 */
import { type SkillLibrary } from '@deepseek-ai/dsh-evolution-core';
import type { MergeUndoPort } from '../undo-merge.ts';
export declare function skillLibraryUndoPort(skills: SkillLibrary): MergeUndoPort;
//# sourceMappingURL=undo.d.ts.map