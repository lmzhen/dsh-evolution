import type { EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
import type { MergeCandidate } from '../contracts.ts';
import type { SkillCard } from '../skill-card.ts';
export type EngineScreenResult = {
    readonly ok: true;
    readonly report: Record<string, unknown>;
} | {
    readonly ok: false;
    readonly error: {
        readonly code: string;
        readonly stage?: string;
        readonly detail?: string;
    };
};
export interface EngineScreenPort {
    screen(input: {
        readonly corpusDir: string;
        readonly outDir: string;
        readonly cfg?: Record<string, unknown>;
        readonly signal?: AbortSignal;
        readonly onProgress?: (p: {
            stage: string;
            done?: number;
            total?: number;
        }) => void;
        readonly runner?: (prompt: string, cfg?: Record<string, unknown>) => Promise<string>;
    }): Promise<EngineScreenResult>;
}
export interface CandidateSelection {
    readonly candidates: readonly MergeCandidate[];
    readonly skipped: readonly {
        readonly pairKey: string;
        readonly a: string;
        readonly b: string;
        readonly reason?: string;
    }[];
    readonly reportOnly: readonly unknown[];
    readonly candidatePairs?: number;
}
export type ScreeningCandidates = readonly MergeCandidate[] & {
    readonly candidatePairs?: number;
};
export interface EngineScreeningDeps {
    readonly io: EvolutionIoLike;
    readonly home: string;
    readonly engine: EngineScreenPort;
    readonly select: (report: Record<string, unknown>) => CandidateSelection;
    readonly cfg?: Record<string, unknown>;
    readonly runner?: (prompt: string, cfg?: Record<string, unknown>) => Promise<string>;
    readonly onSelection?: (selection: CandidateSelection, runId: string) => Promise<void>;
}
/** Write the exact card bodies as a support-free corpus snapshot and return its root. */
export declare function snapshotCards(io: EvolutionIoLike, home: string, runId: string, cards: readonly SkillCard[]): Promise<string>;
export declare function createEngineScreening(deps: EngineScreeningDeps): (cards: readonly SkillCard[], runId: string, signal: AbortSignal) => Promise<readonly MergeCandidate[]>;
//# sourceMappingURL=engine-screen.d.ts.map