import type { EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
import { type MergePairState, type MergeQueue, type MergeRow, type MergeState } from './contracts.ts';
export declare function mergeStatePath(home: string): string;
export interface LoadMergeStateResult {
    readonly ok: boolean;
    readonly state: MergeState;
    readonly note?: string;
}
/** Pure read: never writes, never deletes a row. */
export declare function loadMergeState(io: EvolutionIoLike, home: string): Promise<LoadMergeStateResult>;
/** The ONE write point. The callback returns the whole row set, not a delta. */
export declare function mutateMergeState<T>(io: EvolutionIoLike, home: string, now: () => number, fn: (rows: readonly MergeRow[]) => {
    rows: readonly MergeRow[];
    result: T;
}): Promise<T>;
export interface MoveRowPatch {
    readonly queue: MergeQueue;
    readonly state?: MergePairState;
    readonly failure?: MergeRow['failure'];
    readonly runId?: string;
    readonly unitId?: string;
    readonly origin?: MergeRow['origin'];
    readonly attempts?: number;
}
export declare function upsertRow(io: EvolutionIoLike, home: string, now: () => number, row: MergeRow): Promise<void>;
export declare function moveRow(io: EvolutionIoLike, home: string, now: () => number, id: string, patch: MoveRowPatch): Promise<MergeRow | undefined>;
export declare function dropRow(io: EvolutionIoLike, home: string, now: () => number, id: string): Promise<boolean>;
export declare function rowsOf(io: EvolutionIoLike, home: string, queue?: MergeQueue): Promise<readonly MergeRow[]>;
//# sourceMappingURL=state.d.ts.map