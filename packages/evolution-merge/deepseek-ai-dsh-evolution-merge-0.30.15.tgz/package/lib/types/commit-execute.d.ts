/**
 * Execute one staged merge: assemble the plan, call the host commit port, then write the
 * receipt. A failed commit returns without a receipt; a landed commit with a failed receipt
 * stays successful and carries a warning.
 */
import type { CommitMergePlan, CommitMergeResult, EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
import { type CommitAssemblyPort } from './commit-assembly.ts';
import { type CommitReceipt } from './commit-receipt.ts';
export interface CommitPort extends CommitAssemblyPort {
    commitMerge(plan: CommitMergePlan): Promise<CommitMergeResult>;
}
export interface CommitStagedOptions {
    readonly origin: CommitMergePlan['origin'];
    readonly summary: string;
    readonly now: () => number;
}
export type CommitStagedResult = {
    readonly ok: true;
    readonly plan: CommitMergePlan;
    readonly result: CommitMergeResult;
    readonly receipt?: CommitReceipt;
    readonly warning?: string;
} | {
    readonly ok: false;
    readonly message: string;
    readonly plan?: CommitMergePlan;
};
export declare function commitStagedRun(io: EvolutionIoLike, home: string, runId: string, port: CommitPort, options: CommitStagedOptions): Promise<CommitStagedResult>;
//# sourceMappingURL=commit-execute.d.ts.map