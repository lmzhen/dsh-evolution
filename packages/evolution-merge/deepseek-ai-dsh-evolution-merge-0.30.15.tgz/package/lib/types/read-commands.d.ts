/**
 * Read-only command handlers: status/pending/skipped are served from merge-state.
 * Mutating verbs return null so the host shell can route them to the run engine.
 */
import type { EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
import type { MergeCliCommand } from './commands.ts';
export declare function handleReadOnlyMergeCommand(command: MergeCliCommand, io: EvolutionIoLike, home: string): Promise<string | null>;
export declare function mergeCommandHelp(): string;
//# sourceMappingURL=read-commands.d.ts.map