/**
 * Merge run shell: registry lifecycle + report-before-settle.
 *
 * The pair executor is injected. This module owns the invariants every command shares:
 * begin a merge run, publish stage/progress, write the report, then settle with resultRef.
 * A body failure still produces a failed report (unless the report itself cannot be written).
 */
import type { EvolutionIoLike, RunHandle, RunKind, RunStage } from '@deepseek-ai/dsh-evolution-core';
import type { MergeReport, MergeReportPair, MergeRunCommand } from './contracts.ts';
export interface MergeRegistryPort {
    begin(kind: RunKind, seed?: {
        command?: MergeRunCommand;
        total?: number;
        parentRunId?: string;
        mergeStatus?: 'running' | 'succeeded' | 'failed' | 'cancelled' | 'awaiting-approval' | 'undone' | 'superseded' | 'interrupted' | 'orphan';
    }): Promise<Pick<RunHandle, 'id' | 'signal' | 'startedAt'>>;
    stage(id: string, stage: RunStage, progress?: {
        done: number;
        total: number;
    }): Promise<void>;
    settle(id: string, outcome: {
        state: 'succeeded' | 'failed' | 'cancelled';
        resultRef?: string;
        failure?: string;
        mergeStatus?: 'running' | 'succeeded' | 'failed' | 'cancelled' | 'awaiting-approval' | 'undone' | 'superseded' | 'interrupted' | 'orphan';
    }): Promise<void>;
}
export interface MergeRunBodyContext {
    readonly runId: string;
    readonly startedAt: number;
    readonly signal: AbortSignal;
    readonly stage: (stage: RunStage, progress?: {
        done: number;
        total: number;
    }) => Promise<void>;
}
export interface MergeRunReportDraft {
    readonly stopReason: MergeReport['stopReason'];
    readonly scope: MergeReport['scope'];
    readonly pairs: readonly MergeReportPair[];
    readonly totals: MergeReport['totals'];
    readonly notes: readonly string[];
    readonly remaining?: MergeReport['remaining'];
}
export interface WithMergeRunOptions {
    readonly io: EvolutionIoLike;
    readonly home: string;
    readonly registry: MergeRegistryPort;
    readonly command: MergeRunCommand;
    readonly approval: MergeReport['approval'];
    readonly now: () => number;
    readonly total?: number;
    readonly detached?: boolean;
    readonly body: (ctx: MergeRunBodyContext) => Promise<MergeRunReportDraft>;
}
export type WithMergeRunResult = {
    readonly ok: true;
    readonly runId: string;
    readonly reportPath: string;
    readonly report: MergeReport;
} | {
    readonly ok: true;
    readonly accepted: true;
    readonly runId: string;
} | {
    readonly ok: false;
    readonly runId?: string;
    readonly message: string;
    readonly reportPath?: string;
};
export declare function withMergeRun(options: WithMergeRunOptions): Promise<WithMergeRunResult>;
//# sourceMappingURL=run-shell.d.ts.map