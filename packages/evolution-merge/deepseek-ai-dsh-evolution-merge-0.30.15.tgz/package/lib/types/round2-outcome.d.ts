/**
 * Shared round2 outcome recorder for approve and resume: one place decides whether the
 * row is dropped (commit landed) or kept in fuse with a failure. No report/registry logic.
 */
import type { EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
import type { MergeReportPair, MergeRow } from './contracts.ts';
import type { ScanRound2Outcome } from './scan-run.ts';
export interface Round2Record {
    readonly pair: MergeReportPair;
    readonly merged: boolean;
}
export declare function recordRound2Outcome(io: EvolutionIoLike, home: string, now: () => number, row: MergeRow, outcome: ScanRound2Outcome): Promise<Round2Record>;
//# sourceMappingURL=round2-outcome.d.ts.map