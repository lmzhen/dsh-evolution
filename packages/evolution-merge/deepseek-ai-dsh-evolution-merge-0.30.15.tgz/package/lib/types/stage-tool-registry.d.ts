/**
 * Child-scoped stage-tool bindings. A round child is bound only for the window in which its
 * staging writes are legal; the tool resolves the caller from the platform exec and refuses
 * when no binding exists.
 */
import type { StageToolContext } from './stage-tool.ts';
export declare class StageToolRegistry {
    private readonly bindings;
    bind(childId: string, context: StageToolContext): void;
    unbind(childId: string): void;
    clear(): void;
    resolve(exec: unknown): StageToolContext | undefined;
}
//# sourceMappingURL=stage-tool-registry.d.ts.map