/**
 * approve command: one pending row is atomically taken to fuse, then a new run executes
 * round2 with the persisted decision. A second approve loses at approvePending (not-pending).
 */
import type { EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
import type { MergeDecision, MergeRow } from './contracts.ts';
import type { MergeRegistryPort, WithMergeRunResult } from './run-shell.ts';
import type { ScanRound2Outcome } from './scan-run.ts';
export interface ApprovePorts {
    round2(row: MergeRow, decision: MergeDecision, signal: AbortSignal, runId: string): Promise<ScanRound2Outcome>;
}
export interface RunApproveCommandOptions {
    readonly io: EvolutionIoLike;
    readonly home: string;
    readonly registry: MergeRegistryPort;
    readonly ports: ApprovePorts;
    readonly rowId: string;
    readonly platformWrite: boolean;
    readonly now: () => number;
}
export declare function runApproveCommand(options: RunApproveCommandOptions): Promise<WithMergeRunResult>;
//# sourceMappingURL=approve-command.d.ts.map