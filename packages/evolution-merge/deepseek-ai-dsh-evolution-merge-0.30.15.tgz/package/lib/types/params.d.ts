/**
 * Merge parameter resolution. E2/E3 values arrive as one JSON object; this is the only
 * validator. Invalid values throw loudly (no silent clamp), matching the screening contract.
 */
export interface MergeParams {
    readonly mergeApproval: boolean;
    readonly mergeSkippedTtlDays: number;
    readonly mergeRunTimeoutMinutes: number;
    readonly mergePairTimeoutMinutes: number;
    readonly mergeModelsRoot: string;
}
export declare const MERGE_PARAM_DEFAULTS: MergeParams;
export declare function resolveMergeParams(input?: unknown): MergeParams;
//# sourceMappingURL=params.d.ts.map