/**
 * A tree restore invalidates earlier merge runs: their commit receipts may describe a tree
 * that no longer exists. Mark every non-superseded merge run in this process's registry.
 */
import type { RunRecord, RunRegistry } from '@deepseek-ai/dsh-evolution-core';
export declare function mergeRunIdsToSupersede(runs: readonly RunRecord[]): readonly string[];
export declare function supersedeMergeRuns(registry: RunRegistry): Promise<number>;
//# sourceMappingURL=supersede.d.ts.map