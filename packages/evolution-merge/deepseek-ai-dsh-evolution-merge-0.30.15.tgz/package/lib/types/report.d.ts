import { type EvolutionIoLike, type Probe } from '@deepseek-ai/dsh-evolution-core';
import type { MergeReport, MergeReportPair } from './contracts.ts';
export declare function mergeReportPath(home: string, runId: string): string;
export declare function mergeReportDigestPath(home: string, runId: string): string;
/** Write JSON first, then the digest; returns the JSON path (the registry resultRef). */
export declare function writeMergeReport(io: EvolutionIoLike, home: string, report: MergeReport): Promise<string>;
export declare function readMergeReport(io: EvolutionIoLike, home: string, runId: string): Promise<Probe<MergeReport>>;
/** Pairs this run actually merged (for merge undo / reports). */
export declare function committedPairs(io: EvolutionIoLike, home: string, runId: string): Promise<readonly MergeReportPair[]>;
//# sourceMappingURL=report.d.ts.map