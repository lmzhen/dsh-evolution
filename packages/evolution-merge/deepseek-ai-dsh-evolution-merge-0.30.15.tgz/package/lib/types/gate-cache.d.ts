import { type EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
import { GateCache } from './ladder.ts';
export declare const GATE_CACHE_VERSION = 1;
export declare function gateCachePath(home: string): string;
export interface LoadGateCacheResult {
    readonly cache: GateCache;
    readonly note?: string;
}
export declare function loadGateCache(io: EvolutionIoLike, home: string): Promise<LoadGateCacheResult>;
export declare function saveGateCache(io: EvolutionIoLike, home: string, cache: GateCache): Promise<void>;
export declare function hasGateCache(cache: GateCache): boolean;
//# sourceMappingURL=gate-cache.d.ts.map