/**
 * Compose the channel and authoring flow into ScanPorts for a scan run.
 *
 * Approval off: round1 keeps the child, round2 authors the staging tree, then commits.
 * Approval on: round1 disposes the child immediately; the row waits in pending and the later
 * approve run must open a new child (not handled by this factory).
 */
import type { EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
import type { SkillCard } from './skill-card.ts';
import { type ConversationChannelLike } from './channel-port.ts';
import type { CommitPort } from './commit-execute.ts';
import type { StageToolContext } from './stage-tool.ts';
import type { ScanPorts } from './scan-run.ts';
export interface CreateScanPortsOptions {
    readonly io: EvolutionIoLike;
    readonly home: string;
    readonly runId: string;
    readonly cards: readonly SkillCard[];
    readonly screening: ScanPorts['screening'];
    readonly channel: ConversationChannelLike;
    readonly parent: unknown;
    readonly allow: readonly string[];
    readonly cwd?: string;
    readonly timeoutMs: number;
    readonly approval: boolean;
    readonly commitPort: CommitPort;
    readonly now: () => number;
    readonly onChild?: (context: StageToolContext) => void;
    readonly onChildClosed?: (childId: string) => void;
}
export declare function createChannelScanPorts(options: CreateScanPortsOptions): ScanPorts;
//# sourceMappingURL=scan-ports.d.ts.map