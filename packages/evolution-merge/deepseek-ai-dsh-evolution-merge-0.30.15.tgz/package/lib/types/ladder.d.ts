export type GateLevel = 'L0' | 'L1' | 'L2';
export type GateVerdictValue = 1 | 0 | -1;
export interface GateFacts {
    readonly name: string;
    readonly description: string;
    readonly body: string;
}
export interface GateCandidate {
    readonly a: string;
    readonly b: string;
    readonly score?: number;
}
export interface GateEvidence {
    readonly path: string;
    readonly line: number;
    readonly quote: string;
}
export interface GateVerdict {
    readonly level: GateLevel;
    readonly verdict: GateVerdictValue;
    readonly reason: string;
    readonly evidence: readonly GateEvidence[];
    readonly cached: boolean;
}
export interface GateModelPort {
    callJson(request: {
        readonly system: string;
        readonly user: string;
        readonly maxTokens: number;
        readonly signal: AbortSignal;
    }): Promise<unknown>;
}
export type LadderRoute = 'merge' | 'undecided' | 'keep' | 'error';
export interface LadderResult {
    readonly route: LadderRoute;
    readonly verdicts: readonly GateVerdict[];
    readonly calls: number;
    readonly droppedAt?: GateLevel;
    readonly error?: string;
}
export declare class GateCache {
    private readonly entries;
    get(key: string): GateVerdict | undefined;
    put(key: string, value: GateVerdict): void;
    get size(): number;
    toObject(): Record<string, GateVerdict>;
    static fromObject(value: unknown): GateCache;
}
export declare function gateCacheKey(level: GateLevel, payload: string, model: string): string;
export declare function parseVerdict(level: GateLevel, raw: unknown, cached?: boolean): GateVerdict | undefined;
export interface RunLadderOptions {
    readonly level: GateLevel;
    readonly candidate: GateCandidate;
    readonly facts: readonly GateFacts[];
    readonly model: GateModelPort;
    readonly modelName: string;
    readonly signal: AbortSignal;
    readonly cache?: GateCache;
    /** Audit path starts at L2 after an L0 keep. */
    readonly startLevel?: GateLevel;
}
/** Deterministic 10% L0 audit selection from the run seed + pair key. */
export declare function selectedForAudit(pairKey: string, seed: string, rate?: number): boolean;
export declare function runLadder(options: RunLadderOptions): Promise<LadderResult>;
//# sourceMappingURL=ladder.d.ts.map