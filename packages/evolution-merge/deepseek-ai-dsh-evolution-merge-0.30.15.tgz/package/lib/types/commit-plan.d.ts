/**
 * Pure commit-plan assembly for a staged merge tree.
 *
 * The control plane has already chosen the target name and the child wrote merged/<target>/.
 * This module only turns those bytes into a CommitMergePlan; it never reads the live tree and
 * never decides whether a merge is allowed (validateStagedTree does that).
 */
import type { CommitMergePlan, WriteOrigin } from '@deepseek-ai/dsh-evolution-core';
export type ResolveTargetResult = {
    readonly ok: true;
    readonly name: string;
    readonly suffix: number;
} | {
    readonly ok: false;
    readonly message: string;
};
/** Pick the first free target: requested, then -v2, -v3, ... (never truncate a name). */
export declare function resolveTargetName(requested: string, exists: (name: string) => boolean): ResolveTargetResult;
/** Rewrite only the frontmatter name; body bytes stay otherwise intact. */
export declare function rewriteFrontmatterName(body: string, name: string): string;
export interface BuildCommitPlanInput {
    readonly target: string;
    readonly create: boolean;
    readonly mergedBody: string;
    readonly mergedFiles: readonly {
        readonly path: string;
        readonly content: string;
    }[];
    readonly targetCurrent: string | null;
    readonly sourceBodies: readonly {
        readonly name: string;
        readonly body: string;
    }[];
    readonly origin: WriteOrigin;
    readonly summary: string;
}
export type BuildCommitPlanResult = {
    readonly ok: true;
    readonly plan: CommitMergePlan;
} | {
    readonly ok: false;
    readonly message: string;
};
export declare function buildCommitPlan(input: BuildCommitPlanInput): BuildCommitPlanResult;
//# sourceMappingURL=commit-plan.d.ts.map