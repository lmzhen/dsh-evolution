/**
 * Authoring flow: create the staging tree, let the author write it, run the deterministic
 * rule gate, then commit through the injected CommitPort. The channel adapter and the
 * author tool live outside; this is the seam they share.
 */
import type { EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
import { type RuleFinding } from './rules.ts';
import { type CommitPort, type CommitStagedResult } from './commit-execute.ts';
import type { StagedTree } from './rules.ts';
import type { SkillCard } from './skill-card.ts';
export interface RunAuthoringOptions {
    readonly io: EvolutionIoLike;
    readonly home: string;
    readonly runId: string;
    readonly stageKey?: string;
    readonly reuseStaging?: boolean;
    readonly target: string;
    readonly mode?: 'merge-into-existing' | 'create-umbrella' | 'keep';
    readonly cards: readonly SkillCard[];
    readonly author: (staging: {
        readonly home: string;
        readonly runId: string;
    }) => Promise<string>;
    readonly commitPort: CommitPort;
    readonly now: () => number;
    readonly summary: string;
}
export type AuthoringResult = {
    readonly ok: true;
    readonly tree: StagedTree;
    readonly commit: Extract<CommitStagedResult, {
        readonly ok: true;
    }>;
} | {
    readonly ok: false;
    readonly message: string;
    readonly findings?: readonly RuleFinding[];
};
export declare function runAuthoring(options: RunAuthoringOptions): Promise<AuthoringResult>;
//# sourceMappingURL=authoring-flow.d.ts.map