/**
 * The scan pair loop. Registry/report lifecycle stays in withMergeRun; this module owns
 * candidate → round1 → pending/fuse → commit transitions and returns the report draft.
 */
import { type MergeCandidate, type MergeDecision, type MergeFailure, type MergeRow } from './contracts.ts';
import type { EvolutionIoLike, RunStage } from '@deepseek-ai/dsh-evolution-core';
import type { MergeRunReportDraft } from './run-shell.ts';
export interface ScanRound1Outcome {
    readonly kind: 'keep' | 'merge' | 'failed';
    readonly decision?: MergeDecision;
    readonly failure?: MergeFailure;
    readonly stagingRef?: string;
    readonly stagingExpiresAt?: number;
    readonly sourceRevision?: string;
    readonly targetRevision?: string;
}
export interface ScanRound2Outcome {
    readonly kind: 'merged' | 'failed';
    readonly unitId?: string;
    readonly archived?: readonly string[];
    readonly target?: {
        readonly requested: string;
        readonly actual: string;
        readonly created: boolean;
    };
    readonly failure?: MergeFailure;
}
export interface ScanPorts {
    screening(signal: AbortSignal): Promise<readonly MergeCandidate[]>;
    round1(candidate: MergeCandidate, signal: AbortSignal): Promise<ScanRound1Outcome>;
    round2(row: MergeRow, decision: MergeDecision, signal: AbortSignal): Promise<ScanRound2Outcome>;
}
export interface RunScanOptions {
    readonly io: EvolutionIoLike;
    readonly home: string;
    readonly now: () => number;
    readonly signal: AbortSignal;
    readonly approval: boolean;
    readonly timeoutMinutes?: number;
    readonly startedAt?: number;
    readonly ports: ScanPorts;
    readonly stage?: (stage: RunStage, progress?: {
        done: number;
        total: number;
    }) => Promise<void>;
}
export declare function runScan(options: RunScanOptions): Promise<MergeRunReportDraft>;
//# sourceMappingURL=scan-run.d.ts.map