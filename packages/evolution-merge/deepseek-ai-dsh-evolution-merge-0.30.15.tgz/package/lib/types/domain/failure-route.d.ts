/** Pure failure routing for merge errors. */
export type MergeFailureRoute = {
    readonly kind: 'parameter';
    readonly reportOnly: false;
} | {
    readonly kind: 'source-gone';
    readonly reportOnly: true;
} | {
    readonly kind: 'target-taken';
    readonly reportOnly: true;
} | {
    readonly kind: 'validation';
    readonly reportOnly: true;
} | {
    readonly kind: 'commit';
    readonly reportOnly: true;
} | {
    readonly kind: 'schema';
    readonly reportOnly: true;
} | {
    readonly kind: 'runtime';
    readonly reportOnly: true;
};
export declare function routeFailure(code: string): MergeFailureRoute;
//# sourceMappingURL=failure-route.d.ts.map