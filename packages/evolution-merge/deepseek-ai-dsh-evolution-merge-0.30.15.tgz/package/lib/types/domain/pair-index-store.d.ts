import type { EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
import type { PairIndexEntryV2 } from './indexes.ts';
export declare function pairIndexPath(home: string): string;
export declare function loadPairIndex(io: EvolutionIoLike, home: string): Promise<Map<string, PairIndexEntryV2>>;
export declare function recordPair(io: EvolutionIoLike, home: string, entry: PairIndexEntryV2): Promise<void>;
//# sourceMappingURL=pair-index-store.d.ts.map