import type { MergeRowV2 } from './row.ts';
import { type MergeQueue } from './state.ts';
export interface LedgerV2 {
    readonly schemaVersion: 2;
    readonly rows: readonly MergeRowV2[];
}
export interface LedgerParseResult {
    readonly ok: boolean;
    readonly ledger: LedgerV2;
    readonly note?: string;
}
export declare function parseLedger(raw: string | null): LedgerParseResult;
export declare function upsert(rows: readonly MergeRowV2[], row: MergeRowV2): readonly MergeRowV2[];
export declare function remove(rows: readonly MergeRowV2[], pairKey: string): readonly MergeRowV2[];
export declare function rowsOfQueue(rows: readonly MergeRowV2[], queue: MergeQueue): readonly MergeRowV2[];
export declare function activeCounts(rows: readonly MergeRowV2[]): Record<MergeQueue, number>;
//# sourceMappingURL=ledger.d.ts.map