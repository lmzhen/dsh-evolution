/** Pure pairKey lookup over run records. No IO. */
import type { PairIndexEntryV2 } from './indexes.ts';
import type { PairRecord } from './run-record.ts';
export interface PairRunLike {
    readonly id: string;
    readonly pairKey?: string;
    readonly pairs: readonly PairRecord[];
    readonly resultRef?: string;
}
export declare function findPairRun(runs: readonly PairRunLike[], pairKey: string): PairIndexEntryV2 | undefined;
//# sourceMappingURL=resolve-pair.d.ts.map