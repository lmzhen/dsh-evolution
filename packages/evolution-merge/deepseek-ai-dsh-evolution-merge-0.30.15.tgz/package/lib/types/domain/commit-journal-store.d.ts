import type { EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
import type { CommitJournal } from './commit-journal.ts';
export declare function journalPath(home: string, runId: string): string;
export declare function writeJournal(io: EvolutionIoLike, home: string, journal: CommitJournal): Promise<string>;
export declare function readJournal(io: EvolutionIoLike, home: string, runId: string): Promise<CommitJournal | null>;
//# sourceMappingURL=commit-journal-store.d.ts.map