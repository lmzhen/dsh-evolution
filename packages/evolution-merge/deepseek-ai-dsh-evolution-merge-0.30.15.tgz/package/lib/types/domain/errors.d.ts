/** Pure merge error rendering: parameter errors are two lines, runtime/target failures three. */
export type MergeErrorKind = 'parameter' | 'runtime' | 'target' | 'approval';
export interface MergeError {
    readonly kind: MergeErrorKind;
    readonly code: string;
    readonly message: string;
    readonly detail?: string;
}
export declare function formatMergeError(error: MergeError): string;
//# sourceMappingURL=errors.d.ts.map