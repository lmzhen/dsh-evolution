export declare function renderMarkdown(source: string): string;
//# sourceMappingURL=markdown.d.ts.map