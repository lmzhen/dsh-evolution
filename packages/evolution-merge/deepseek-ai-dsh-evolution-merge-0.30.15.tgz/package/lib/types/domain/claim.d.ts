/** Pure approve-claim lease. No IO. */
export interface Claim {
    readonly id: string;
    readonly token: string;
    readonly expiresAt: number;
}
export declare function acquireClaim(current: Claim | undefined, now: number, leaseMs: number, token: string): Claim | undefined;
export declare function releaseClaim(current: Claim | undefined, token: string): Claim | undefined;
export declare function isClaimExpired(current: Claim | undefined, now: number): boolean;
//# sourceMappingURL=claim.d.ts.map