import { type MergeState } from './state.ts';
import type { MergeDecision, MergeFailure } from '../contracts.ts';
export interface MergeRowV2 {
    readonly id: string;
    readonly pairKey: string;
    readonly a: string;
    readonly b: string;
    readonly state: MergeState;
    readonly queue: 'verify' | 'pending' | 'fuse' | 'skipped';
    readonly failure?: MergeFailure;
    readonly decision?: MergeDecision;
    readonly sourceRevision?: string;
    readonly targetRevision?: string;
    readonly runId?: string;
    readonly unitId?: string;
    readonly origin?: 'agent' | 'human' | 'system';
    readonly attempts?: number;
    readonly stagingRef?: string;
    readonly stagingExpiresAt?: number;
    readonly target?: {
        readonly requested: string;
        readonly actual?: string;
        readonly created?: boolean;
    };
    readonly reason?: string;
    readonly expired?: 'target-taken' | 'source-changed';
    readonly createdAt: string;
    readonly updatedAt: string;
}
export type MergeRowEvent = {
    readonly type: 'candidate';
    readonly a: string;
    readonly b: string;
    readonly at: string;
} | {
    readonly type: 'round1-start';
    readonly at: string;
} | {
    readonly type: 'round1-keep';
    readonly at: string;
} | {
    readonly type: 'round1-merge';
    readonly approval: 'on' | 'off';
    readonly decision?: MergeDecision;
    readonly stagingRef?: string;
    readonly stagingExpiresAt?: number;
    readonly at: string;
} | {
    readonly type: 'round1-fail';
    readonly failure: MergeFailure;
    readonly at: string;
} | {
    readonly type: 'approve';
    readonly runId?: string;
    readonly at: string;
} | {
    readonly type: 'reject';
    readonly at: string;
} | {
    readonly type: 'round2-start';
    readonly at: string;
} | {
    readonly type: 'round2-fail';
    readonly failure: MergeFailure;
    readonly at: string;
} | {
    readonly type: 'round2-success';
    readonly unitId?: string;
    readonly at: string;
} | {
    readonly type: 'restore';
    readonly at: string;
} | {
    readonly type: 'discard';
    readonly at: string;
} | {
    readonly type: 'source-gone';
    readonly at: string;
} | {
    readonly type: 'target-taken';
    readonly at: string;
} | {
    readonly type: 'source-changed';
    readonly at: string;
} | {
    readonly type: 'staging-expired';
    readonly at: string;
} | {
    readonly type: 'round2-cancel';
    readonly at: string;
} | {
    readonly type: 'timeout';
    readonly at: string;
} | {
    readonly type: 'cancel';
    readonly at: string;
} | {
    readonly type: 'gate-keep';
    readonly a: string;
    readonly b: string;
    readonly reason?: string;
    readonly at: string;
};
export type RowTransitionResult = {
    readonly ok: true;
    readonly row: MergeRowV2 | null;
} | {
    readonly ok: false;
    readonly code: 'invalid-transition';
    readonly message: string;
};
export declare function transitionRow(current: MergeRowV2 | undefined, event: MergeRowEvent): RowTransitionResult;
//# sourceMappingURL=row.d.ts.map