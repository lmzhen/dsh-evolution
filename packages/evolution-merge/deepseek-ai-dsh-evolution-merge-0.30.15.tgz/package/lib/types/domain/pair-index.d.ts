/** Pure pairKey index serialization. No IO. */
import type { PairIndexEntryV2 } from './indexes.ts';
export interface PairIndexFile {
    readonly schemaVersion: 1;
    readonly entries: readonly PairIndexEntryV2[];
}
export declare function parsePairIndex(raw: string | null): Map<string, PairIndexEntryV2>;
export declare function serializePairIndex(index: ReadonlyMap<string, PairIndexEntryV2>): string;
//# sourceMappingURL=pair-index.d.ts.map