/** Pure merge decision state machine. No IO, no host imports. */
export type MergeState = 'verify' | 'pending' | 'approved' | 'fuse' | 'skipped';
export type MergeQueue = 'verify' | 'pending' | 'fuse' | 'skipped';
export type MergeEvent = {
    readonly type: 'candidate';
} | {
    readonly type: 'round1-start';
} | {
    readonly type: 'round1-keep';
} | {
    readonly type: 'round1-merge';
    readonly approval: boolean;
} | {
    readonly type: 'round1-fail';
} | {
    readonly type: 'approve';
} | {
    readonly type: 'reject';
} | {
    readonly type: 'round2-start';
} | {
    readonly type: 'round2-fail';
} | {
    readonly type: 'round2-merged';
} | {
    readonly type: 'round2-cancel';
} | {
    readonly type: 'staging-expired';
} | {
    readonly type: 'source-gone';
} | {
    readonly type: 'target-taken';
} | {
    readonly type: 'source-changed';
} | {
    readonly type: 'cancel';
} | {
    readonly type: 'timeout';
};
export type TransitionResult = {
    readonly ok: true;
    readonly state: MergeState;
} | {
    readonly ok: true;
    readonly state: null;
    readonly removed: true;
} | {
    readonly ok: false;
    readonly code: 'invalid-transition';
    readonly message: string;
};
export declare function queueOf(state: MergeState): MergeQueue;
export declare function isTerminal(state: MergeState): boolean;
/** Single transition point; callers must not mutate fields outside this function. */
export declare function transition(state: MergeState, event: MergeEvent): TransitionResult;
export declare function allowedEvents(state: MergeState): readonly MergeEvent['type'][];
//# sourceMappingURL=state.d.ts.map