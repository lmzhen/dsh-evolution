/** Pure v1→v2 row migration. No IO. */
import type { MergeState } from './state.ts';
export interface LegacyMergeRow {
    readonly id: string;
    readonly pairKey: string;
    readonly a: string;
    readonly b: string;
    readonly state: 'verify' | 'pending' | 'fuse' | 'skipped';
    readonly queue?: 'pending' | 'retry' | 'skipped';
    readonly failure?: unknown;
    readonly decision?: unknown;
    readonly runId?: string;
    readonly unitId?: string;
    readonly origin?: 'agent' | 'human';
    readonly attempts?: number;
    readonly stagingRef?: string;
    readonly stagingExpiresAt?: number;
    readonly createdAt: string;
    readonly updatedAt: string;
}
export interface V2Row {
    readonly schemaVersion: 2;
    readonly id: string;
    readonly pairKey: string;
    readonly a: string;
    readonly b: string;
    readonly state: MergeState;
    readonly queue: 'verify' | 'pending' | 'fuse' | 'skipped';
    readonly failure?: unknown;
    readonly decision?: unknown;
    readonly runId?: string;
    readonly unitId?: string;
    readonly origin?: 'agent' | 'human';
    readonly attempts?: number;
    readonly stagingRef?: string;
    readonly stagingExpiresAt?: number;
    readonly createdAt: string;
    readonly updatedAt: string;
}
export declare function migrateV1Row(row: LegacyMergeRow): V2Row;
//# sourceMappingURL=migrate-v1.d.ts.map