/** Pure pairKey result index and archived-history projection. No IO. */
export interface PairIndexEntryV2 {
    readonly pairKey: string;
    readonly runId: string;
    readonly result: 'merged' | 'kept' | 'failed' | 'cancelled' | 'undone';
    readonly target?: string;
    readonly reportRef?: string;
}
export type HistoryKind = 'merged' | 'deleted' | 'split' | 'other';
export interface HistoryRecord {
    readonly name: string;
    readonly kind: HistoryKind;
    readonly reason: string;
    readonly lastVersion: number;
    readonly archivedAt: string;
    readonly sourceRunId?: string;
}
export declare function putPair(index: ReadonlyMap<string, PairIndexEntryV2>, entry: PairIndexEntryV2): Map<string, PairIndexEntryV2>;
export declare function historyRecord(input: HistoryRecord): HistoryRecord;
export declare function summarizeHistory(records: readonly HistoryRecord[]): Record<HistoryKind, number>;
//# sourceMappingURL=indexes.d.ts.map