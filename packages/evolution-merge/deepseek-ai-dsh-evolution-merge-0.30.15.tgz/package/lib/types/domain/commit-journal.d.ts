/** Pure commit-journal phases for target-first merge. */
export type JournalPhase = 'prepared' | 'target-written' | 'sources-archived' | 'committed' | 'rolled-back' | 'failed';
export interface CommitJournal {
    readonly runId: string;
    readonly unitId?: string;
    readonly target: string;
    readonly create: boolean;
    readonly sources: readonly string[];
    readonly phase: JournalPhase;
    readonly updatedAt: string;
}
export declare function advanceJournal(journal: CommitJournal, phase: JournalPhase, at: string): CommitJournal;
export type JournalRecovery = 'none' | 'retry-commit' | 'rollback-target' | 'rollback-sources';
/** What a restart may do with the last durable phase. */
export declare function recoveryFor(journal: CommitJournal): JournalRecovery;
//# sourceMappingURL=commit-journal.d.ts.map