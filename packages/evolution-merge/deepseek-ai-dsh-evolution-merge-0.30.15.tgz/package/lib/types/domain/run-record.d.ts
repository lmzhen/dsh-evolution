/** Pure RunRecord v2 types and derived 9-state projection. No IO. */
export type RunStatus = 'running' | 'succeeded' | 'failed' | 'cancelled' | 'interrupted' | 'orphan';
export type MergeStatus = 'running' | 'succeeded' | 'failed' | 'cancelled' | 'awaiting-approval' | 'undone' | 'superseded' | 'interrupted' | 'orphan';
export type PairResult = 'pending' | 'merged' | 'kept' | 'failed' | 'cancelled' | 'undone';
export interface PairRecord {
    readonly pairKey: string;
    readonly a: string;
    readonly b: string;
    readonly result: PairResult;
    readonly target?: {
        readonly requested: string;
        readonly actual?: string;
        readonly created?: boolean;
    };
    readonly stagingRef?: string;
    readonly committed?: boolean;
}
export interface PairIndexEntry {
    readonly pairKey: string;
    readonly runId: string;
    readonly result: PairResult;
    readonly target?: string;
    readonly reportRef?: string;
}
export interface RunRecordV2 {
    readonly id: string;
    readonly kind: 'merge';
    readonly status: RunStatus;
    readonly stage?: 'screening' | 'decide' | 'author' | 'commit' | 'settle';
    readonly approval?: 'on' | 'off';
    readonly parentRunId?: string;
    readonly pairKey?: string;
    readonly plane?: 'local' | 'foreign';
    readonly startedAt: number;
    readonly updatedAt: number;
    readonly endedAt?: number;
    readonly resultRef?: string;
    readonly failure?: string;
    readonly stagingRef?: string;
    readonly pairs: readonly PairRecord[];
    readonly supersededAt?: number;
}
export declare function deriveMergeStatus(record: RunRecordV2): MergeStatus;
export declare function allCommittedUndone(record: RunRecordV2): boolean;
//# sourceMappingURL=run-record.d.ts.map