/**
 * Pending approval actions. The row lookup and the transition happen in one
 * mutateMergeState transaction, so two clients approving the same row cannot both win.
 */
import type { EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
import type { MergeRow } from './contracts.ts';
export type PendingActionResult = {
    readonly ok: true;
    readonly row: MergeRow;
} | {
    readonly ok: false;
    readonly reason: 'not-found' | 'not-pending' | 'invalid';
    readonly message: string;
};
export declare function approvePending(io: EvolutionIoLike, home: string, now: () => number, id: string): Promise<PendingActionResult>;
export declare function rejectPending(io: EvolutionIoLike, home: string, now: () => number, id: string): Promise<PendingActionResult>;
//# sourceMappingURL=pending-actions.d.ts.map