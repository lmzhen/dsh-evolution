/**
 * Pure command-surface parser for the /evolution merge prefix. The command layer only
 * validates shape; run/state effects are injected by the host shell.
 */
export type MergeCliCommand = {
    readonly verb: 'scan';
} | {
    readonly verb: 'pair';
    readonly a: string;
    readonly b: string;
    readonly force?: true;
} | {
    readonly verb: 'status';
    readonly id?: string;
} | {
    readonly verb: 'report';
    readonly id?: string;
} | {
    readonly verb: 'cancel';
    readonly id?: string;
} | {
    readonly verb: 'runs';
} | {
    readonly verb: 'doctor';
} | {
    readonly verb: 'pending';
    readonly expired?: true;
} | {
    readonly verb: 'candidates';
    readonly retry?: true;
} | {
    readonly verb: 'approve';
    readonly id: string;
} | {
    readonly verb: 'reject';
    readonly id: string;
} | {
    readonly verb: 'resume';
    readonly id?: string;
    readonly clear?: string;
    readonly retry?: true;
} | {
    readonly verb: 'skipped';
    readonly restore?: string;
} | {
    readonly verb: 'discard';
    readonly id: string;
} | {
    readonly verb: 'undo';
    readonly target: string;
    readonly run: string;
};
export type ParseMergeCommandResult = {
    readonly ok: true;
    readonly command: MergeCliCommand;
    readonly help?: boolean;
} | {
    readonly ok: false;
    readonly code: 'usage';
    readonly message: string;
};
export declare function parseMergeCommand(argv: readonly string[]): ParseMergeCommandResult;
export declare function mergeUsage(): string;
//# sourceMappingURL=commands.d.ts.map