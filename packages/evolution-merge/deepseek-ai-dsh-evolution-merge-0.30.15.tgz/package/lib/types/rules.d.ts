/**
 * Deterministic gate for a staged merge tree. No io, no model.
 *
 * block = commit must not proceed; warn = report only. The path and reference checks reuse
 * the skill-store's own `validateSupportPath` / `supportRefs`, so there is one whitelist.
 */
import { type SkillLimits } from '@deepseek-ai/dsh-evolution-core';
export interface StagedTree {
    readonly target: string;
    readonly body: string;
    readonly files: readonly {
        readonly path: string;
        readonly content: string;
    }[];
}
export interface RuleFinding {
    readonly rule: string;
    readonly path: string;
    readonly severity: 'block' | 'warn';
    readonly message: string;
}
export declare function validateStagedTree(tree: StagedTree, limits?: SkillLimits): readonly RuleFinding[];
export declare function hasBlockingFinding(findings: readonly RuleFinding[]): boolean;
//# sourceMappingURL=rules.d.ts.map