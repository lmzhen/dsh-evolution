/**
 * Execute a merge undo from its commit receipt. The receipt names the unit and archived
 * sources; this module resolves versions, plans the cross-skill undo and runs the shared
 * executor. No command/routing logic here.
 */
import type { SkillVersion } from '@deepseek-ai/dsh-evolution-core';
import { type UnitUndoExecution, type UnitUndoSink } from '@deepseek-ai/dsh-evolution-core';
import type { CommitReceipt } from './commit-receipt.ts';
export interface MergeUndoPort extends UnitUndoSink {
    listVersions(skill: string): Promise<readonly SkillVersion[]>;
}
export declare function undoMergeReceipt(receipt: CommitReceipt, port: MergeUndoPort): Promise<UnitUndoExecution>;
//# sourceMappingURL=undo-merge.d.ts.map