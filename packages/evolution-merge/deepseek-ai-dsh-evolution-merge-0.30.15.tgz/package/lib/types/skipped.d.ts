/**
 * Skipped filtering: a pair the operator marked as not-worth-merging stays out of automatic
 * screening until mergeSkippedTtlDays expires. Explicit /merge pair ignores this set.
 */
import { type MergeRow } from './contracts.ts';
export declare function skippedPairKeys(rows: readonly MergeRow[], ttlDays: number, now: number): ReadonlySet<string>;
export declare function isSkippedPair(keys: ReadonlySet<string>, a: string, b: string): boolean;
//# sourceMappingURL=skipped.d.ts.map