/**
 * resume command: verify rows re-enter round1; fuse rows re-enter round2 with the persisted
 * decision. pending/skipped rows are not resumable.
 */
import type { EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
import { type MergeRegistryPort, type WithMergeRunResult } from './run-shell.ts';
import type { ScanPorts, ScanRound2Outcome } from './scan-run.ts';
import type { MergeDecision, MergeRow } from './contracts.ts';
export interface RunResumeCommandOptions {
    readonly io: EvolutionIoLike;
    readonly home: string;
    readonly registry: MergeRegistryPort;
    readonly ports: ScanPorts;
    /** Per-run ports for the verify branch (staging needs the new runId). */
    readonly makePorts?: (runId: string) => ScanPorts;
    /** Optional new-child authoring port (approve-after-pending path). */
    readonly round2WithRun?: (row: MergeRow, decision: MergeDecision, signal: AbortSignal, runId: string) => Promise<ScanRound2Outcome>;
    readonly rowId: string;
    readonly platformWrite: boolean;
    readonly timeoutMinutes?: number;
    readonly now: () => number;
}
export declare function runResumeCommand(options: RunResumeCommandOptions): Promise<WithMergeRunResult>;
//# sourceMappingURL=resume-command.d.ts.map