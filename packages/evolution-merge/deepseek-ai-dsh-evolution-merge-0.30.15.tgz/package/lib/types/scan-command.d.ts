/**
 * scan command wiring: the registry/report shell around runScan.
 * Pair/approve/resume commands get their own thin wrappers on the same shell.
 */
import type { EvolutionIoLike } from '@deepseek-ai/dsh-evolution-core';
import { type ScanPorts } from './scan-run.ts';
import { type MergeRegistryPort, type WithMergeRunResult } from './run-shell.ts';
export interface RunScanCommandOptions {
    readonly io: EvolutionIoLike;
    readonly home: string;
    readonly registry: MergeRegistryPort;
    readonly ports?: ScanPorts;
    /** Build per-run ports when staging needs the runId (channel authoring). */
    readonly makePorts?: (runId: string) => ScanPorts;
    readonly approval: boolean;
    readonly platformWrite: boolean;
    readonly timeoutMinutes?: number;
    readonly now: () => number;
    readonly detached?: boolean;
}
export declare function runScanCommand(options: RunScanCommandOptions): Promise<WithMergeRunResult>;
//# sourceMappingURL=scan-command.d.ts.map