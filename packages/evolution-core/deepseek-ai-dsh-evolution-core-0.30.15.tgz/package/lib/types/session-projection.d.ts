import type { Context } from '@deepseek-ai/cordis';
import type { Session } from '@deepseek-ai/dsh-session';
import type { ProjectionDefinition } from '@deepseek-ai/dsh-session-projection';
import { type EvidenceIndex } from './evidence.ts';
import { type TurnFoldState, type TurnSignals } from './signals.ts';
/** Time of the newest event folded for one session; 0 for a log with no event. */
export interface EvolutionActivityState {
    /** Milliseconds of the newest event, or 0 when nothing was folded. */
    readonly lastEventTime: number;
}
/**
 * Which session frames carry content, in complement form.
 *
 * `sequenced` counts the frames that carry an integer seq, so 0 is the "this log cannot tell a
 * boundary from a message" answer the evidence reader reports as `undefined` (a stub session, a
 * log whose events carry no seq).
 *
 * `through` is the highest seq folded, so a citation BEYOND the log answers false exactly as the
 * dense set does. Platform logs number their frames densely from 0 (a seq is a frame's index), so
 * complement and enumeration agree; a sparse hand-built log is not a Session and reaches the unit
 * through neither path.
 */
export interface EvolutionEvidenceState {
    /** Frames folded that carried an integer seq. */
    readonly sequenced: number;
    /** Highest seq folded; -1 before the first sequenced frame. */
    readonly through: number;
    /** Boundary seqs, ascending. Every other seq at or below `through` carries content. */
    readonly bookkeeping: readonly number[];
}
declare module '@deepseek-ai/dsh-session-projection/types' {
    interface SessionProjectionStateMap {
        /** The curator's idleness gate input: the newest event time of one session. */
        evolutionActivity: EvolutionActivityState;
        /** The plan path's evidence-class input: the boundary seqs of one session. */
        evolutionEvidence: EvolutionEvidenceState;
    }
}
/** The `evolutionActivity` unit (host-only: no client view is registered for it). */
export declare const evolutionActivityProjection: ProjectionDefinition<'evolutionActivity'>;
/** The `evolutionEvidence` unit (host-only: no client view is registered for it). */
export declare const evolutionEvidenceProjection: ProjectionDefinition<'evolutionEvidence'>;
/**
 * The skill names one session read through a non-failed dispatch, as a fold state.
 *
 * One entry per READ-CAPABLE dispatch (`isSkillReadToolName`), in first-seen order: the ledger
 * key, the skill the arguments name (null when they name none), and whether a settle failed it.
 * A pending dispatch counts as read — the platform settles every started sub-dispatch, so pending
 * is a live-window state, not a failure (`skillReadNameOf` documents the same rule).
 */
export interface EvolutionReadsState {
    /** Read dispatches seen so far, in first-seen order. */
    readonly reads: readonly {
        readonly key: string;
        readonly skill: string | null;
        readonly failed: boolean;
    }[];
}
/**
 * The current turn's window signals plus the facts a turn boundary needs.
 *
 * `turn` is the SAME state `foldTurnEvent` folds for `observeEvent`; it resets at `turn/start`, so
 * the state after the newest event is exactly the window `foldTurn(session, turnStartSeq)` reads.
 * `through`/`lastEventTime` serve readers that only need progress (the curator's idleness gate has
 * its own unit, but a consumer holding this one gets the same answers).
 */
export interface EvolutionSignalsState {
    /** Seq of the last folded event; -1 before the first. */
    readonly through: number;
    /** Time of the last folded event; 0 before the first. */
    readonly lastEventTime: number;
    /** Seq of the open turn's `turn/start`; -1 when none was seen. */
    readonly turnStartSeq: number;
    /** The open turn's window fold. */
    readonly turn: TurnFoldState;
}
declare module '@deepseek-ai/dsh-session-projection/types' {
    interface SessionProjectionStateMap {
        /** The skill names one session read, for the read-before-write gate and the review plan path. */
        evolutionReads: EvolutionReadsState;
        /** The open turn's window signals, for the review cadence. */
        evolutionSignals: EvolutionSignalsState;
    }
}
/** The `evolutionReads` unit (host-only: no client view is registered for it). */
export declare const evolutionReadsProjection: ProjectionDefinition<'evolutionReads'>;
/** The `evolutionSignals` unit (host-only: no client view is registered for it). */
export declare const evolutionSignalsProjection: ProjectionDefinition<'evolutionSignals'>;
/**
 * Register the family's units on the calling context's fiber.
 *
 * Called by the READERS (not by a plugin's mount) and idempotent by the registry's own reference
 * count: the first read of a foldable session installs the definitions, later reads count as
 * co-owners, and the keys survive until the last registrant unloads
 * (`session-projection/src/index.ts:273-292`). Registering at the read is what keeps a session
 * view the registry cannot fold (`isProjectableSession`) from ever reaching its drive — the
 * registry folds the in-memory log on first touch, so a unit that appears mid-session is still
 * correct (`:602-630`).
 *
 * Idempotent by design, so a plugin mounting later does not need its own call.
 * @param ctx - the mounting plugin's context.
 */
export declare function installEvolutionProjections(ctx: Context): void;
/**
 * Time of one session's newest event, or `undefined` when the unit is not installed.
 *
 * The curator's idleness gate reads this instead of folding the session log; `undefined` is a
 * measurement that did not happen, which the gate answers with the deployment's fail-open policy.
 * @param ctx - a context of the runtime (the service is read from the global store).
 * @param session - the session to ask about.
 * @returns the newest event's milliseconds, or undefined with no unit or no event.
 */
export declare function sessionLastEventTime(ctx: Context, session: Session): number | undefined;
/**
 * The skill names one session read through a non-failed dispatch, or `undefined` when the session
 * cannot be projected (a structural view, or a host without the registry).
 *
 * `undefined` is NOT an empty set: the tool path's read-before-write gate keeps its previous
 * behavior rather than refusing every write in a composition whose session object is a bare stub
 * (`skill-reads.ts` documents that three-state posture).
 * @param ctx - a context of the runtime.
 * @param session - the session whose reads are wanted.
 * @returns the names read, or undefined when the log cannot be folded.
 */
export declare function sessionReadNames(ctx: Context, session: Session): ReadonlySet<string> | undefined;
/**
 * The open turn's window signals, or `undefined` when the session cannot be projected.
 *
 * The window is the events since the newest `turn/start`, folded by the same `foldTurnEvent`
 * `observeEvent` uses; `undefined` means the caller has no measurement (a structural view), not
 * that the turn was empty.
 * @param ctx - a context of the runtime.
 * @param session - the session whose open turn is being judged.
 * @returns the window signals, or undefined when the log cannot be folded.
 */
export declare function sessionTurnSignals(ctx: Context, session: Session): TurnSignals | undefined;
/**
 * The evidence index of one session, or `undefined` when the log cannot be classified.
 *
 * `undefined` covers both the missing unit and a log whose frames carry no seq: the plan path's
 * `EVIDENCE_CLASS` row is report-only and must stay silent rather than report every op.
 * @param ctx - a context of the runtime.
 * @param session - the session the review plan is authored against.
 * @returns an index answering "does this seq carry content?".
 */
export declare function sessionEvidenceIndex(ctx: Context, session: Session): EvidenceIndex | undefined;
//# sourceMappingURL=session-projection.d.ts.map