/** The io surface the reconciliation needs. */
export interface ReachabilityIo {
    list(path: string): Promise<string[]>;
    readText(path: string): Promise<string | null>;
    exists(path: string): Promise<boolean>;
}
/** One domain's reading. `baseline` is the audit's measured value, quoted for comparison, never a target. */
export interface DomainReading {
    readonly domain: string;
    readonly unit: 'bytes' | 'files';
    readonly total: number;
    readonly reachable: number;
    readonly unreachable: number;
    /** The audit baseline this line is checked against, verbatim, so a drift is visible without a lookup. */
    readonly baseline: string;
    /** Set when a read FAILURE made this domain unmeasurable: not "nothing unreachable", but "not read". */
    readonly unmeasured?: string | undefined;
}
/** Every sha256 any skill index references, across the whole history root. */
export declare function referencedBlobs(io: ReachabilityIo, historyRoot: string): Promise<Set<string> | undefined>;
/**
 * The history domain: blobs on disk minus the blobs the indexes still reference.
 * @param io - the tree reader.
 * @param historyRoot - the history root (`.history`), passed in, never guessed.
 * @returns the reading, with the audit baseline quoted for comparison.
 */
export declare function historyReachability(io: ReachabilityIo, historyRoot: string): Promise<DomainReading>;
/**
 * The reports domain: files no run record points at. A record WITHOUT a `resultRef` still owns the
 * conventional path (`reports/maintain-<id>.json`), so that path counts as reachable - counting only
 * explicit refs would report compliant files as orphans and the number could never match the baseline.
 * @param io - the tree reader.
 * @param reportsDir - the reports directory, passed in.
 * @param runIds - every run id the run records carry.
 * @param resultRefs - every explicit resultRef those records carry.
 */
export declare function reportsReachability(io: ReachabilityIo, reportsDir: string, runIds: readonly string[], resultRefs: readonly string[]): Promise<DomainReading>;
/**
 * The backups domain: snapshot trees and how much each holds. `skillsPerSnapshot` is measured by the
 * caller (it already reads manifests); an empty tree is one whose manifest lists no skill.
 * @param io - the tree reader.
 * @param backupsRoot - the snapshot root, passed in.
 * @param skillsPerSnapshot - the caller's manifest reading, one entry per snapshot directory.
 */
export declare function backupsReachability(io: ReachabilityIo, backupsRoot: string, skillsPerSnapshot: readonly number[]): Promise<DomainReading>;
//# sourceMappingURL=reachability.d.ts.map