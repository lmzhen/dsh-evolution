/**
 * 0.19.0 (S4): the family's long-run inventory — one table, one owner per entry.
 *
 * A "long run" is work whose duration is NOT bounded by the interaction that asked
 * for it: a maintenance scan, a curator pass, a review pass. The measured fact this
 * table exists to record is that a CLIENT can end a request long before the work is
 * done (measured: the desktop shell ends a request at ~305 s while the same command
 * finishes in 949.7 s on the web plane), so the lifetime of such work must come from
 * its OWNER — never from the request.
 *
 * Two fields carry the judgments, and a spec pins both:
 *
 *   - `lifetime`: `'plugin'` entries must name an owner and a result home (the work
 *     outlives the request and must be readable afterwards); `'request'` entries
 *     must say WHY their cost cannot reach the wall.
 *   - `measured`: only measured numbers, with their basis. An unmeasured bound is
 *     written as exactly that — this table is not a place to guess.
 *
 * The rendered table is pinned byte-for-byte into `packages/README.md` by
 * `tests/long-runs.spec.ts` (the T-WD2 pattern the command registry already uses),
 * so the published table cannot drift from this list.
 * @module
 */
/** What kind of work an entry describes. */
export type LongRunKind = 'command' | 'tool' | 'pass';
/** Whose lifetime the work borrows. `'plugin'` = it must outlive the request. */
export type LongRunLifetime = 'request' | 'plugin';
/** One entry of the long-run inventory. */
export interface LongRunEntry {
    /** Command/entry id as a user sees it. */
    id: string;
    kind: LongRunKind;
    /** The package that owns the work (its lifecycle, its budget, its result). */
    owner: string;
    lifetime: LongRunLifetime;
    /** The measured cost, with its basis. Never a guess. */
    measured: string;
    /** Where the deadline/budget comes from, or why there is none. */
    budget: string;
    /** Where a result is readable after the work settles. */
    resultHome: string;
    note: string;
}
/**
 * The inventory. Order is the rendered order; a spec pins it into the README.
 */
export declare const LONG_RUNS: readonly LongRunEntry[];
/**
 * Render the inventory as the README table rows (no header).
 * @returns one markdown row per entry, in inventory order.
 */
export declare function renderLongRunTable(): string;
//# sourceMappingURL=long-runs.d.ts.map