/**
 * Skill library management for the self-evolution plugin.
 *
 * Skills live under `$DSH_HOME/skills` (`~/.dsh/skills` by default), matching
 * the default dsh skill-filesystem user root. The plugin only manages skills
 * it created unless a `.hermes-managed` marker opts a skill in. Archival is a
 * move to `.archive/` — never a hard delete.
 *
 * ## Concurrency discipline (OPT-09, 2026-09) — read before adding a mutator
 *
 * Three primitives, three distinct jobs (they compose, they do not replace
 * each other):
 *
 * 1. **In-process serial queue** (`this.serial`, makeSerialQueue) — orders the
 *    read→plan→commit phases of one skill's mutation against OTHER mutators
 *    in this process. Used by: create/update/patch/setPinned/restructure/
 *    writeSupportFile/removeSupportFile and (whole-mutation) consolidate.
 *    NON-reentrant: a callback must never call a public method that wraps
 *    itself in `this.serial` (archive/restoreFromArchive deliberately do not).
 * 2. **Per-directory write lock** (io.ts LOCK_*) — cross-process mutual
 *    exclusion plus in-process crash ownership (tickets, takeover). Checked
 *    with `supportDirsUnlistable` before any destructive move (archive/restore/
 *    snapshot); held inside transactIo by byte writers.
 * 3. **CAS baseline (`expected:`)** — any read whose bytes feed a later write
 *    must either live inside the serial section that commits the write, or
 *    carry its plan-time bytes as `expected` so the commit fails closed on
 *    drift (V8-11 / V24-01). A read outside the serial section WITHOUT a
 *    baseline is a lost-update bug; this file's history is the test suite.
 *
 * Known residuals (deliberate, documented at their sites): the archive commit
 * re-check narrows but does not close the pin race (OPT-06); snapshotAll
 * re-probes after its copies so a mid-copy writer demotes to `skipped`
 * (OPT-07); the movers' probe→rename window is owned by the io.ts protocol.
 */
import { type WriteAuthority } from './write-authority.ts';
import { transactIo, type EvolutionIoLike } from './io.ts';
import { type Probe } from './probe.ts';
import type { SkillLimits } from './limits.ts';
import { type MutationRecord } from './mutations.ts';
import { type UnitHead, type SkillVersion } from './skill-history.ts';
import { type SkillHealthAssessment, type SkillHealthThresholds } from './skill-health.ts';
import type { EvolutionSkillMutatedEvent } from './events.ts';
export interface SkillSummary {
    name: string;
    description: string;
    path: string;
    protectedBy: string | null;
    /** A1-17 (v18): the marker probe itself failed (EACCES/EIO), so "no marker"
     * cannot be told apart from "directory unreadable". Consumers must treat this
     * as protected, never as unprotected.
     * v41: this flag and `protectedBy` ARE the read three-state —
     * (null, false) = no marker, (X, false) = present, (_, true) = unreadable.
     * Read them together, never this flag alone; it is a published field, so the
     * encoding stays (core's `Probe<T>` is for internal decisions, not for this
     * contract). */
    protectionUnknown: boolean;
    managed: boolean;
    /** E-11 (v18): the frontmatter `whenToUse` routing hint, published so the
     * platform catalog keeps it while this provider shadows the upstream
     * filesystem provider. Absent when the frontmatter has none. */
    whenToUse?: string;
    /** v35 C11: the whole SKILL.md body, present only for
     * {@link SkillLibrary.list} calls that pass `{ withContent: true }`. A consumer
     * that needs both the summary fields and the body (tree hashing, enrichment,
     * drift scans) saves the second per-skill read; the default stays body-free so
     * the common listing does not hold a whole tree in memory. */
    content?: string;
    /** T2-07/A22: the parsed frontmatter record, present only for
     * {@link SkillLibrary.list} calls that pass `{ withFrontmatter: true }`. The
     * listing parses the file it already read, so a consumer that derives a policy
     * from frontmatter (the catalog’s invocation map) shares that ONE read instead
     * of paying a second per-skill read. Absent when the file carries no parseable
     * frontmatter — the same posture as its description. */
    frontmatter?: Record<string, unknown>;
}
/**
 * Stage-time anchor for a full-content write (v35 C9): the sha256 the caller read
 * when it staged the plan, or `absent` when the target did not exist then. The
 * library compares it against the bytes it reads INSIDE the write's own lock — the
 * same read the write commits — so a concurrent writer landing between staging and
 * commit is refused instead of silently overwritten.
 */
export type WriteAnchor = {
    readonly sha256: string;
} | {
    readonly absent: true;
};
/**
 * What the write lock observed about an anchor target.
 * - `match`: the anchor holds; the write proceeds.
 * - `drift`: the target exists with different bytes.
 * - `missing`: the target does not exist (an `absent` anchor `match`es this).
 */
export type AnchorVerdict = 'match' | 'drift' | 'missing';
/**
 * Evaluate a stage-time anchor against the bytes a locked read observed.
 * @param anchor - the caller's anchor, or `undefined` for an unanchored write.
 * @param current - the bytes the write lock read (`null` = the target is absent).
 * @returns `match` when the write may proceed, otherwise the refusal verdict.
 */
export declare function anchorVerdict(anchor: WriteAnchor | undefined, current: string | null): AnchorVerdict;
export interface SkillActionResult {
    ok: boolean;
    message: string;
    path?: string;
    /** Frontmatter keys auto-quoted for catalog-loadable YAML (0.3.11) — set
     * only when the write path modified the block. */
    normalizedFrontmatterFields?: string[];
    /** 0.3.18 (E-68): patch produced byte-identical content (old===new) — no
     * write, no audit, no mutation event; callers must not count a patch. */
    noop?: boolean;
    /** Set when the caller passed a {@link WriteAnchor} that the locked read did
     * not satisfy: nothing was written. Carries {@link SkillActionResult.anchor}
     * so a caller with staged-replay wording can translate it (v35 C9). */
    stale?: true;
    /** The locked read's verdict for the caller's anchor. */
    anchor?: AnchorVerdict;
}
/**
 * One section move of a restructure proposal (008 batch B): a body section
 * anchored by its exact `## heading` line is moved to a references/ support
 * file and replaced by a pointer line. The skill name/dir never change —
 * restructure is a content-distribution repair, not a routing change.
 */
export interface SkillRestructureMove {
    /** The `##` heading title, matched as an exact line (leading `##` + spaces); no fuzzy matching. */
    heading: string;
    /** Destination support file: `references/<topic>.md` (references/ only — moved content is log/detail, never a template or script). */
    toFile: string;
}
/** Upper bound of moves per restructure proposal (validator and core agree). */
export declare const MAX_RESTRUCTURE_MOVES = 5;
/** Restructure targets are plain markdown files under references/ — no
 * subdirectories, no other support kind. V8-10 (0.3.47): the regex-level
 * `(?!.*\.\.)` keeps the restructure-created set EXACTLY the set
 * validateSupportPath can reopen — a `references/my..notes.md` target (double
 * dots) used to pass here while every later patch/write/remove on it was
 * refused as traversal (an orphan file the user could not touch). */
export declare const RESTRUCTURE_TARGET_RE: RegExp;
/** Extra file name carried inside a snapshot's `extras/` directory. */
export declare const SNAPSHOT_EXTRA_NAME_RE: RegExp;
/** An opaque side file stored under a snapshot's `extras/` (curator state etc.). */
export interface SnapshotExtra {
    name: string;
    content: string;
}
/** Normalized manifest of a skills snapshot. */
export interface SnapshotManifest {
    reason: string;
    createdAt: string;
    /** Active skill names at snapshot time. */
    skills: string[];
    /** V25-05 (v25): skills that were SKIPPED by the write-lock probe at
     * snapshot time (a live byte-writer held them) — they are NOT in the
     * snapshot directory and are NOT restored by a whole-tree restore, which
     * clears the live tree and copies back only `skills`. Consumers must
     * surface this list; restore reports it in its result message. Absent
     * (empty) on pre-0.3.67 manifests. */
    skipped: string[];
    /** Co-copied sidecar file names (usage/suppression). */
    sidecars: string[];
    /** Whether `.archive/` was co-copied; absent on legacy manifests (do not touch archive on restore). */
    hasArchive?: boolean;
    /** Extras declared under `extras/`; only these names are ever read back. */
    extras: string[];
}
/** Who is writing: a foreground user-directed tool call, or the autonomous review/curator pipeline. */
export type WriteOrigin = 'foreground' | 'subagent' | 'background_review';
/** Options for `SkillLibrary.archive`. The absorbed-into name and the archival reason are distinct fields. */
export interface ArchiveOptions {
    /** Umbrella skill this one was consolidated into; when set it must exist (consolidate semantics). */
    absorbedInto?: string;
    /** Human-readable reason written to `.archive-reason`; default derives from `absorbedInto`. */
    reason?: string;
    /** Permit archiving a bundled skill (curator prune-builtins only; hub-installed and pinned stay protected). */
    allowBundled?: boolean;
    /** Unit shared with the rest of a multi-skill transaction (merge). */
    unitId?: string;
    /** Cross-skill landmark for the unit; a merge source names the target. */
    unitHead?: UnitHead;
}
/** One multi-skill merge commit: target body + support files, with the source names it absorbs. */
export interface CommitMergePlan {
    readonly target: string;
    /** Whether the target already exists. The caller planned this; commit re-checks it. */
    readonly targetExists: boolean;
    readonly sources: readonly string[];
    readonly body: string;
    readonly supportFiles: readonly {
        readonly path: string;
        readonly content: string;
    }[];
    /** Plan-time target body; null for a create. */
    readonly expectedTargetBody: string | null;
    readonly expectedSourceBodies: readonly {
        readonly name: string;
        readonly body: string;
    }[];
    readonly origin: WriteOrigin;
    readonly summary: string;
}
export interface CommitMergeResult {
    readonly ok: boolean;
    readonly message: string;
    readonly unitId?: string;
    readonly targetPath?: string;
    readonly archived?: readonly string[];
    /** One per skill written: target + each source. */
    readonly mutations?: number;
}
export declare function skillsRoot(env?: NodeJS.ProcessEnv): string;
/** 0.3.18 (S4.1, E-30): the ONE root resolution for every member that reads
 * the skills tree — tool-skill-manage / evolution-skill-catalog / skill-usage
 * / evolution-learning-graph used to each resolve `config.root || skillsRoot()`
 * (and the graph ignored config entirely). Empty/whitespace config falls
 * through to the default; callers pass their raw Config. The optional field is
 * declared `| undefined` so a config object whose root field is explicitly
 * `string | undefined` still assignable under exactOptionalPropertyTypes.
 * P2-31 core half (S2.2 batch, PLAN 2026-09-16): an explicit non-empty root
 * is `resolve()`d — the same normalization `evolutionRoot` applies and the
 * same one upstream skill-filesystem applies to `customSkillDirs`
 * (`(config.customSkillDirs ?? []).map(root => resolve(root))`). The former
 * verbatim return left a RELATIVE config root CWD-relative, so the family's
 * skill tree moved with the host process's launch directory while every
 * absolute consumer (watchers, the platform catalog) resolved it — a
 * split-brain tree; a trailing slash or `..` segment likewise landed
 * unnormalized. A clean absolute root is byte-identical (resolve is a no-op). */
export declare function resolveSkillsRoot(config?: {
    root?: string | undefined;
}): string;
/** E-7 (v18) → V27 G2.4 (M-08): every family row reads ONE root key. `root` is
 * canonical; the `skillsRoot` alias was honoured for one minor version and its
 * window closed at 0.3.65 — it is now two releases past expiry, so this
 * resolver no longer reads it at all. A deployment that still sets the alias
 * must fail LOUDLY at load (see {@link assertSkillsRootAliasRetired}): silently
 * ignoring a config key leaves the deployment pointing at a root nobody reads,
 * which is the worst form of compatibility.
 * @param config - the raw plugin config.
 * @returns the effective root (empty when the key is unset or blank).
 */
export declare function resolveRootConfig(config?: {
    root?: string | undefined;
}): {
    root: string;
};
/** V27 G2.4 (M-08): the retirement gate for the expired `skillsRoot` alias.
 * Called at each plugin's load boundary (before the root is resolved), it turns
 * a stale key into an explicit load error naming the replacement — the
 * fail-loud form the plan requires instead of a silent no-op.
 * @param config - the raw plugin config (the alias field stays DECLARED in each
 * schema so the loader can hand it here instead of dropping it).
 */
export declare function assertSkillsRootAliasRetired(config?: {
    skillsRoot?: string | undefined;
}): void;
/**
 * Map a requesting session onto the two origin surfaces (rc.44 plan M2-2.3):
 * the APPROVAL surface treats every delegated subagent as the autonomous
 * review channel, while the LIBRARY surface keeps the Hermes distinction -
 * the review fork is 'background_review' (the pinned guard blocks its
 * writes) and any other subagent is 'subagent' (agent-authored, not
 * review-channel). `isReview` marks the caller as the background review
 * pipeline itself. Single source: the two tools and the review executor all
 * read this table instead of re-deriving it.
 */
export declare function resolveOrigins(headerOrigin: string | undefined, isReview?: boolean): {
    approval: 'foreground' | 'background_review';
    library: WriteOrigin;
};
/** Minimal structural view of a tool execution context, so the helper below
 * stays decoupled from the platform's exec type (extra fields are ignored). */
export interface EvolutionExecOriginView {
    agent?: {
        session?: {
            id?: unknown;
            header?: {
                origin?: string;
            };
        };
    };
}
/**
 * S1-E8 (0.3.80): ONE exec→origins resolution for the two write tools — reads
 * the session header origin AND the v37 S2.2 review-channel session mark, so a
 * tool cannot forget the mark half (tool-memory shipped without it, which
 * mislabeled every inject-mode review memory write as `foreground` and let it
 * bypass staging under `stageForeground: false`).
 * Single source: both tools call this instead of re-deriving the pair.
 */
export declare function resolveExecOrigins(exec: EvolutionExecOriginView | undefined): {
    approval: 'foreground' | 'background_review';
    library: WriteOrigin;
};
/** Dot-prefixed on-disk marker name. SINGLE source: `list()` matches directory
 * entries against this name, and path builders must never hardcode a marker
 * literal (N-1: the rc.49 exists()-probe convergence dropped the dot,
 * poisoning every protectedBy/managed report). Exported for cross-package
 * consumers that must probe markers without re-deriving the name (curator's
 * archive-copy bundled probe, 0.3.26 V4-02). */
export declare function markerEntryName(marker: 'bundled' | 'hub-installed' | 'pinned' | 'hermes-managed'): string;
/** A1-6 (v18): the regex alone admits `references/nul.md` (a Windows device
 * stem), which the support-file layer refuses. Restructure must use the same
 * rule, or it creates an orphan the later patch/write/remove paths refuse.
 * Single source shared with the plan validator. */
export declare function validateRestructureTarget(filePath: string): string | null;
export declare function validateSupportPath(filePath: string): string | null;
/**
 * Support-directory references in a markdown body (009 kernel): `references/…`,
 * `templates/…`, `scripts/…`, `assets/…` relative links — any extension and
 * nested paths (v7 audit P3-1: `.md`-only matching missed `scripts/run.sh` and
 * `references/sub/x.md`, both of which dangle just like a `.md` link once the
 * source package is archived). Pure — who checks them and what the verdict is
 * belongs to the caller's context (a moved/appended body whose references
 * travel with an archived source is a dangling link; a restructure pointer is
 * a fresh link to a file written in the same plan). `..` traversal is a
 * different defect class (path validation owns it) and is not a support link.
 */
export declare function supportRefs(content: string): string[];
export declare class SkillLibrary {
    readonly root: string;
    readonly limits: SkillLimits;
    private readonly io;
    private readonly onMutation;
    /** 0.3.21 (F-208) + V4-20: cross-process RMW transactor. An explicitly
     * injected value wins; otherwise the IO backend's own `transact` is bound
     * when it provides one (cross-process atomicity on by default for any
     * transact-capable backend), and a backend without `transact` leaves this
     * undefined (each write falls back to the plain read→task→write path). */
    private readonly transact;
    /** 0.3.21 (F-208): in-process serialize queue so two concurrent mutators on
     * one skill never interleave their read-modify-write (the cross-process layer
     * is the IO backend's transact lock; this chain is the second layer). */
    private readonly serial;
    /** V10-03 (P2-18): see the constructor's threatExemptLabels. Empty by
     * default — the strict ANY-hit-blocks policy is unchanged. */
    private readonly threatExemptLabels;
    /** G1/1.1: default authority; a call may override (origin is per-invocation). */
    /** G1/1.1/Stage 2: the ONE default every mutator reads. Per-call overrides still win. */
    private readonly authority;
    /** skill-history.ts: the content history is best-effort, so a failure must not be SILENT —
     * but it is a deployment condition, not a per-write event, so it warns once per instance. */
    private historyWarned;
    constructor(root?: string, io?: EvolutionIoLike, limits?: SkillLimits, onMutation?: (event: EvolutionSkillMutatedEvent) => void, transact?: typeof transactIo, threatExemptLabels?: readonly string[], authority?: WriteAuthority);
    /**
     * Run one single-file read-modify-write for a mutator. When `transact` was
     * injected the read and the write run inside it (cross-process atomicity);
     * otherwise a plain read → task → write sequence runs (the process-level
     * `serial` chain is the second layer). `task` receives the current content
     * (null when missing) and returns a {@link SingleWriteOutcome}. Audit and the
     * mutation event are issued ONLY when a write actually lands, so a no-op
     * never inflates the mutation-maturity counter.
     */
    private runSingleWrite;
    /**
     * v28 G1.1 (EVO-IO-02): shared compensating cleanup for a locked write that
     * found no SKILL.md — remove the possibly-resurrected directory ONLY when it
     * holds nothing but this path's own write-lock file. The BR-5 rule from
     * setPinnedCore/createCore applies unchanged: a concurrent mover can land a
     * full directory between the list probe and the remove, so ANY content at all (support files, a
     * fresh restore) must never be recursed away. Best-effort: a failed cleanup leaves the "not found" result
     * unchanged (the operator-facing ghost-dir refusal is fail-loud already).
     */
    private cleanupGhostDir;
    /** Notify the mutation observer after a successful write; observers must never fail the mutation. */
    private notifyMutation;
    /** V10-03 (P2-18): ScanOptions shared by every write-path threat check —
     * the constructor's exempt labels, empty by default (behavior unchanged). */
    private threatScanOptions;
    /** V10-03 (P2-18): the strict-scan write gate. A block message names the hit
     * label (scanContentThreats already embeds it) plus the self-heal hint, so a
     * false-positive rewrite direction is actionable instead of a dead end. */
    private contentThreatBlock;
    /**
     * v30 REV-03: read a support file's bytes for staleness anchoring (the
     * write/remove replay guard). Same validation as writeSupportFile; a
     * missing file (or a directory squatting on the path) reads as `null`, any
     * other failure RETHROWS — the callers are the staging/replay anchors, and
     * a swallowed error would silently downgrade the anchor to
     * last-writer-wins.
     */
    /**
     * S4-01 (G0/0.7): the ONE three-state read the staging/replay anchors use.
     *
     * The two absorbing reads below absorb ENOENT/EISDIR and rethrow everything else, and the callers then
     * each wrote their own try/catch to turn a rethrow into a decision - three near-copies of one posture,
     * and the newest of them silently dropped the anchor instead of refusing. A read failure is its own
     * state, so it gets its own name here: `unknown` with the reason, next to `present` and `absent`.
     * Failing closed is then the CALLER decision (they refuse on unknown), not something each call site has
     * to re-derive from a thrown error.
     */
    readSkillProbe(rawName: string): Promise<Probe<string>>;
    /** The support-file face of {@link readSkillProbe}. */
    readSupportFileProbe(rawName: string, filePath: string): Promise<Probe<string>>;
    /** One place that turns the absorbing reads into three states. `null` is absent; a throw is unknown. */
    private probeOf;
    readSupportFile(name: string, filePath: string): Promise<string | null>;
    /**
     * Summarize the skill tree.
     * @param options - `withContent` attaches each skill's whole SKILL.md body to
     * its summary (v35 C11), `withFrontmatter` its parsed frontmatter record
     * (T2-07/A22): the read this listing already performs is the one either would
     * cost again, so a caller pays no second pass over the tree.
     * @returns one summary per readable skill directory.
     */
    /** T2-V2/A27: the skill names the TREE holds — the same listing rule {@link list} applies (dot
     * entries skipped, a SKILL.md must exist), WITHOUT reading any SKILL.md. A consumer that needs the
     * member set rather than the summaries (the learning graph's node set) pays one directory listing
     * instead of a whole-tree read pass.
     * @returns the sorted skill directory names. */
    treeNames(): Promise<string[]>;
    list(options?: {
        withContent?: boolean;
        withFrontmatter?: boolean;
    }): Promise<SkillSummary[]>;
    read(rawName: string): Promise<string | null>;
    /**
  
     * Single path-building choke point (rc.42 audit P2-5): every directory path
  
     * is built from the TRIMMED name, so a name that passes `badName` (which
  
     * trims before validating) can never mint a second, whitespace-padded
  
     * directory next to the real one. Callers keep passing raw user input.
  
     */
    private dirOf;
    /**
     * Name-format guard for every path-building entry point (P1-1/v14 closed the
     * one gap: `patch`). Write paths, protection probes and support-file
     * enumeration all call it before `dirOf`, so no directory path is ever built
     * from a name that could escape the skills root. `list()` and `snapshotAll()`
     * are the deliberate exceptions — their names come from `listNames()`, i.e.
     * from the tree itself, never from caller input.
     */
    private badName;
    /**
     * Refusal reason for a write to `rawName`, or null when the write may
     * proceed: a protection marker on the directory, or an invalid name
     * (P1-1/v14 — the name guard lives HERE as well as at every entry point, so
     * no caller can build a path from an unvalidated name).
     */
    writeProtection(rawName: string, origin?: WriteOrigin): Promise<string | null>;
    deleteProtection(rawName: string, options?: {
        allowBundled?: boolean | undefined;
    }): Promise<string | null>;
    isManaged(rawName: string): Promise<boolean>;
    /** Whether the skill carries the bundled marker (curator prune-builtins eligibility). */
    isBundled(rawName: string): Promise<boolean>;
    /** Whether the skill carries the pinned marker (the marker is the factual source; usage.pinned mirrors it). */
    isPinned(rawName: string): Promise<boolean>;
    /** Count non-empty support subdirectories (richness input for quality scoring). */
    /** G4 ⑤-d: the dangling targets THIS write introduced, as a receipt note (empty when none).
     *
     * Uses the SAME resolver as the drift signal, so a receipt and a drift row can never disagree;
     * an absent or unknown listing reports nothing rather than inventing a dead link.
     */
    private danglingNoteFor;
    countSupportDirs(rawName: string): Promise<number>;
    /**
     * Support-file paths (`references/x.md`) under SUPPORT_DIRS for one skill,
     * as a THREE-state read (N14): a missing skill directory is absent, an
     * unreadable one is unknown. A partial listing is unknown too — the union
     * promises the present branch is complete (011 §7 enrichment, probe reads).
     */
    listSupportFiles(rawName: string): Promise<Probe<string[]>>;
    /**
     * V4 (design §16.6): exact character counts of the support files that can
     * POSSIBLY exceed the content cap. The pre-filter is BYTE size, and that is
     * sound rather than approximate: a UTF-16 code unit never costs less than one
     * UTF-8 byte, so a file whose bytes are within the cap provably cannot exceed
     * the cap in characters. The returned map is therefore COMPLETE for the
     * oversize question without reading the small files.
     * @param rawName - the skill's name.
     * @returns path -> character count (possibly empty), or null when the listing or
     *   a size probe cannot answer — unknown is never an empty map.
     */
    /** A plan-time read whose bytes become a tree change's CAS baseline (`expected`). A failed read is
     * NAMED and answers `null`, which is FAIL-CLOSED at commit: the baseline is then "absent", so an
     * existing file counts as drift and the commit refuses instead of overwriting bytes nobody read
     * (N36: the failure is not silently "the file is not there").
     * @param target - the file a tree change is about to write.
     * @returns its bytes, or `null` for both "absent" and "could not read". */
    private readForCas;
    supportFileChars(rawName: string): Promise<Record<string, number> | null>;
    /**
     * Structure-health facts for one skill (rc.73 A1, 008 design): body
     * chars/density from SKILL.md, support groups from countSupportDirs, plus
     * optional usage counts (A2 churn dimension) when the caller has them.
     * Derived, never persisted. CONTRACT: `null` whenever the skill cannot be
     * read — a missing file AND any read failure (EACCES/EIO/…) both answer
     * null, so a whole health view degrades one ROW instead of throwing out of
     * its per-skill loop (A6, audit P2-10: the former code absorbed only
     * missing/EISDIR and let a transient win32 hold kill the entire view).
     */
    assessHealth(rawName: string, thresholds?: SkillHealthThresholds, counts?: {
        patchCount?: number;
        readCount?: number;
    }): Promise<SkillHealthAssessment | null>;
    /** Best-effort audit trail entry; never blocks the mutation.
     *
     * Two independent best-effort writes run here, because either one failing must not cost the
     * other: the CONTENT history (skill-history.ts, so a version can be read back at all) and the
     * mutation ledger that points at it. The history failure is not silent — a deployment whose
     * history stopped growing is a degradation worth seeing once (the ledger keeps hashes either
     * way). */
    private audit;
    /** Recent mutation audit records (read-only inspection surface). */
    listMutations(): Promise<MutationRecord[]>;
    /**
     * Content versions recorded for one skill, oldest first (skill-history.ts, batch A).
     *
     * Read-only: the version seam never feeds a judgment — callers use it to LIST and to read content
     * back. A malformed or unreadable index reads as empty, and a bad name reads as empty too (the
     * caller is a human command, so "no versions" is the honest answer for a name that cannot exist).
     * @param rawName - the skill's name.
     * @returns the versions, oldest first.
     */
    listVersions(rawName: string): Promise<SkillVersion[]>;
    /**
     * One version's content, read back from the content-addressed blob store.
     * @param rawName - the skill's name.
     * @param v - the version number (see {@link SkillLibrary.listVersions}).
     * @returns the content, or null when the version does not exist, the name is unusable, or the
     *   blob cannot be read — never an empty string.
     */
    readVersion(rawName: string, v: number): Promise<string | null>;
    /**
     * Pin or unpin a skill (`.pinned` marker). Pinned skills are protected from
     * deletion, from background-review writes, and from the lifecycle — a
     * protective mutation, so the autonomous pipeline may never call it. The
     * marker write is the only state change; content is untouched.
     */
    setPinned(name: string, pinned: boolean, origin?: WriteOrigin): Promise<SkillActionResult>;
    private setPinnedCore;
    create(name: string, content: string, origin?: WriteOrigin, options?: {
        unitId?: string;
        unitHead?: UnitHead;
    }): Promise<SkillActionResult>;
    private createCore;
    update(rawName: string, content: string, origin?: WriteOrigin, anchor?: WriteAnchor): Promise<SkillActionResult>;
    private updateCore;
    patch(rawName: string, oldString: string, newString: string, filePath?: string, replaceAll?: boolean, origin?: WriteOrigin): Promise<SkillActionResult>;
    private patchCore;
    /**
     * P2-9 (v15): the destructive directory move shared by archive and
     * restoreFromArchive — rename first, copy+remove fallback when the backend
     * cannot rename across media (V5-35), with the E-14 rollback when the
     * fallback's source removal fails. Returns a failure MESSAGE on a failed
     * move (caller wraps into a structured result) or undefined on success.
     */
    private moveDir;
    /**
     * P2 (v16): the write-lock probe for the DESTRUCTIVE MOVERS (archive /
     * restoreFromArchive). A byte-writer mid-flight is the ghost-generator —
     * after the move its transact commit re-creates `<dir>/…` (mkdir
     * recursive) and the tree ends half-archived.
     * G2 S4: the writer-lock probe that used to answer this question is retired — writes go through
     * the provider's versioned writes, so a writer that raced the move fails its own write loudly
     * instead of landing on a moved-away path. What REMAINS load-bearing here is the fail-closed
     * listing rule, which is about the filesystem misbehaving rather than about writers.
     */
    private supportDirsUnlistable;
    /** A1-4 (v18): a manifest-declared name is copied with `join(root, name)`;
     * only a single, non-traversing path component is safe. Dotfiles
     * (`.usage.json`) stay allowed — sidecars are legitimately dot-prefixed.
     * P2-4 (v19): a non-string entry (`skills: [123]`) is refused structurally
     * instead of throwing `name.includes is not a function`. */
    private safeSnapshotEntryName;
    archive(rawName: string, options?: ArchiveOptions, origin?: WriteOrigin): Promise<SkillActionResult>;
    /**
     * Commit one merge plan as a single multi-skill transaction.
     *
     * Existing target: archive every source first, then write the target through the
     * tree-change kernel. Create target: create the target with its final body first
     * (so absorbedInto can see it), then archive sources and write support files.
     * Every failure rolls back what already landed; a rollback failure names the
     * unrestored skills instead of claiming success.
     */
    commitMerge(plan: CommitMergePlan): Promise<CommitMergeResult>;
    /**
     * V2 (design §16.7): what an apply-mode consolidation would do for ONE source,
     * computed BEFORE any side effect. `blocked` means behaviour is exactly the
     * plan-mode refusal (with the reason named); `apply` carries the rewritten body
     * and the support files that must be copied into the target.
     * @param source - the moving skill's name.
     * @param targetName - the destination skill's name.
     * @param body - the moving body (frontmatter stripped).
     * @returns the decision plus the note to append to a refusal.
     */
    private planSourceRehoming;
    /**
     * Merge the bodies of `sources` into `target` and archive the sources with
     * an absorbed-into marker. Hermes-style consolidation: overlapping skills
     * collapse into one, and the originals stay recoverable under `.archive/`.
     *
     * `mode:'append'` (default) appends each source body to the target. The
     * target write goes through the tree-change kernel (009) — byte-level
     * rollback, audit and the mutation event are kernel-owned. Package-integrity
     * (009-I): append-mode consolidation REFUSES a source whose directory has
     * support files or whose body carries support-directory links — an append
     * would leave those references pointing at an archived package (dangling);
     * the refusal message directs to the reference mode / whole-package archive.
     *
     * `mode:'reference'` writes each source's body (frontmatter stripped) into
     * `target/references/<source>.md` and archives the source — the demote path
     * (009-II). A source body with support-directory links is refused there too
     * (the references file would carry links whose files were archived).
     *
     * V2 (design §16.7) lifts that refusal when `referenceRewrite:'apply'` and the
     * plan proves the move is safe: the support files the body NEEDS are copied into
     * the target under their own paths (renamed only on a collision) and the body's
     * references are rewritten to match, in the same commit. Anything the plan
     * cannot place — a cited file the source no longer has, an unreadable listing —
     * still refuses, and the refusal names it. The archived source keeps whatever
     * the body did not need.
     */
    consolidate(target: string, sources: string[], origin?: WriteOrigin, options?: {
        mode?: 'append' | 'reference';
    }): Promise<SkillActionResult>;
    /**
     * Content-distribution repair (008 batch B, 009-R kernel): move body
     * sections — anchored by their exact `## heading` lines — into references/
     * support files and replace each span with a pointer line. The skill
     * name/dir never change (routing stays; only content location shifts, so a
     * fat body sheds its log-like detail). Deterministic, never automatic:
     * candidates come from an approved review plan. The write batch goes
     * through the tree-change kernel — one commit point, byte-level rollback.
     * Package integrity (009-R): a moved section whose text carries
     * support-directory links is refused (those links' files stay behind in the
     * same package; the moved text belongs in references/ beside them).
     */
    restructure(rawName: string, moves: SkillRestructureMove[], origin?: WriteOrigin): Promise<SkillActionResult>;
    private restructureCore;
    /**
     * Unified tree-change commit point (009 kernel): owns validation order,
     * pre-read rollback bytes, two-phase write with byte-level rollback, audit
     * and the mutation event. Mutators compose `TreeChangePlan`s — consolidate,
     * restructure (and future reference-mode consolidations) never implement
     * two-phase commit themselves.
     */
    private applyTreeChange;
    /**
     * Restore one skill from `.archive/` back to the active root. Hermes-style
     * recoverability: archival never deletes, and this is the control-plane
     * path back. The `.archive-reason` marker is dropped on restore.
     */
    restoreFromArchive(rawName: string, origin?: WriteOrigin): Promise<SkillActionResult>;
    writeSupportFile(rawName: string, filePath: string, content: string, origin?: WriteOrigin, anchor?: WriteAnchor): Promise<SkillActionResult>;
    private writeSupportFileCore;
    removeSupportFile(rawName: string, filePath: string, origin?: WriteOrigin, anchor?: WriteAnchor, unitId?: string): Promise<SkillActionResult>;
    private removeSupportFileCore;
    /**
     * v23 (ML-1): `.archive` retention. Archived skills are recoverable history,
     * but nothing bounded their growth — the curator auto-archives idle skills,
     * consolidation and manual deletes take the same path, and every snapshot
     * copies the whole `.archive` (keep-5 retention amplifies it ×6). Entries
     * older than this many days are pruned at snapshot time. Generous by
     * design: a year-old auto-archive is effectively dead recoverability.
     * Backends without the mtime probe skip pruning (no false deletes on
     * unknown age).
     */
    /**
     * 0.5.0 V1 (design §16.6-④): the retention window's READ half. Names every
     * archived entry past the window without touching it — the report path the
     * default policy uses, and the input the curator's run report carries.
     * @returns the expired entry names ([] when the backend has no mtime probe,
     *   because an unknown age must never read as expired).
     */
    /** Names currently in .archive, for target occupancy; unknown listing is null. */
    archivedNames(): Promise<string[] | null>;
    expiredArchives(): Promise<string[] | null>;
    /** V4 (design §16.6): support-file char policy, resolved at the call site. */
    supportFileCharPolicy(): 'report' | 'enforce';
    /** Retention policy resolved at the call site (absent limits object = report).
     * Public so a run report can say WHICH policy produced its numbers. */
    archiveRetentionPolicy(): 'report' | 'prune';
    private pruneExpiredArchives;
    /**
     * Snapshot the recoverable skills state: active tree, usage/suppression
     * sidecars, `.archive/` and caller-supplied extras. `extras` are opaque
     * side files the Snapshot owner cares about (curator state); they are
     * listed in the manifest and only those names are ever read back.
     */
    snapshotAll(reason?: string, extras?: SnapshotExtra[]): Promise<string>;
    /** Read and normalize a snapshot manifest; null when the file is missing or unparsable. */
    /**
     * V26-03 (v25/v26): sanitize the manifest's `skipped` list before it can
     * reach a user-visible restore message. Entries must pass the same name
     * gate as snapshot entries (a corrupted or hand-edited manifest cannot
     * inject arbitrary text into the result), bounded to 50 entries of at most
     * 64 chars each (the name-rule maximum — real skill names always fit).
     */
    private sanitizeSkippedNames;
    /**
     * V27 G0.4 (core-a-01): the per-entry gate `skipped` already has. A corrupted
     * or hand-edited manifest could carry `extras: [123]`: the array check passed,
     * `SNAPSHOT_EXTRA_NAME_RE.test(123)` coerced the number to the string "123"
     * and matched, and the value then threw `TypeError` inside `path.join` — which
     * `readSnapshotExtras` reached only AFTER a whole-tree restore had committed.
     * Extras are path components under `extras/`, so they take the entry gate too;
     * bounded like `skipped` so a hostile manifest cannot grow the read set.
     */
    private sanitizeExtraNames;
    readSnapshotManifest(path: string): Promise<SnapshotManifest | null>;
    /** Keep only the newest N snapshots (Hermes keep=5 parity); older ones are removed outright. */
    /**
     * G3/3.4: can a snapshot actually be used right now?
     *
     * The recovery messages used to promise "restore it from a snapshot" without asking whether a usable
     * snapshot exists (audit S1-01: the message promised recoverability from a chain that is five deep and
     * whose newest member held 9 of 35 skills). Three states, like every other reading here: a fragment
     * naming the usable snapshot, a fragment saying there is none, or a fragment saying the directory could
     * not be read - the caller embeds whichever it gets, so the sentence is generated by the capability.
     */
    private snapshotRecoveryAvailability;
    private retainSnapshots;
    /** Snapshots as a THREE-state read (N14): absent = no .backups directory,
     * unknown = it exists but could not be listed (a caller must not read a
     * failed listing as "no snapshots to restore"). */
    listSnapshots(): Promise<Probe<Array<{
        path: string;
        createdAt: string;
        reason: string;
    }>>>;
    /**
     * Read the extras of a snapshot, restricted to the names declared in the
     * manifest — an `extras/` directory is never listed directly, so unknown
     * files cannot leak back as state on the next restore.
     */
    readSnapshotExtras(path: string): Promise<SnapshotExtra[]>;
    /**
     * Manifest-driven restore of the latest snapshot: active tree, sidecars,
     * `.archive/` and (for full-state snapshots) the extras read back by the
     * caller. `extras` are additionally written into the pre-rollback safety
     * snapshot so the rollback itself is undoable with the same state.
     */
    restoreLatestSnapshot(extras?: SnapshotExtra[]): Promise<SkillActionResult & {
        extras?: SnapshotExtra[];
    }>;
    /**
     * Whole-tree replacement from one snapshot path (rc.50 P2-14): every
     * NON-system entry in the active root is cleared first, then the manifest
     * drives the repopulation (skills, sidecars, `.archive`). Extracted from
     * restoreLatestSnapshot so a failed restore can roll itself back (E-13).
     */
    private restoreSnapshotIntoRoot;
}
/** The emit surface the helper needs — structurally the platform context's
 * `emit`, so core states the contract without importing the platform type. */
export interface SkillMutationSink {
    emit: (type: 'evolution/skill-mutated', event: EvolutionSkillMutatedEvent) => unknown;
}
/** V41 P2-26 (0.3.75): the ONE SkillLibrary construction point.
 *
 * Eleven call sites used to re-derive the root and hand-roll the
 * `evolution/skill-mutated` arrow (the catalog invalidates its cache on that
 * exact string, so a second spelling is a silent divergence), and each one
 * re-decided its own limits. `config` stays the RAW family config: resolving
 * an empty `root` to the family default is `resolveSkillsRoot`'s policy, not
 * a per-caller detail. */
export interface NewSkillLibraryOptions {
    /** Raw family config; only `root` is read, through resolveSkillsRoot. */
    config?: {
        root?: string | undefined;
    } | undefined;
    io: EvolutionIoLike;
    limits?: SkillLimits | undefined;
    /** Supplying it wires the mutation event HERE — never at the call site. */
    ctx?: SkillMutationSink | undefined;
    transact?: typeof transactIo | undefined;
    threatExemptLabels?: readonly string[] | undefined;
    /** G1/1.1: WHO writes through this library. Required: no call site can omit it. */
    authority: WriteAuthority;
}
export declare function newSkillLibrary(options: NewSkillLibraryOptions): SkillLibrary;
export { DEFAULT_SKILL_LIMITS, DEFAULT_CITATION_POLICY, DEFAULT_REFERENCE_REWRITE_POLICY, DEFAULT_ARCHIVE_RETENTION_POLICY, DEFAULT_SUPPORT_FILE_CHAR_POLICY, POLICY_STAGE_DEFAULTS, policyStageLimits, } from './limits.ts';
export type { SkillLimits, CitationPolicy, ReferenceRewritePolicy, ArchiveRetentionPolicy, SupportFileCharPolicy, PolicyStageFields, } from './limits.ts';
export { authoringFeedback, frontmatterBlock, frontmatterCatalogInvalid, normalizeFrontmatter, parseFrontmatter, relatedSkillNames, validateFrontmatter, yamlPlainScalarNeedsQuotes } from './frontmatter.ts';
export type { AuthoringFeedback, Frontmatter, FrontmatterNormalizeResult, FrontmatterRead, PlatformStringSplit } from './frontmatter.ts';
//# sourceMappingURL=skill-store.d.ts.map