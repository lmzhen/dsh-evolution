/**
 * Shared constants for the dsh-evolution plugin family.
 *
 * Two classes of value live here, deliberately separated by section so future
 * edits do not blur the semantic boundary:
 *
 * 1. **Fixed protocol/format/security invariants** — changing these breaks an
 *    on-disk format, a naming/format contract, a path-security boundary, or a
 *    cross-component invariant. They are NOT exposed as deployment config.
 *
 * 2. **Cross-package shared tunable defaults** — the same semantic default is
 *    read (with a config override path) by more than one package (e.g.
 *    `evolution-policy` and `evolution-curator` both default `staleAfterDays`
 *    to 30). Centralizing them here means one authoritative default: a config
 *    override still applies per package, but the fallback is single-sourced.
 *
 * Package-private tunables (used by exactly one package) stay in that package,
 * not here — see evolution-replay's `DEFAULT_WEIGHTS` and evolution-feedback's
 * threshold, which are intentionally left where they are used.
 * @module @deepseek-ai/dsh-evolution-core
 */
/**
 * Required argument names per `skill_manage` action — the SINGLE SOURCE read
 * by the tool's argument gate (tool-skill-manage write-gates.ts) and the plan
 * validator (evolution-plan-validator), so the two can never drift.
 * OPT-05 (2026-09): the plan validator used to accept a `write_file`/
 * `remove_file` op without `file_path` while the executor required it — the
 * staged write then failed at EVERY approve until rejected.
 * Rows here are the op-level requirements only: `delete` additionally
 * requires `absorbed_into` at the PLAN layer (review passes may only delete
 * into an umbrella) and `pin`/`unpin` are tool-only actions — each consumer
 * adds its own extras on top of this table. An empty-string argument is NOT
 * caught here (the tool's gate deliberately lets it reach the library for a
 * more specific remedy message); the validator adds its own `.trim()`
 * emptiness checks for payload fields.
 */
export declare const SKILL_ACTION_REQUIRED_FIELDS: Readonly<Record<string, readonly string[]>>;
/** Skill frontmatter `name` validated for the file name (lowercase + hyphen).
 * 计划 B-4 (v18): tightened to the UPSTREAM `SKILL_NAME` shape
 * (`/^[a-z0-9]+(?:-[a-z0-9]+)*$/`, packages/skill/skill/src/index.ts:21). The
 * old form admitted trailing/consecutive hyphens, which upstream
 * `validateCandidate` throws on — and that throw aborts the WHOLE `ctx.skills`
 * collection. The catalog provider still filters such legacy tree entries so
 * an existing tree cannot break a session. */
export declare const SKILL_NAME_RE: RegExp;
/** Allowed skill support-file subdirectories (path-traversal boundary). */
export declare const SUPPORT_DIRS: readonly ["references", "templates", "scripts", "assets"];
/** Delimiter between durable memory entries (on-disk storage format). */
export declare const ENTRY_DELIMITER = "\n\u00A7\n";
/** Built-in skill names the curator must never lifecycle-manage. */
export declare const PROTECTED_BUILTIN_SKILLS: ReadonlySet<string>;
export declare const MAX_SKILL_NAME_LENGTH = 64;
export declare const MAX_DESCRIPTION_LENGTH = 1024;
export declare const MAX_SKILL_CONTENT_CHARS = 100000;
/** How many content versions to retain per skill (skill-history.ts). 20 mirrors the count
 * KiroCrew settled on for the same job (its `MAX_SKILL_VERSIONS`), and is an E2 deployment
 * parameter — the value is a retention policy, not a protocol constant. */
export declare const DEFAULT_SKILL_VERSION_KEEP = 20;
/** The authoring DISCIPLINE band, taken from the upstream standard (archive §5):
 * peer skills sit at 8-14k characters and a body pushing past 20k belongs in
 * `references/*.md`. Deliberately separate from `MAX_SKILL_CONTENT_CHARS`: the
 * hard ceiling is a deployment-tunable limit, this band is the authoring
 * standard — deriving the band from the ceiling is exactly what let a 40k
 * ceiling hide a 99k body without a single signal saying "split me" (V3). */
export declare const AUTHORING_SPLIT_LINE_CHARS = 20000;
/** Upstream's conversion basis for CHARACTER LIMITS: 2.75 chars/token, labelled
 * model-independent in the config template (\`cli-config.yaml.example:538\`), and the
 * basis behind every quoted token figure there — memory 2200 chars ≈ 800 tokens,
 * user 1375 ≈ 500, SKILL.md 100_000 ≈ 36k (\`tools/skill_manager_tool.py:455\`).
 * Limits are deliberately conservative, so this is the basis a BORROWED LIMIT must
 * be converted with. */
export declare const UPSTREAM_LIMIT_CHARS_PER_TOKEN = 2.75;
/** The platform's own estimate basis: \`CHARS_PER_TOKEN = 4\` in
 * \`@deepseek-ai/dsh-token-meter/estimate.ts\` (its comment reads "used until exact
 * tokenization is needed"), matching upstream's ESTIMATE-side heuristic — "~4
 * chars/token is the usual English heuristic" (\`agent/prompt_builder.py:1179\`).
 * Estimates use this; limits use the constant above. */
export declare const PLATFORM_ESTIMATE_CHARS_PER_TOKEN = 4;
export declare const MAX_SKILL_FILE_BYTES = 1048576;
export declare const DEFAULT_REVIEW_MEMORY_INTERVAL = 10;
export declare const DEFAULT_REVIEW_SKILL_INTERVAL = 10;
/** Skill-review completion channel trigger mode: 'cadence' | 'completion' | 'both'.
 * 0.3.39 (V6-53 follow-up): default is 'cadence' — since 0.3.38 the cadence
 * channel's review is executed at conversation END (deferred), so 'both' would
 * inject a second (task-complete) prompt at the same boundary; the cadence
 * deferral alone IS the end-of-conversation summary. */
export declare const DEFAULT_SKILL_REVIEW_TRIGGER: "cadence";
/** Cumulative session tool calls before a session counts as "proven long" for the completion channel. */
export declare const DEFAULT_SKILL_REVIEW_COMPLETION_MIN_TOOL_CALLS = 20;
export declare const DEFAULT_SUBSTANTIVE_MIN_TOOL_CALLS = 3;
export declare const DEFAULT_SUBSTANTIVE_MIN_USER_CHARS = 200;
export declare const DEFAULT_SUBSTANTIVE_MIN_AGENT_CHARS = 500;
export declare const DEFAULT_MAX_OPS_PER_PLAN = 32;
export declare const DEFAULT_CURATOR_INTERVAL_HOURS = 168;
export declare const DEFAULT_MIN_IDLE_HOURS = 2;
export declare const DEFAULT_STALE_AFTER_DAYS = 30;
export declare const DEFAULT_ARCHIVE_AFTER_DAYS = 90;
/**
 * Support-file count above which `references-sprawl` warns. **NOT CALIBRATED YET** — 60 is a
 * placeholder: the platform corpus is empty (no platform skills available here), so the admission
 * band cannot be checked. Until `gen-health-baseline` reports both corpora, the rule is
 * REPORT-ONLY: its count must not be shown as a number on any surface (plan G4 ③).
 */
export declare const SUPPORT_SPRAWL_FILES = 60;
export declare const DEFAULT_MEMORY_CHAR_LIMIT = 2200;
export declare const DEFAULT_USER_CHAR_LIMIT = 1375;
/** Consolidation-failure backoff cap, shared by MemoryStore and memory-files' Config default. */
export declare const DEFAULT_CONSOLIDATION_FAILURES = 3;
/** F-20 (v18): the authored-body budget and the hard ceiling are the same
 * number today. Derive it so a future divergence is one edit, not two names
 * that silently disagree. */
export declare const DEFAULT_SKILL_CONTENT_CHARS = 100000;
/** P3-19 (v14): defaults that were written twice (schema `.default()` AND the
 * clamp fallback literal) now have one home per value. */
export declare const DEFAULT_REVIEW_TIMEOUT_MS = 120000;
export declare const DEFAULT_REVIEW_CONTEXT_MESSAGES = 60;
export declare const DEFAULT_REVIEW_MESSAGE_CHARS = 2000;
export declare const DEFAULT_CURATOR_BOOT_GRACE_SECONDS = 10;
export declare const DEFAULT_CURATOR_REVIEW_MAX_TOKENS = 2048;
/** Threat-scan WINDOW SIZE (not a total cap — E-12: the whole text is scanned in
 * overlapping windows, so content beyond this stays in scope). The coverage
 * floor is `PATTERN_OVERLAP + 1` (V6-05). Single home for the core scanners'
 * default parameter and clamp fallback, plus evolution-threat's Config default
 * — the two packages previously wrote 65_536 independently (G0/S0.1). */
export declare const DEFAULT_THREAT_MAX_SCAN_CHARS = 65536;
/** 0.3.17 (S3.10, T-1): control-plane fields a model-facing write call may
 * never carry — single source for plan-validator, evolution-policy and the
 * threat scanner (they used to each hardcode the list).
 * P2-13 (v37): staged_from_sha256 joins the list — it is the replay's own
 * staleness anchor, and the tool-arguments root is an OPEN object, so a model
 * could otherwise choose the anchor that decides the write's outcome. */
export declare const FORBIDDEN_CONTROL_KEYS: readonly ["policy", "threshold", "prompt_hash", "model_route", "evolution_config", "staged_from_sha256"];
/** 0.3.17 (S3.10): the model-facing write tools the policy guard and threat
 * scanner cover. */
export declare const EVOLUTION_WRITE_TOOLS: readonly ["memory", "skill_manage"];
/** Hermes authoring quality bar for descriptions (the 60-char Rule). The
 * platform's own index limit stays in validateFrontmatter; this bar is the
 * target the authoring standard names, enforced as ADVISORY feedback.
 * 0.3.16 (T-4): moved here from skill-store.ts so drift-signals (pure, no IO)
 * can reference it without importing the skill-store module. */
export declare const AUTHORING_DESCRIPTION_BAR = 60;
/** The PLATFORM's default cap on the description a skill catalog shows —
 * `catalogDescriptionMaxLength` on the platform's `tool-skill` row (default 500).
 *
 * Recorded here because it is the third number in the description-length relationship, and the one
 * that is easiest to misread as a family rule: the family's own host/all rows SET that field to
 * `AUTHORING_DESCRIPTION_BAR` (60), so what a family deployment truncates at is the ROW's value —
 * this default only governs compositions that do not override it. It is NOT a refusal threshold:
 * the only refusal is `MAX_DESCRIPTION_LENGTH` / the row's `maxDescriptionLength`, and the catalog
 * cut is a view, not a validation. See tool-skill-manage/README.md for the three-number table. */
export declare const PLATFORM_CATALOG_DESCRIPTION_DEFAULT = 500;
/** The split hint both size refusals share (0.5.0 V1). The same sentence used to
 * be copied into validateFrontmatter AND the patch path, and neither copy named
 * where the content should go — the upstream cap message names the destination
 * directories, and that is the part a model actually acts on. */
export declare const CONTENT_SPLIT_HINT = "\u5EFA\u8BAE\u62C6\u6210\u66F4\u5C0F\u7684 SKILL.md\uFF0C\u628A\u652F\u6491\u6587\u4EF6\u653E\u8FDB references/ \u6216 templates/\u3002";
/** V27 G2.4: the largest millisecond delay a timer accepts. `AbortSignal.timeout`
 * (and `setTimeout`) coerce anything larger to 1ms after a Node warning, so a
 * timeout configured above this ceiling silently collapses to "immediately
 * aborted". The curator's review timeout and the review timeout each carried
 * their own copy of the literal; the bound is one protocol constant.
 * (v19 P2-10 corrected the value from 2^32-1 to Node's real 2^31-1 ceiling.) */
export declare const MAX_TIMER_DELAY_MS = 2147483647;
/**
 * Model-facing budget of one `maintenance_probe` call (ms) — a HANG GUARD, not a
 * performance knob.
 *
 * Measured (2026-10-10): one probe costs 188/220/225 ms on the deployed library
 * (28 skills / 418 KB) and scales linearly at ~5.5 ms per skill (100 skills
 * 0.4-0.6 s, 400 skills 1.9-2.5 s), so this default is ~50x the worst measured
 * case and ~600x the deployed one — it will not fire in normal use, and the
 * ~305 s desktop interaction wall is ~5e4 skills away.
 *
 * It exists for the state the probe cannot report itself: a provider that never
 * answers. The platform's tool-timeout guard reads this budget off the tool
 * definition and turns the hang into a diagnosable `tool call timed out after
 * <ms>ms` error result, instead of a request that ends with nothing to read.
 * Reopen the default when the library approaches ~1e4 skills, when the
 * `evolutionIo` provider stops being local, or when a model leg enters a tool's
 * execute (the same conditions the probe's own note lists).
 */
export declare const DEFAULT_PROBE_TIMEOUT_MS = 120000;
/** V27 G2.4: the model each review/curation leg defaults to. The policy schema,
 * the policy resolver and the curator's LLM nomination pass each carried their
 * own copy of these strings — a deployment that changed the policy default used
 * to leave the curator passing a different model than the reviews. */
export declare const DEFAULT_MEMORY_REVIEW_MODEL = "deepseek-v4-flash";
export declare const DEFAULT_SKILL_REVIEW_MODEL = "deepseek-v4-pro";
export declare const DEFAULT_CURATOR_MODEL = "deepseek-v4-pro";
/** Order of the `evolution:memory-guidance` section (before the skills one). */
export declare const MEMORY_GUIDANCE_SECTION_ORDER = 11000;
/** Order of the `evolution-skills-guidance` section (last of the two). */
export declare const SKILLS_GUIDANCE_SECTION_ORDER = 11100;
//# sourceMappingURL=constants.d.ts.map