import type { EvolutionIoLike } from './io.ts';
export interface TreeLockRecord {
    readonly token: string;
    readonly pid: number;
    readonly startedAt: number;
}
export interface TreeLock {
    readonly token: string;
    readonly path: string;
    readonly acquiredAt: number;
    release(): Promise<void>;
}
export type TreeLockAcquireResult = {
    readonly ok: true;
    readonly lock: TreeLock;
} | {
    readonly ok: false;
    readonly reason: 'busy' | 'io';
    readonly holder?: TreeLockRecord;
    readonly message?: string;
};
export interface TreeLockOptions {
    readonly io: EvolutionIoLike;
    /** Evolution home; the lock lives at <home>/merge/.tree-lock. */
    readonly home: string;
    /** How long to wait for a busy lock. Default 5000 ms. */
    readonly waitMs?: number;
    /** Poll interval. Default 25 ms. */
    readonly pollMs?: number;
    readonly now?: () => number;
    readonly sleep?: (ms: number) => Promise<void>;
}
/** The one lock path. */
export declare function treeLockFile(home: string): string;
/** Read the current holder without creating or changing anything. */
export declare function readTreeLock(io: EvolutionIoLike, home: string): Promise<TreeLockRecord | undefined>;
/**
 * Acquire the tree write lock, waiting up to `waitMs`.
 *
 * A live holder is never stolen. A record whose pid is gone (or a corrupt record) is
 * taken over; that is how a killed process releases its lock without a timer.
 */
export declare function acquireTreeWriteLock(options: TreeLockOptions): Promise<TreeLockAcquireResult>;
/** Acquire, run, release; the lock is released even when the body throws. */
export declare function withTreeWriteLock<T>(options: TreeLockOptions, body: (lock: TreeLock) => Promise<T>): Promise<{
    ok: true;
    value: T;
} | Exclude<TreeLockAcquireResult, {
    ok: true;
}>>;
//# sourceMappingURL=tree-lock.d.ts.map