/**
 * Cross-skill unit undo planner.
 *
 * The curator's single-skill undo already proves the rule: one path is described by
 * (baseline, oldest after, newest after), and a path the unit created is removed. A merge
 * unit adds two shapes:
 *
 * - a source that the merge ARCHIVED: undo restores it from .archive; it has no live ops;
 * - a target the merge CREATED: undo archives the target (never hard-deletes it); it has no
 *   body op.
 *
 * The plan is pure; the executor resolves hashes to bytes and applies anchors. Any refusal
 * means the caller writes nothing.
 */
import { type SkillVersion } from './skill-history.ts';
export interface UnitUndoMember {
    readonly skill: string;
    /** Entries of this unit for this skill. */
    readonly entries: readonly SkillVersion[];
    readonly status: 'live' | 'archived' | 'missing';
    /** Required when status is archived: the archived directory to restore from. */
    readonly archivedPath?: string;
    /** True when this unit created the skill (the target of a merge-into-new). */
    readonly createdInUnit?: boolean;
}
export interface UnitUndoOp {
    readonly skill: string;
    /** '' means SKILL.md; otherwise a support path relative to the skill directory. */
    readonly path: string;
    readonly remove: boolean;
    readonly preUnitHash?: string;
    /** The bytes the unit left on disk; the executor's CAS anchor. */
    readonly expectedHash: string;
}
export interface UnitUndoRestore {
    readonly skill: string;
    readonly archivedPath: string;
}
export interface UnitUndoPlan {
    readonly ops: readonly UnitUndoOp[];
    readonly restores: readonly UnitUndoRestore[];
    /** New targets: undo archives them instead of writing a body. */
    readonly archiveTargets: readonly string[];
    readonly refusals: readonly string[];
}
/** Plan one unit across a live target and any archived sources. */
export declare function planUnitUndoAcross(members: readonly UnitUndoMember[]): UnitUndoPlan;
//# sourceMappingURL=unit-undo-plan.d.ts.map