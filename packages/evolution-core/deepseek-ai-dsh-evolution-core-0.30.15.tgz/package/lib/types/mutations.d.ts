/**
 * Curator/author audit trail: `.mutations.json` records every skill mutation
 * with before/after content hashes so any automated edit is reviewable and
 * replayable. Best-effort persistence, mirroring the usage sidecar posture.
 * @module @deepseek-ai/dsh-evolution-core
 */
import { type EvolutionIoLike } from './io.ts';
export interface MutationRecord {
    skillName: string;
    action: string;
    beforeHash?: string;
    afterHash?: string;
    /** The skill-history version the content on each side of this mutation belongs to
     * (skill-history.ts). Optional: records written before content history existed carry none, and
     * the hashes above stay the authority for "what changed". */
    beforeVersion?: number;
    afterVersion?: number;
    summary: string;
    at: string;
    /** G5: who caused this mutation — a write face ('foreground', 'background_review', …) or a
     * migration step. Optional: records written before the ledger carried it stay readable. */
    origin?: string;
}
export declare const DEFAULT_MUTATION_CAP = 500;
/** Version of the `.mutations.json` file shape; writers always emit the current one. */
export declare const MUTATIONS_FILE_VERSION = 1;
export declare function mutationsFile(root: string): string;
export declare function contentHash(content: string): string;
export declare function loadMutations(root: string, io?: EvolutionIoLike): Promise<MutationRecord[]>;
/** Append one record, trim to `cap`, and write atomically (versioned shape). */
export declare function recordMutation(root: string, io: EvolutionIoLike, record: MutationRecord, cap?: number): Promise<void>;
//# sourceMappingURL=mutations.d.ts.map