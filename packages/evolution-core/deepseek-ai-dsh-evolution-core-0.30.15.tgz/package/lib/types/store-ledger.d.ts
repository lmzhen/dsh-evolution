/**
 * G3/3.2 (audit 06-performance.md 接缝 C): ONE declaration for every bounded store.
 *
 * Before this file the family had eight retention rules scattered across four packages and no place
 * that could answer "how long does this record live under the current policy" (S1.md 4.3): six caps
 * were named constants, three lived inline (snapshots 5, reports 20/20/10, archive 365d). Each entry
 * below states its bound AND the code that declares it, so a gate can compare the two sets.
 *
 * `declare` is an ARRAY because one store may have several declaration sites (the report buckets are
 * kept by two packages). The `inline` branch matches a CODE SNIPPET rather than a line number: line
 * numbers rot on every edit above them, a snippet survives (and a snippet that stops matching is the
 * detector the gate wants). No naming convention is assumed anywhere - that is the whole point of a
 * ledger: the list IS the declaration.
 */
/** How one bound is declared in code. `named` resolves a constant; `inline` matches a snippet in a file. */
export type StoreBoundDeclare = {
    readonly kind: 'named';
    readonly module: string;
    readonly name: string;
    readonly value: number | string;
} | {
    readonly kind: 'inline';
    readonly file: string;
    readonly contains: string;
    readonly value: string;
};
/** One bounded store: what it is, who owns it, what bounds it, and where that bound is declared. */
export interface StoreSpec {
    readonly id: string;
    /** The package that keeps the store (the one a reclamation change belongs to). */
    readonly owner: string;
    readonly unit: 'bytes' | 'files' | 'entries';
    /** The bound itself, as a person reads it (a cap, or a policy phrase when removal is report-only). */
    readonly bound: string;
    /** What makes an entry removable - the cutoff the bound counts over. */
    readonly cutoff: string;
    readonly trigger: 'write' | 'run-end' | 'pass-end' | 'manual';
    /** Where a footprint reading for this store comes from (the field 3.3 reports). */
    readonly artifact: string;
    readonly declare: readonly StoreBoundDeclare[];
}
/** The one list. A new bounded store that is not registered here is what the G3 gate refuses. */
export declare const STORE_LEDGER: readonly StoreSpec[];
//# sourceMappingURL=store-ledger.d.ts.map