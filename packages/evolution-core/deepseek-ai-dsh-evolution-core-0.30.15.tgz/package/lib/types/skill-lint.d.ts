export type LintSeverity = 'warn' | 'error';
export interface LintFinding {
    severity: LintSeverity;
    /** Stable rule id; findings are diffed by (rule, count), never by message text. */
    rule: string;
    message: string;
    /** How many times the rule bit — a name-only comparison hid one site becoming nine. */
    count: number;
}
/** Size facts the deciding engine already measured. `null` means NOT MEASURED, never fine: a rule
 * that needs a missing fact stays silent rather than inventing a pass or a failure. */
export interface SkillDims {
    bodyChars: number | null;
    bodyTokens: number | null;
    stampDensityPerKb: number | null;
    /** Support GROUPS (non-empty references/templates/scripts/assets dirs) — the old dimension. */
    supportGroups: number;
    /** Support FILES under references/ (contract §4), or null when the caller cannot count them. */
    supportFiles: number | null;
    /** Raw stamp hits behind `stampDensityPerKb` — the COUNT this rule reports (never a fixed 1). */
    stampHits: number | null;
    churnPatches: number | null;
    churnReads: number | null;
}
/** The judgement itself, computed by `skill-health.ts` on its own scales; this module never
 * recomputes it from raw numbers (that is exactly how a second set of thresholds appears). */
export interface LintFacts {
    skillName: string;
    dims: SkillDims;
    softLineChars: number;
    overSoftLine: boolean;
    overTwiceSoftLine: boolean;
    stampLimitPerKb: number;
    /** The engine's own churn threshold — the rule must use the SAME number, not a literal. */
    churnMinPatches: number;
    /** True when the caller could read the body at all. */
    readable: boolean;
}
interface LintRule {
    readonly id: string;
    readonly severity: LintSeverity;
    run(facts: LintFacts): LintFinding | null;
}
/** One rule yields AT MOST one finding (contract §3). `body-oversize-2x` is the only rule whose
 * severity can escalate a verdict to needs-restructure. */
export declare const RULES: readonly LintRule[];
export declare function lintSkill(facts: LintFacts): LintFinding[];
/** What a write introduced, what got worse, what got fixed. A rule whose count grew (one site to
 * nine) counts as worsened — comparing by rule name alone reported nothing. */
export declare function diffFindings(before: readonly LintFinding[], after: readonly LintFinding[]): {
    introduced: LintFinding[];
    worsened: LintFinding[];
    resolved: string[];
};
/** Support files = markdown files under references/ (contract §4: unit frozen, underscore-prefixed
 * excluded). Paths are supplied by the caller — this module never touches the filesystem. */
export declare function countReferenceFiles(paths: readonly string[]): number;
export {};
//# sourceMappingURL=skill-lint.d.ts.map