/**
 * 0.19.0 (S2) / 0.19.3 (restructure): the family's run-lifecycle owner.
 *
 * A "run" is work that can outlive one interaction — the maintenance scan and merge workflows.
 * Before this module the only record of such work was the requesting invocation:
 * `lastMaintainAt` / `lastMaintainRunId` / `maintainInFlightSince` were
 * module-scope globals in evolution-commands, and the plan text existed ONLY in
 * the command's return string. An interaction that ended (measured: the desktop
 * shell hangs up at ~305 s) therefore erased every trace of a still-running scan.
 *
 * This registry is the single owner of (a) what is in flight, (b) how a run
 * ended, and (c) WHERE its result lives (`resultRef` is a path, never the result
 * itself — the report file is the one result home).
 *
 * Three disciplines are structural, not stylistic:
 *
 *   - **One writer per row** (0.19.3). A run's row is authoritative in the memory of
 *     the process that STARTED it (`owned`) and in the shared index for everyone else
 *     (`foreign`, rebuilt from the file on every `load()`). The only write a non-owner
 *     may make is the orphan verdict for a row whose owner is gone, judged inside the
 *     very transaction that read the row. The two cross-plane bugs this family shipped
 *     were projections of that one missing rule: 0.19.0 froze a foreign run as
 *     `running` forever (a "known id" was never re-read), and 0.19.1 wrote a settled
 *     foreign row back as `running` (memory overwrote every row it knew).
 *   - **No timer.** A run whose process died is converged at READ time: the live rows
 *     are in memory, so a `running` row in the file whose owner is not alive is an
 *     orphan — the same "converge when read" posture the approval window uses.
 *   - **One terminal state, and it is monotone.** `settle()` refuses to overwrite a row
 *     that is already terminal (so a cancel that raced a failure cannot flip the answer
 *     the operator already read), and a row that reached a terminal state never reads as
 *     `running` again: only the owner that started it could make it running and
 *     `settle()` is terminal-once, so a `running` claim for a settled row can only be a
 *     stale writer's — refused on read, repaired on the next write.
 *
 * The store is PER INSTANCE (a factory, not module scope): one registry per
 * mounted row, disposed with its fiber. There is no module-scope mutable state
 * here to register under N12.
 * @module
 */
import type { EvolutionIoLike } from './io.ts';
/** The kinds of long-running work the registry tracks. */
export type RunKind = 'maintain' | 'merge';
/** Which merge command opened a run. `kind` stays the work family; this is the command. */
export type RunCommand = 'scan' | 'pair' | 'approve' | 'resume';
/** Coarse, user-visible stage of a run. */
export type RunStage = 'screening' | 'decide' | 'author' | 'commit' | 'settle';
/** Progress of a run's current stage. */
export interface RunProgress {
    readonly done: number;
    readonly total: number;
}
/** The four terminal-or-live states of a run. */
export type RunState = 'running' | 'succeeded' | 'failed' | 'cancelled';
/** One tracked run. `resultRef` is a path to the run's report, never its content. */
export interface RunRecord {
    id: string;
    kind: RunKind;
    state: RunState;
    startedAt: number;
    /** The merge command that opened this run, when the kind is merge. */
    command?: RunCommand | undefined;
    /** The stage the owner last reported. */
    stage?: RunStage | undefined;
    progress?: RunProgress | undefined;
    /** The process that owns a RUNNING record. Required to tell an in-flight run of
     * another plane (both planes share one DSH_HOME) from the orphan of a dead one;
     * absent means the owner cannot be named, which is treated as gone. */
    pid?: number | undefined;
    endedAt?: number | undefined;
    /** Absolute path of the run's report, written by the run owner at settle. */
    resultRef?: string | undefined;
    /** Why the run did not succeed (an abort reason, a validation failure). */
    failure?: string | undefined;
    /** Set when a tree restore made this run's effects un-undoable. */
    supersededAt?: number | undefined;
    /** The run this run was spawned from (approve/resume after an earlier command). */
    parentRunId?: string | undefined;
    /** Merge-side projection; core lifecycle stays four-state. */
    mergeStatus?: 'running' | 'succeeded' | 'failed' | 'cancelled' | 'awaiting-approval' | 'undone' | 'superseded' | 'interrupted' | 'orphan' | undefined;
    stagingRef?: string | undefined;
    pairKey?: string | undefined;
    pairs?: readonly unknown[] | undefined;
}
/** What a started run gets: its id and the signal its work must honour. */
export interface RunHandle {
    readonly id: string;
    readonly kind: RunKind;
    readonly signal: AbortSignal;
    /** When the run was registered — the same instant the record carries. */
    readonly startedAt: number;
    readonly command?: RunCommand | undefined;
    readonly parentRunId?: string | undefined;
    /** Merge-side projection; core lifecycle stays four-state. */
    readonly mergeStatus?: 'running' | 'succeeded' | 'failed' | 'cancelled' | 'awaiting-approval' | 'undone' | 'superseded' | 'interrupted' | 'orphan' | undefined;
    readonly stagingRef?: string | undefined;
    readonly pairKey?: string | undefined;
    readonly pairs?: readonly unknown[] | undefined;
}
/** How a run ended, as reported by its owner. */
export interface RunOutcome {
    state: 'succeeded' | 'failed' | 'cancelled';
    resultRef?: string | undefined;
    failure?: string | undefined;
    mergeStatus?: 'running' | 'succeeded' | 'failed' | 'cancelled' | 'awaiting-approval' | 'undone' | 'superseded' | 'interrupted' | 'orphan' | undefined;
}
/** The registry surface the commands row drives. */
export interface RunRegistry {
    /**
     * Converge the persisted index; the commands row calls it before answering any read.
     * The foreign view is rebuilt wholesale (0.19.3), so a row another plane settled is
     * re-read here instead of being frozen at whatever this process first saw.
     */
    load(): Promise<{
        ok: boolean;
        note?: string;
    }>;
    /**
     * Register a new run, arm its cancellation, and return its handle.
     *
     * Resolves only once the row is in the shared index (0.19.1, review P2): the detached
     * lifetime starts when the caller answers "started", so a plane that reads that answer
     * must find the run. The cost is one local index write on the ack path (milliseconds).
     */
    begin(kind: RunKind, seed?: {
        command?: RunCommand;
        total?: number;
        parentRunId?: string;
        mergeStatus?: 'running' | 'succeeded' | 'failed' | 'cancelled' | 'awaiting-approval' | 'undone' | 'superseded' | 'interrupted' | 'orphan';
        stagingRef?: string;
        pairKey?: string;
        pairs?: readonly unknown[];
    }): Promise<RunHandle>;
    /** Record a run's terminal state (first writer wins). */
    settle(id: string, outcome: RunOutcome): Promise<void>;
    /** Record the current stage/progress of a running run. */
    stage(id: string, stage: RunStage, progress?: RunProgress): Promise<void>;
    /** Mark runs as superseded by a tree restore; idempotent. */
    supersede(ids: readonly string[]): Promise<void>;
    /** Mark every run of a kind in the SHARED index (including foreign rows); returns the count. */
    supersedeKind(kind: RunKind): Promise<number>;
    /** The live run, optionally filtered by kind. */
    inFlight(kind?: RunKind): RunRecord | undefined;
    /** When the newest terminal run of a kind ended (`undefined` when none). */
    lastSettledAt(kind?: RunKind): number | undefined;
    /** Every tracked run, newest first (retained history: cap applied). */
    runs(kind?: RunKind): readonly RunRecord[];
    /** One run by id, converged view included. */
    find(id: string): RunRecord | undefined;
    /** Ask a running run to stop; it settles as `cancelled`. @returns whether it was running. */
    cancel(id: string): boolean;
    /** Ask every running run to stop (fiber dispose). @returns how many were running. */
    cancelAll(): number;
}
/** Options for {@link newRunRegistry}. */
export interface RunRegistryOptions {
    io: EvolutionIoLike;
    /** Evolution home (`evolutionHome()`); the index lives at `<home>/runs.json`. */
    home: string;
    /** Warn channel for a failed index write (the run itself is unaffected). */
    warn?: (message: string) => void;
    /** Clock seam for tests. */
    now?: () => number;
    /** Retained records (N3-clamped). */
    maxRecords?: number;
}
/** Current index schema. Bump only for a structural change. */
export declare const RUNS_SCHEMA_VERSION = 2;
/** Retained run records, newest first. */
export declare const DEFAULT_RUN_RECORDS = 50;
/** Index path for a home. */
export declare function runsFile(home: string): string;
/**
 * Create the run registry for one mounted row.
 * @param options - io seam, evolution home, warn channel, clock and record cap.
 * @returns the registry; call {@link RunRegistry.load} once before answering reads.
 */
export declare function newRunRegistry(options: RunRegistryOptions): RunRegistry;
//# sourceMappingURL=run-registry.d.ts.map