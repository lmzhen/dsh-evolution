import type { Context } from '@deepseek-ai/cordis';
export declare const name = "evolution-restrictor";
export declare const inject: readonly ["agentPresets"];
export interface Config {
    readonly allow?: readonly string[];
    readonly deny?: readonly string[];
    /** Restricted preset id this row belongs to; only agents composed with it are restricted. */
    readonly presetId?: string;
}
export declare function apply(ctx: Context, config?: Config): void;
//# sourceMappingURL=restrictor.d.ts.map