/**
 * Deterministic skill curator: active → stale → archived transitions.
 * Pure function with one deliberate side effect: records in the passed
 * `usage` map are MUTATED (state/archived_at) to carry the transition — the
 * caller owns the map and decides whether to clone first (dry-run) or persist
 * after. File moves are performed by SkillLibrary.
 */
import type { UsageMap, UsageRecord } from './usage.ts';
import { EvolutionGateSet } from './gates.ts';
export { PROTECTED_BUILTIN_SKILLS } from './constants.ts';
export interface CuratorConfig {
    staleAfterDays: number;
    archiveAfterDays: number;
    /** Shorter stale threshold for quality-warned skills; archive threshold never changes. */
    qualityWarnStaleAfterDays?: number;
    /** Explicit skill names never considered for lifecycle transitions. */
    excludeSkillNames?: ReadonlySet<string>;
    /** When true, usage records without created_by='agent' also enter the lifecycle. */
    manageUnmanaged?: boolean;
    /** When true, bundled skills (in `bundledNames`) are curation candidates like agent-created ones. */
    pruneBuiltins?: boolean;
    /** Skill names carrying the bundled marker; only read when `pruneBuiltins` is true. */
    bundledNames?: ReadonlySet<string>;
    /** Skill names the curator archived once and must not fight across re-seeds. */
    suppressedNames?: ReadonlySet<string>;
    /** Skills referenced by scheduled/automated jobs: never auto-transitioned (idle clocks mislead for rarely-firing tasks). */
    referencedSkillNames?: ReadonlySet<string>;
}
export interface CuratorTransition {
    name: string;
    from: 'active' | 'stale' | 'archived';
    to: 'stale' | 'archived' | 'active';
    reason: string;
}
export interface CuratorResult {
    transitions: CuratorTransition[];
    archive: string[];
    reactivate: string[];
    markStale: string[];
}
export interface CuratorArchivedSkill {
    name: string;
    /** v28 G4.3 (CUR-03): the on-disk archive destination. OMITTED when the run
     * only knows the nominal `.archive/<name>` location — consolidation sources
     * archive through SkillLibrary.archive(), which stamps a
     * `<name>-<stamp>[-<rand>]` suffix on collision. A synthesized path sent
     * operators to a directory that may not exist; the real destination is on
     * the `evolution/skill-mutated` event (`archivedPath`). */
    path?: string;
    reason: string;
}
export interface CuratorFailedSkill {
    name: string;
    reason: string;
}
export interface CuratorRunReport {
    /** G3b: cross-index orphan landmarks -- report-only, never a verdict. */
    routeStubs?: {
        readonly skills: number;
        readonly stubs: number;
        readonly reason: string;
        readonly detail: readonly {
            readonly skill: string;
            readonly v: number;
            readonly owner: string;
            readonly reason: string;
        }[];
    };
    /** Report shape version; readers may ignore unknown fields on later versions. */
    schemaVersion: 1;
    runId: string;
    startedAt: string;
    finishedAt: string;
    staleCandidates: string[];
    llmNominations: string[];
    archiveCandidates: string[];
    archived: CuratorArchivedSkill[];
    /** Failures attributable to a SKILL NAME (`<name>: …`). V27 CUR-2: this field
     * is the skill-attributable subset only — run-level facts (an abort, a phase
     * that could not start) live in `aborted`/`unattributed` so a report can no
     * longer show `failed: 0` for a run that was cut short. */
    failed: CuratorFailedSkill[];
    /** V27 CUR-2: the run stopped early (e.g. disposed mid-run, timeout). The
     * string names the phase that did not complete; absent on a full run. */
    aborted?: string;
    /** V27 CUR-2: error strings that could not be attributed to a skill name.
     * They were previously collected in memory and then dropped on write. */
    unattributed?: string[];
    /** Consolidations actually executed this run (source absorbed into target). */
    consolidated?: CuratorConsolidation[];
    snapshotPath?: string;
    /** Whether the LLM nomination pass was enabled for this run (decision visibility). */
    llmReviewEnabled?: boolean;
    /** V6-35 (0.3.36): lenient-parse shape notes from the LLM nomination block. */
    nominationsWarnings?: string[];
    scanWarnings?: string[];
    /** 0.5.0 V1 (design §16.6-④): archived entries past the retention window that
     * the CURRENT policy keeps rather than deletes. Present (even empty) only when
     * the retention policy was `report`, so a report cannot read as "nothing
     * expired" for a run that pruned under a different policy. `null` means the
     * listing could not be read — unknown, never "nothing expired". */
    wouldPrune?: string[] | null;
}
export interface CuratorReportInput {
    runId: string;
    startedAt: string;
    finishedAt: string;
    staleCandidates: readonly string[];
    llmNominations: readonly string[];
    archiveCandidates: readonly string[];
    archived: readonly CuratorArchivedSkill[];
    failed: readonly CuratorFailedSkill[];
    /** V27 CUR-2: run-level abort reason (see CuratorRunReport.aborted). */
    aborted?: string;
    /** V27 CUR-2: errors with no skill name to attribute them to. */
    unattributed?: readonly string[];
    consolidated?: readonly CuratorConsolidation[];
    snapshotPath?: string;
    llmReviewEnabled?: boolean;
    nominationsWarnings?: readonly string[];
    scanWarnings?: readonly string[];
    wouldPrune?: readonly string[] | null;
}
export declare function buildCuratorRunReport(input: CuratorReportInput): CuratorRunReport;
/**
 * Render a curator run report as a compact human-readable markdown digest
 * (G6): run metadata first, then the notable sections (archived / failed /
 * stale candidates / LLM nominations).
 */
export declare function renderCuratorReportMarkdown(report: CuratorRunReport): string;
/** One LLM-nominated consolidation: `from` merges into the umbrella `into`.
 * `mode:'reference'` demotes the source (its body becomes
 * `references/<source>.md` under the umbrella) instead of appending to the
 * target body (009-II); absent means append. */
export interface CuratorConsolidation {
    from: string;
    into: string;
    mode?: 'append' | 'reference' | undefined;
}
/** Structured result of the optional curator LLM nomination pass. */
export interface CuratorNominations {
    prunings: string[];
    consolidations: CuratorConsolidation[];
    /** V6-35 (0.3.36): lenient-parse shape notes (an entry the lenient logic
     * silently dropped or re-routed). Parsing stays lenient — these are advisory
     * and flow into the run report so the operator sees why a mode or a pruning
     * went somewhere unexpected. */
    warnings: string[];
}
/**
 * Parse the curator LLM's YAML nomination block (consolidations + prunings).
 * Line-oriented and lenient by design: the LLM output is advisory, every name
 * is re-validated against the tree before any file move happens downstream.
 */
export declare function parseCuratorNominations(text: string): CuratorNominations;
/**
 * The lifecycle-candidate gate, shared by the transition engine and the scope
 * view so the two can never disagree: records failing ANY of these gates are
 * outside the managed scope.
 */
export declare function lifecycleCandidate(name: string, record: UsageRecord, config: CuratorConfig, bundled: boolean, gates?: EvolutionGateSet, protectedNames?: ReadonlyMap<string, string>): boolean;
export interface ScopeView {
    /** Skills inside the lifecycle scope right now (candidate gate + active state). */
    managed: string[];
    /** Managed skills already flagged stale or quality-warned — the ones to watch. */
    watched: string[];
    /** Managed skills flagged low quality (subset of `watched`) — consolidation candidates. */
    qualityWarned: string[];
    /** Explicitly exempted by excludeSkillNames / referencedSkillNames. */
    exempted: string[];
    /** Carrying a protection marker (pinned / bundled / hub-installed). */
    protected: string[];
}
/**
 * Read-only scope classification, derived from the SAME gate the transition
 * engine uses (`lifecycleCandidate`), so the view always predicts what a
 * curator pass may touch. `protectedNames` carries the marker info the usage
 * records lack (bundled / hub-installed / pinned from `SkillLibrary.list()`).
 */
export declare function computeScopeView(usage: UsageMap, config: CuratorConfig, protectedNames?: ReadonlyMap<string, string>, gates?: EvolutionGateSet): ScopeView;
export declare function computeLifecycleTransitions(usage: UsageMap, config: CuratorConfig, now?: Date, gates?: EvolutionGateSet, protectedNames?: ReadonlyMap<string, string>): CuratorResult;
//# sourceMappingURL=curator.d.ts.map