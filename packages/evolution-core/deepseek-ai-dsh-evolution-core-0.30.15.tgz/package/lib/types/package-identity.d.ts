/**
 * The scope segment of the nearest `package.json` at or above `from`.
 * @param from - the calling module URL (its own manifest is the answer).
 * @returns the scope, e.g. `@deepseek-ai` or `@lmzhen`; an unscoped manifest yields an empty string.
 */
export declare function scopeOfNearestManifest(from: string | URL): string;
/**
 * One family/platform package name under the RUNNING scope.
 * @param bareName - the name without any scope, e.g. `dsh-agent-preset`.
 * @param from - the calling module URL.
 * @returns `scope/bareName`, or `bareName` when the manifest carries no scope.
 */
export declare function scopedPackageName(bareName: string, from: string | URL): string;
//# sourceMappingURL=package-identity.d.ts.map