/**
 * Canonical type of a config field that may arrive as a live reference or a plain value.
 *
 * Spelled STRUCTURALLY on purpose: the platform's `Volatile<T>` (cordis) satisfies it for every payload
 * shape, so a field declared `Volatile<number | undefined>` and one declared `Volatile<number>` both pass
 * without the readers importing cordis or narrowing the payload. Where a plugin wants the
 * canonical spelling it may still write `Volatile<T>` in its own Config.
 */
export type LiveValue<T> = T | {
    get(): T | undefined;
} | undefined;
/**
 * Unwrap a live reference; return a plain value unchanged. The ONLY place that decides the shape.
 *
 * The discriminant is `typeof get === 'function'` rather than a bare `typeof value === 'object'`: a
 * config field may legitimately carry an object (a policy record), and calling `.get()` on that
 * used to throw where a plain read was meant.
 *
 * @param value - the field as supplied: live reference, plain value, or absent.
 * @returns the plain value, or `undefined` when the reference/field is absent.
 */
export declare function unwrapLive<T>(value: LiveValue<T>): T | undefined;
/** Options for {@link liveNumber}; the warning triple is all-or-nothing. */
export interface LiveNumberOptions {
    /** Inclusive lower bound; omit for no lower bound (0 is then a legitimate value). */
    readonly min?: number;
    /** Inclusive upper bound. */
    readonly max?: number;
    /** The keys this caller already warned about (caller-owned, so the warning stays once-per-key). */
    readonly warned?: Set<string>;
    /** The warning sink (each package prefixes its own name). */
    readonly warn?: (message: string) => void;
    /** The config key, for the warning text. Required together with `warned` and `warn`. */
    readonly name?: string;
}
/**
 * Read a numeric knob (live or plain) and clamp it, warning ONCE per key.
 *
 * @param value - the field as supplied: live reference, plain value, or absent.
 * @param fallback - the package default an invalid value falls back to.
 * @param opts - bounds plus the optional warning triple.
 * @returns the value the engine may use.
 */
export declare function liveNumber(value: LiveValue<number>, fallback: number, opts?: LiveNumberOptions): number;
/**
 * Clamp one numeric knob and warn ONCE per key — the pre-0.22 signature, kept as a thin adapter so
 * existing callers migrate one at a time instead of in one commit.
 *
 * @param warned - the keys this caller already warned about.
 * @param warn - the warning sink (each package prefixes its own name).
 * @param name - the config key, for the warning.
 * @param value - the value as supplied, or its live reference.
 * @param fallback - the package default a corrected value falls back to.
 * @param min - the smallest value the engine can act on.
 * @param max - the largest value the carrier can hold, when bounded.
 * @returns the value the engine may use.
 */
export declare function clampOnce(warned: Set<string>, warn: (message: string) => void, name: string, value: LiveValue<number>, fallback: number, min: number, max?: number): number;
/**
 * Read a boolean flag (live or plain). Absent ⇒ `fallback` (default `false`).
 *
 * The boolean counterpart of {@link liveNumber}: `value === true` is never true for a live
 * reference, which is the silent failure this reader exists to prevent.
 */
export declare function liveBool(value: LiveValue<boolean>, fallback?: boolean): boolean;
/**
 * Read a string (live or plain). Blank/whitespace counts as unset — the same rule `evolutionRoot` uses
 * for `DSH_HOME`.
 */
export declare function liveString(value: LiveValue<string>, fallback: string): string;
/**
 * Read an enumerated string (live or plain); a value outside `allowed` falls back.
 *
 * Used for the mode-like knobs (review mode, trigger, citation policy, write-confirm mode) where a
 * bare `?? default` would accept a typo the schema never saw.
 */
export declare function liveEnum<T extends string>(value: LiveValue<T>, allowed: readonly T[], fallback: T): T;
//# sourceMappingURL=live.d.ts.map