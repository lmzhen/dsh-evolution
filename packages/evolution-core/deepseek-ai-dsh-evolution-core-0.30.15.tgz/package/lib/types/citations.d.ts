/**
 * Citation resolution for skill bodies and support files (design §5.2).
 *
 * WHY this exists beside `supportRefs` (skill-store.ts): that scanner answers
 * "does this text contain a path-shaped token", which is the right question
 * when a package is being ARCHIVED — every such path may dangle — and the wrong
 * one when a section is only being MOVED, where nothing leaves and the only
 * thing that changes is the directory a citation is read from. Measured false
 * positives of the token scan: a URL tail (`https://host/references/x.md`), a
 * category path the original Hermes documents as legitimate
 * (`skills/scripts/foo.py`), and a prose command line
 * (`npm run scripts/build.mjs`).
 *
 * CONTRACT: a token whose path STARTS WITH a support directory is a citation of
 * this skill and is resolved from the SKILL ROOT, in whichever file it is
 * written. A token that merely contains a support directory further along its
 * path belongs to something else: it is reported as `foreign` and never
 * resolved.
 *
 * PURE: existence is decided against the caller's file list, so identical
 * inputs always answer the same report.
 */
/** Support directories that make a path a citation of the owning skill. */
export declare const CITATION_SUPPORT_DIRS: readonly string[];
/** How one path-shaped token was classified. */
export type CitationKind = 
/** Starts with a support directory: a citation of this skill. */
'citation'
/** Inside a fenced code block: illustrative, never resolved. */
 | 'fence'
/** Tail of a URL. */
 | 'url'
/** Contains a support directory further along its path (`skills/scripts/foo.py`). */
 | 'foreign'
/** A command line naming a path (`npm run scripts/build.mjs`). */
 | 'prose';
/** One scanned token with its classification and resolution. */
export interface CitationRef {
    /** The matched token, verbatim, after trailing sentence punctuation is stripped. */
    raw: string;
    /** 1-based line number in the scanned content. */
    line: number;
    /** Skill-root-relative target, or null when the token is not a citation of this skill. */
    target: string | null;
    /** The base a citation is read from; this scanner resolves the skill root only. */
    base: 'root';
    kind: CitationKind;
    /** Whether `target` names a file in the caller's file list. */
    exists: boolean;
    /** `#fragment` carried by the token, when present. */
    fragment?: string | undefined;
}
/** One scan of a body or support file. */
export interface CitationReport {
    refs: readonly CitationRef[];
    /** Citations whose target is provably absent from the file list. */
    dangling: readonly CitationRef[];
    /** Citations a non-recursive listing cannot decide (target sits under a listed directory). */
    unverified: readonly CitationRef[];
    /** Path-shaped tokens that are not citations of this skill (foreign/url/prose/fence). */
    foreign: readonly CitationRef[];
    /** True when the scan stopped at the budget: a partial report never reads as clean. */
    truncated: boolean;
}
/** Scan budget: bounded so a pathological body cannot stall a maintenance run. */
export declare const DEFAULT_CITATION_REF_BUDGET = 500;
/**
 * Resolve every path-shaped token in `content`.
 * @param input - content, the skill-root-relative path of its owner, the skill's
 *   file list, and an optional scan budget.
 * @returns the refs plus the dangling and foreign subsets; `truncated` marks a
 *   report that stopped at the budget.
 */
export declare function resolveCitations(input: {
    content: string;
    file: string;
    files: readonly string[];
    budget?: number | undefined;
}): CitationReport;
/** The sanctioned body hook (design §5.6): a list item whose payload is
 * exactly one support-file path, so the file stays discoverable in the body. */
export declare const HOOK_LINE_RE: RegExp;
/** The retirement escape hatch (design §5.6): a standalone body comment that
 * names the support file it exempts and the reason it must survive. The path
 * is part of the marker because the proposal list is per FILE, and a reason is
 * required — an unexplained exemption is what this hook exists to prevent. */
export declare const KEEP_LINE_RE: RegExp;
/** Whether a skill-relative path names a FILE rather than a directory: the same
 * rule the scanner applies to a token's final segment (`name.ext`). The support
 * listing is one level deep and includes directory entries (a real library has
 * `references/archive`), which no pointer or retirement list may treat as a file.
 * @param path - a skill-root-relative support path.
 * @returns true when the final segment is file-shaped.
 */
export declare function isFileShapedPath(path: string): boolean;
/** Result of one hook scan over a body. */
export interface BodyHookScan {
    /** Targets named by a sanctioned hook line, in file order, deduplicated. */
    targets: readonly string[];
    /** Target -> the reason its `keep` marker records. */
    kept: ReadonlyMap<string, string>;
}
/**
 * Scan a body for sanctioned hooks and `keep` markers.
 * @param content - the SKILL.md body (frontmatter included).
 * @returns hook targets plus the `keep` reasons keyed by target.
 */
export declare function scanBodyHooks(content: string): BodyHookScan;
//# sourceMappingURL=citations.d.ts.map