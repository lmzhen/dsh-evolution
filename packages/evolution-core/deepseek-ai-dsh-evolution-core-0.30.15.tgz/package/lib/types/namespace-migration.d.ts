/** One value a legacy section carried, with the spelling it used. */
export interface NamespaceMigrationValue {
    /** The key as the legacy document spelled it (canonical or deprecated alias). */
    readonly source: string;
    /** The canonical registry id the value is written under. */
    readonly key: string;
    /** The parsed value. */
    readonly value: unknown;
}
/** One row's migration target. */
export interface NamespaceMigrationEntry {
    /** The legacy section the values sit in. */
    readonly namespace: string;
    /** The row id the platform keys the settings by now. */
    readonly rowId: string;
    /** The values to merge into that row, in document order. */
    readonly values: readonly NamespaceMigrationValue[];
}
/** One legacy key no row may take. */
export interface NamespaceMigrationSkip {
    /** The legacy section it sat in. */
    readonly namespace: string;
    /** The key as spelled. */
    readonly key: string;
    /** Why it is not migrated. */
    readonly reason: string;
}
/** What a legacy document asks for. */
export interface NamespaceMigrationPlan {
    /** One entry per legacy section that carried values a row can take. */
    readonly entries: readonly NamespaceMigrationEntry[];
    /** Legacy sections the family knows but that carried nothing mappable. */
    readonly empty: readonly string[];
    /** Top-level sections that are not family legacy sections (the platform's own). */
    readonly foreign: readonly string[];
    /** Keys that were found but not migrated. */
    readonly skipped: readonly NamespaceMigrationSkip[];
}
/**
 * Read one legacy settings document into a migration plan.
 *
 * Pure: the caller reads the file (the platform's renamed `settings.yaml.imported` first,
 * then a `settings.yaml` the platform has not imported yet) and hands the text over.
 * @param documentText - the YAML document text.
 * @returns what to write, what the family knows but need not touch, and what it refused.
 * @throws {Error} when the document is not a mapping, or a family section is not one.
 */
export declare function planNamespaceMigration(documentText: string): NamespaceMigrationPlan;
/** One key the target row already carried. */
export interface NamespaceMigrationConflict {
    /** The row id. */
    readonly rowId: string;
    /** The canonical key. */
    readonly key: string;
    /** The value the stored row already holds — it wins. */
    readonly current: unknown;
    /** The legacy value that was NOT applied. */
    readonly legacy: unknown;
}
/** What one run did. */
export interface NamespaceMigrationReport {
    /** Rows the run wrote, with the keys it merged. */
    readonly written: readonly {
        readonly rowId: string;
        readonly keys: readonly string[];
    }[];
    /** Keys whose stored value won over the legacy one. */
    readonly conflicts: readonly NamespaceMigrationConflict[];
    /** Keys the target row already held the same value for: no write was needed. */
    readonly unchanged: readonly {
        readonly rowId: string;
        readonly key: string;
    }[];
    /** Keys the plan refused (see {@link NamespaceMigrationSkip}). */
    readonly skipped: readonly NamespaceMigrationSkip[];
}
/** Everything {@link applyNamespaceMigration} needs from its caller. */
export interface NamespaceMigrationDeps {
    /**
     * The row's CURRENT user layer, as `settings.describe()` reports it — the raw user
     * section, not the resolved value: presence of a key is what marks an override.
     * @param rowId - the row id.
     * @returns the describe view, or undefined when the platform serves no such row.
     */
    read(rowId: string): {
        readonly user?: Record<string, unknown> | undefined;
    } | undefined;
    /**
     * Merge one row's values (the platform's `settings.update` — merge semantics).
     * @param rowId - the row id.
     * @param patch - canonical key to value, the keys the row does not already carry.
     * @returns settlement after the write is accepted.
     */
    update(rowId: string, patch: Readonly<Record<string, unknown>>): Promise<void>;
    /**
     * Report one value that was found and not applied.
     * @param message - the warning text.
     */
    warn(message: string): void;
}
/** One row's pending write: the keys that row does not carry yet. */
export interface NamespaceMigrationWrite {
    /** The row id. */
    readonly rowId: string;
    /** Canonical key to legacy value, for the keys the row does not already hold. */
    readonly patch: Readonly<Record<string, unknown>>;
}
/** What a plan would do against the live document, decided without writing anything. */
export interface NamespaceMigrationClassification {
    /** The rows to write, one entry per row. */
    readonly write: readonly NamespaceMigrationWrite[];
    /** Keys whose stored value won over the legacy one. */
    readonly conflicts: readonly NamespaceMigrationConflict[];
    /** Keys the row already held the same value for. */
    readonly unchanged: readonly {
        readonly rowId: string;
        readonly key: string;
    }[];
    /** The plan's refusals, plus the keys of a row this composition does not serve. */
    readonly skipped: readonly NamespaceMigrationSkip[];
}
/**
 * Decide what a plan would do: the rows it would write, the keys already equal, the stored
 * values that win, and the refusals. The write half and the read-only doctor read the SAME
 * decision here — one rule, two consumers, so a report can never disagree with a run.
 * @param plan - the plan from {@link planNamespaceMigration}.
 * @param read - the row's current user layer (see {@link NamespaceMigrationDeps.read}).
 * @returns the decision; nothing is written.
 */
export declare function classifyNamespaceMigration(plan: NamespaceMigrationPlan, read: NamespaceMigrationDeps['read']): NamespaceMigrationClassification;
export declare function applyNamespaceMigration(plan: NamespaceMigrationPlan, deps: NamespaceMigrationDeps): Promise<NamespaceMigrationReport>;
//# sourceMappingURL=namespace-migration.d.ts.map