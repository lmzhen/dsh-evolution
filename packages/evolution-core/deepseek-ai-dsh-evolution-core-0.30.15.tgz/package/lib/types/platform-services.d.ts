/**
 * Every platform service the family reaches for with `ctx.get`, and what degrades without it.
 *
 * O-2 (v46 audit): the family probes 25 platform services optionally — the platform has no
 * formalized "optional dependency", so an ABSENT service is a silent downgrade and the diagnostic
 * surface is the only place a reader can learn about it. `/evolution doctor` used to judge six of
 * them; this table is the single source it judges the rest from, and the arch guard cross-checks it
 * against the actual probe sites so a new `ctx.get` cannot stay undeclared.
 *
 * `side` decides who can judge it: `host` probes run in the plugin process (doctor judges those),
 * `client` probes run in the browser half, where the host has no view of the seats.
 * @module @deepseek-ai/dsh-evolution-core
 */
/** One platform service the family probes, with the feature that goes quiet without it. */
export interface PlatformServiceProbe {
    /** The service key as `ctx.get` spells it. */
    readonly service: string;
    /** The family feature that silently degrades when the service is absent. */
    readonly feature: string;
    /** Where the probe runs. */
    readonly side: 'host' | 'client';
}
/** The 26 probes, in service-name order (the guard checks this list against the tree). */
export declare const PLATFORM_SERVICE_PROBES: readonly PlatformServiceProbe[];
/**
 * The HOST-side probes that do not resolve in this runtime — what `/evolution doctor` prints as
 * "capability absence". Empty is the normal, healthy answer: every capability the family can use
 * is mounted, and the section stays away.
 * @param has - a `ctx.get(name) !== undefined` probe of the running context.
 * @returns the absent host-side probes, in declaration order.
 */
export declare function absentHostServices(has: (name: string) => boolean): PlatformServiceProbe[];
//# sourceMappingURL=platform-services.d.ts.map