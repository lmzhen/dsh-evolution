/**
 * Deterministic review signal gate.
 *
 * Scans a DSH session event log for durable learning signals before any LLM
 * is spent. `turn/end` calls `observeEvent`; the returned review kind is
 * accumulated until a configured interval fires.
 */
import type { SessionEvent } from '@deepseek-ai/dsh-session';
export type ReviewKind = 'memory' | 'skill' | 'combined';
export interface SignalConfig {
    memoryInterval: number;
    skillInterval: number;
    substantiveMinToolCalls: number;
    substantiveMinUserChars: number;
    substantiveMinAgentChars: number;
    /** 0.3.40 (user decision): the counting window restarts at the INJECTION, not
     * at the threshold fire. `false` keeps the counters MONOTONIC across fires
     * (the `>=` check still returns the kind; the caller resets the counters at
     * its own injection point). Default `true` preserves the historical
     * fire-resets window for existing callers/tests. */
    resetOnFire?: boolean;
}
export interface TurnSignals {
    substantive: boolean;
    toolCalls: number;
    userChars: number;
    assistantChars: number;
    memorySignal: boolean;
    skillSignal: boolean;
}
export interface ReviewState {
    turnsSinceMemory: number;
    turnsSinceSkill: number;
    lastTurn: number;
}
/**
 * The turn-window fold state: what {@link TurnSignals} carries plus its dispatch ledger.
 *
 * `opened` holds one ledger key per dispatch this window already counted
 * ({@link dispatchStepOf}). It lives in the state — not in a side table — because the state is
 * what a live projection unit and a whole-log fold both carry between events.
 */
export interface TurnFoldState extends TurnSignals {
    /** Ledger keys this window already counted, in first-seen order. */
    opened: string[];
}
/** The empty turn-window fold state. */
export declare function initialTurnFold(): TurnFoldState;
/**
 * Fold ONE session event into a turn-window state, purely.
 *
 * The one fold behind all three readers: `observeEvent` (the mutating face the live `turn/end`
 * path uses), `foldTurn` (a whole-log window fold, kept for structural test sessions) and the
 * family's `evolutionSignals` projection unit. P1-1/N4 guards stay: events arrive from disk, so
 * a persisted `data: null` / non-object or a malformed `content` skips instead of throwing.
 * @param state - the window so far.
 * @param event - the next committed session event.
 * @returns the next state; the same reference when the event carries nothing this fold reads.
 */
export declare function foldTurnEvent(state: TurnFoldState, event: SessionEvent): TurnFoldState;
/**
 * Fold one session event into the current turn observation (the mutating face of
 * {@link foldTurnEvent}: every reader shares the one fold, this one copies the result back onto
 * the caller's signal object and keeps its ledger for the next event).
 * @param signal - the turn observation to advance.
 * @param event - the next committed session event.
 */
export declare function observeEvent(signal: TurnSignals, event: SessionEvent): void;
/** Compute review cadence after `turn/end`. */
export declare function advanceReview(state: ReviewState, turn: number, signal: TurnSignals, config: SignalConfig): ReviewKind | null;
/**
 * Fold a log slice into one turn window, purely.
 *
 * The whole-log reference for {@link foldTurnEvent}: a caller that holds events (a fixture, a
 * structural view, a replay) reads a window without touching a platform Session. Production reads
 * the same window live from the family's `evolutionSignals` projection (`sessionTurnSignals`),
 * which folds `foldTurnEvent` once per committed event.
 * @param events - the log, oldest first. Pass an array, not a live iterator, when it can grow.
 * @param fromSeq - index of the first event of the window (0 for the whole log).
 * @returns the window's signals.
 */
export declare function foldTurnEvents(events: Iterable<SessionEvent>, fromSeq?: number): TurnSignals;
//# sourceMappingURL=signals.d.ts.map