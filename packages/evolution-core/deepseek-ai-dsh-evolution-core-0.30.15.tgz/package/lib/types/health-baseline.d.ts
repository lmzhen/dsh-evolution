import { type LintFacts } from './skill-lint.ts';
export type Corpus = 'user' | 'platform';
export interface CorpusSkill {
    name: string;
    corpus: Corpus;
    facts: LintFacts;
}
export interface RuleAdmission {
    platformHits: number;
    userHits: number;
    userHitRate: number;
}
export interface HealthBaseline {
    /** Frozen unit and scope: a rate is only comparable when both are named (contract §4). */
    unit: 'chars';
    scope: 'references markdown file count';
    corpora: {
        user: number;
        platform: number;
    };
    values: Record<string, RuleAdmission>;
}
export interface AdmissionThresholds {
    /** A user-library hit rate below this is too rare to be worth a rule. */
    minUserHitRate: number;
    /** …and above this it is furniture (every skill trips it, so it carries no signal). */
    maxUserHitRate: number;
}
export declare const DEFAULT_ADMISSION: AdmissionThresholds;
export declare function buildHealthBaseline(skills: readonly CorpusSkill[]): HealthBaseline;
/** The admission verdict for ONE rule id (contract §4): platform corpus must not trip it, and the
 * user-library hit rate must land inside the band. Every failure names the number it failed on. */
export declare function admissionVerdict(baseline: HealthBaseline, ruleId: string, thresholds?: AdmissionThresholds): {
    admitted: boolean;
    failures: string[];
};
//# sourceMappingURL=health-baseline.d.ts.map