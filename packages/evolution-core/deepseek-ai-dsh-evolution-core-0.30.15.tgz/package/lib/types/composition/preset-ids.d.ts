export type RestrictedPresetKind = 'reviewer' | 'maintainer';
export declare const EVOLUTION_PRESET_IDS: readonly ["evolution", "evolution-ptc", "evolution-cordis", "evolution-minimal"];
export declare const REVIEWER_PRESET_ID: "evolution-reviewer-readonly";
export declare const MAINTAINER_PRESET_ID: "evolution-maintainer-readonly";
export declare const RESTRICTED_TOOLS_ROW_ID: "evolution-restricted-tools";
export declare const RESTRICTOR_MODULE: string;
export declare const RESTRICTED_PRESET_DELIVERY: "runtime" | "installer";
export interface RestrictedPresetDisplay {
    readonly name: string;
    readonly description: string;
    readonly order: number;
}
export declare const RESTRICTED_PRESET_DISPLAY: Readonly<Record<RestrictedPresetKind, RestrictedPresetDisplay>>;
export declare function restrictedPresetId(kind: RestrictedPresetKind): string;
/** Trim, drop blanks, de-duplicate and sort: ONE spelling for an allow/deny set. */
export declare function normalizeAllow(names: readonly string[]): readonly string[];
//# sourceMappingURL=preset-ids.d.ts.map