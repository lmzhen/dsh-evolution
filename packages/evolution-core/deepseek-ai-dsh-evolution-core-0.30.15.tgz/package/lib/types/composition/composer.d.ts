/**
 * Build the user-root Evolution preset composition from the RUNTIME platform's
 * `standard` preset rows plus the evolution delta rows (P1-1 follow-up,
 * 0.3.15): the agent-preset registry mounts ONE composition file verbatim, so
 * a delta-only `agent.cordis.yml` would produce an agent carrying only the
 * delta rows.
 *
 * Same contract as `install-layered.mjs` `generateAgentPreset` (the source
 * install path) — installer.spec pins byte parity between the two, and both
 * apply the identical row-collision contract: a delta id that overlaps a
 * standard row id fails loud by default, and `DSH_EVOLUTION_ALLOW_ROW_COLLISIONS=1`
 * downgrades it to a warning that keeps both (the row mounts twice).
 *
 * V10-14 / 0.3.53 (P1-2): BOTH composers now inject the Hermes 60-char catalog
 * cap onto the standard-sourced `- id: tool-skill` row of the composed preset
 * (see injectCatalogDescriptionCap) — the session-visible tool-skill instance
 * mounts in the preset's own standing scope, where no profile-root patch can
 * reach it. 0.3.53 moved the injection INTO the composer so
 * `/evolution preset install` (the npm user's only preset path) gets it too;
 * install-layered applies the byte-identical rule, pinned by installer.spec.
 *
 * Row ids are read from `- id:` lines; an id present in both fragments would
 * mount twice and could shadow the platform row, so it fails loud.
 * @param standardComposition - the runtime `standard` preset composition.
 * @param deltaComposition - the evolution delta fragment.
 * @returns the composed preset composition (standard rows first, then delta).
 */
export declare function composePresetComposition(standardComposition: string, deltaComposition: string): string;
/**
 * V10-14 (P1-2), 0.3.53: inject the Hermes 60-char catalog cap onto the
 * standard-sourced `- id: tool-skill` row of a composed preset.
 *
 * The session-visible `tool-skill` instance mounts in the agent preset's own
 * standing scope; a profile-root patch (evolution-host/cordis.patch.yml)
 * cannot reach it, so without this injection the catalog's read side runs the
 * platform default (500). Text-level rewrite in the same line-scan style as
 * compositionRowIds (no YAML library):
 *   - idempotent: a tool-skill item that already carries a `config:` key is
 *     left byte-identical, so re-running the installer never doubles the key;
 *   - the injected block carries a marker comment so a diff of the generated
 *     preset can tell composer-owned text from platform text;
 *   - a composition WITHOUT a tool-skill row is returned unchanged with a
 *     one-time warning (a renamed platform row must not brick the install,
 *     but the missed cap must be observable).
 * The source installer reads the SAME table (`row-overrides.json`) through its
 * own `injectToolSkillCap`, so the two paths cannot diverge (0.3.77).
 */
/** One entry of the shared override table (see {@link loadRowOverrides}). */
interface RowOverride {
    /** Top-level row id this override targets (`- id: <row>`). */
    row: string;
    /** The child key whose presence makes the override inert (idempotence). */
    key: string;
    /** Rendered, already-indented YAML lines to ensure inside the row. */
    lines: string[];
    /** Warning tail shared by both consumers; each prefixes its own logger tag. */
    missingReason: string;
}
/**
 * Read and validate the shared override table.
 * G6.1/M1: the path is a PARAMETER (default: the table beside this module). The source installer
 * runs the generated port from `scripts/`, so its own root has to be passed in — a module-relative
 * read would look for `scripts/../row-overrides.json` and fail.
 * @param path - the table to read.
 * @returns the entries, in file order. A malformed table fails LOUD: a composer
 * that silently skipped an entry would ship a preset running the platform
 * default while nothing downstream reported it.
 */
export declare function loadRowOverrides(path?: string): RowOverride[];
/**
 * Row ids of a composition fragment (line scan, no YAML library).
 *
 * PLAN S5.9 (2026-09-16, audit P2-27): the id extraction accepts INDENTED
 * `- id:` rows too, so a collision hidden in a nested group is still caught —
 * the old `^- id:` anchored at column 0 and was blind to exactly the rows an
 * upstream group nesting would produce. Twin of `rowIds` in
 * `scripts/install-layered.mjs` (installer.spec pins detection parity).
 * Boundary (current, deliberate): DETECTION covers nested rows, while the
 * override INJECTION anchors (`applyOneOverride` below) still match top-level
 * rows only — the injection indent contract (`^ {2}key:`) is defined against a
 * column-0 row.
 */
export declare function compositionRowIds(composition: string): Set<string>;
/** The platform package a DECLARATIVE preset row names (0.2.x replaced preset directories with it). */
export declare const AGENT_PRESET_PACKAGE: string;
/** Identity and display metadata of one generated preset row. */
export interface PresetRowIdentity {
    /** The composition row id (`- id:`); what {@link mergePresetRow} replaces by. */
    readonly rowId: string;
    /** The preset id the platform registry keys on (`evolution` / `evolution-ptc`). */
    readonly id: string;
    /** Display name in the preset picker. */
    readonly name: string;
    /** One-line description in the preset picker. */
    readonly description: string;
    /** Sort order among the registered presets. */
    readonly order: number;
}
/**
 * Compose the DECLARATIVE preset row from the platform base composition and the family delta.
 *
 * 0.2.x removed the directory mechanism: `dsh-agent-preset` is an ordinary composition row whose
 * `config.plugins` carries the preset's complete child plugin list
 * (`packages/preset/agent-preset/src/index.ts`, `agent-preset-registry/src/definition.ts` — the
 * definition has NO base/extends field, which is why the platform base is merged in here).
 *
 * The composition itself is {@link composePresetComposition}: same row-collision contract and the
 * same `row-overrides.json` injection, applied while the composed rows are still at column 0 — the
 * override anchors are defined against a column-0 `- id:` row, so the indentation that puts them
 * under `plugins:` must come last.
 * @param baseComposition - the platform base preset patch/composition rows.
 * @param deltaComposition - the family delta rows.
 * @param identity - row id, preset id, display fields and order.
 * @returns the row text, newline-terminated, ready to merge into a profile patch.
 */
/**
 * Drop the blank lines that merely separate block-sequence items, keeping the ones INSIDE a block
 * literal (`key: |` / `>`): there a blank line is part of the value, and filtering it flattened a
 * platform base preset's multi-paragraph prompt into one paragraph (G6 review, P1).
 * @param text - the composition rows.
 * @returns the rows with the separating blank lines removed.
 */
export declare function denseBlockSequence(text: string): string;
export declare function composePresetRow(baseComposition: string, deltaComposition: string, identity: PresetRowIdentity): string;
/**
 * Wrap a composed row as the patch entry a profile patch needs.
 *
 * The row {@link composePresetRow} returns starts at column 0; a patch entry's list nests it four
 * spaces deeper. Wrapping is a separate step because the same row text is also what
 * {@link mergePresetRow} matches by id, and because the composer's override anchors are defined
 * against column-0 rows.
 * @param row - the row text, as {@link composePresetRow} returns it.
 * @returns the patch entry text, newline-terminated.
 */
export declare function composePresetInsert(row: string): string;
/**
 * The row list a platform base preset patch carries under `config.plugins`, dedented to column 0.
 *
 * A base preset arrives as a whole patch entry — `- insert:` / `- id: preset-standard` /
 * `config:` / `plugins:` — because that is how the platform ships it
 * (`packages/bundle/web-app/presets/standard.patch.yml`). The preset's own list is the
 * SHALLOWEST `plugins:` line: a child row may carry a key by that name far deeper.
 * @param patchText - the base preset patch file's text.
 * @returns the plugin rows, dedented and newline-terminated.
 * @throws {Error} when the patch carries no `plugins:` list.
 */
export declare function basePresetPlugins(patchText: string): string;
/** The row id a family preset occupies: the platform ships \`preset-standard\` for id `standard`
 * (`packages/bundle/web-app/presets/standard.patch.yml`), so a family preset id mirrors it. */
export declare function presetRowId(id: string): string;
/**
 * The patch entry a profile patch receives for one preset: base rows plus the family delta, wrapped
 * as \`- insert:\`.
 *
 * The two halves are also exposed on their own — {@link composePresetRow} for the row, so
 * {@link mergePresetRow} can match it by id, and {@link basePresetPlugins} to read the platform
 * base out of a shipped patch.
 * @param basePatchText - the platform base preset patch's text.
 * @param deltaComposition - the family delta rows.
 * @param identity - row id, preset id, display fields and order.
 * @returns the patch entry text, newline-terminated.
 */
export declare function composePresetEntry(basePatchText: string, deltaComposition: string, identity: PresetRowIdentity): string;
/**
 * The text of one row's own patch item, or null when the patch carries no such row.
 *
 * The comparison unit for a freshness check: this is byte-for-byte what {@link composePresetEntry}
 * writes for the same row id, whether the row sits inside an \`- insert:\` entry (installer-written)
 * or at column 0 (saved by the Web editor).
 * @param patchText - the patch text.
 * @param rowId - the row id to read.
 * @returns the item's text, newline-terminated, or null.
 */
export declare function presetRowBody(block: string): string;
/**
 * The row BODY of a patch block, whichever form it is in.
 *
 * {@link presetRowBlock} returns the enclosing item verbatim: an installer-written row sits inside
 * `- insert:` while a row the platform's Web editor saved IS that column-0 item. A comparison must
 * compare like with like — comparing the raw block against `composePresetEntry()` (which always
 * starts with `- insert:`) reported DIFFERS for every editor-saved row, forever (G6 review, P2), and
 * the remedy it printed (`re-run the installer`) was refused by the `exists; use --force` guard.
 * @param block - a block as {@link presetRowBlock} returns it.
 * @returns the row text, `- insert:` unwrapped and its four-space indent stripped.
 */
export declare function presetRowBlock(patchText: string, rowId: string): string | null;
/**
 * What `DSH_AGENT_PRESET_ROOT` must name: a directory holding the platform base preset patches
 * under their shipped file names (`<base>.patch.yml`) — e.g. a copy of a same-version platform
 * tree's `packages/bundle/web-app/presets/`. The desktop application is the shape that needs it:
 * its platform packages live inside `resources/app.asar`, so there is no plain
 * `node_modules/@deepseek-ai/dsh-web-app/presets/` on disk for a source installer to read.
 */
export declare const AGENT_PRESET_ROOT_HINT = "point DSH_AGENT_PRESET_ROOT at a directory holding <base>.patch.yml (copy it out of a same-version dsh tree: packages/bundle/web-app/presets/)";
/** Where {@link resolveBasePresetPatch} looks, in order. */
export interface BasePresetPatchSources {
    /** Explicit preset root (`DSH_AGENT_PRESET_ROOT`); an ANSWER, never a fallback head. */
    readonly root?: string | undefined;
    /** Module-graph probe for the bundle package — the only candidate that reaches inside an Electron
     * `app.asar`. Receives `@deepseek-ai/dsh-web-app/package.json` and returns its path. */
    readonly resolve?: ((specifier: string) => string) | undefined;
    /** Target profile directory; its `node_modules` holds the bundles it mounts. */
    readonly profileDir?: string | undefined;
    /** Bundle package names to probe under `<profileDir>/node_modules`. */
    readonly bundles?: readonly string[] | undefined;
    /** Directory the ancestor walk starts from — the caller's own file location. */
    readonly fromDir: string;
}
/**
 * Resolve the platform patch file one `--base` names.
 *
 * 0.2.x ships each base preset as a bundle patch layer
 * (`packages/bundle/web-app/presets/<base>.patch.yml`, declared in that package's
 * `dsh.bundle.patch`), so the FILE — not a preset directory — is the base a family row is composed
 * from. Candidates, in order: an explicit `DSH_AGENT_PRESET_ROOT`; a module-graph probe when the
 * caller supplies one (a desktop/Electron host resolves the bundle inside `app.asar`, where no file
 * walk can reach); the target profile's own `node_modules`; then, walking up from the caller,
 * every `presets/` directory of a checkout's bundle packages, then every
 * `@deepseek-ai/dsh-<name>/presets/` directory of an installed tree.
 *
 * A base with no patch file is REFUSED with every probed candidate listed: composing a family preset
 * from another base's rows would mount rows the user did not ask for, with nothing saying so.
 * @param base - the base name, already validated against `evolution-agent/bases.json`.
 * @param sources - the roots to probe.
 * @returns the patch file's absolute path.
 * @throws {Error} when no candidate exists.
 */
export declare function resolveBasePresetPatch(base: string, sources: BasePresetPatchSources): string;
/**
 * Probe every `@deepseek-ai/dsh-*` package under one unpacked resource root.
 * @param resourceRoot - e.g. `<install>/resources/app.asar.unpacked`.
 * @param file - the patch file name to look for.
 * @param probes - the caller's probe log, appended to for the failure report.
 * @returns the patch path when one exists.
 */
export declare function probeDesktopScope(resourceRoot: string, file: string, probes: string[]): string | undefined;
/**
 * Subdirectories of one directory, or none when it does not exist: a missing level is an ordinary
 * miss on a candidate walk, not a failure.
 * @param dir - the directory to list.
 * @returns the directory names.
 */
export declare function listDirectories(dir: string): string[];
/**
 * The block of one row id: the enclosing column-0 list item and the row's own first line.
 *
 * An installer-written row sits inside `- insert:` (four spaces deeper); a row the Web editor
 * saved is that column-0 item itself. Both must be replaced whole, so the span reaches back to the
 * enclosing item and forward to the next one.
 * @param lines - the patch text's lines.
 * @param rowId - the row id to locate.
 * @returns the span, or null when the patch carries no such row.
 */
export declare function rowBlockSpan(lines: string[], rowId: string): {
    start: number;
    end: number;
    rowStart: number;
} | null;
/**
 * Remove one row from a patch, taking its `- insert:` item with it when that item holds nothing
 * else (an empty insert entry is left-over structure the platform would keep parsing).
 * @param patchText - the patch text to edit.
 * @param rowId - the row id to remove.
 * @returns the patch text, newline-terminated; byte-identical when the id is absent.
 */
export declare function removePresetRow(patchText: string, rowId: string): string;
/**
 * The end of one nested row's own block inside a patch entry.
 * @param lines - the patch text's lines.
 * @param rowStart - the row's `- id:` line.
 * @param itemEnd - the enclosing item's end.
 * @returns the index of the next sibling row, or the item's end.
 */
export declare function rowSiblingEnd(lines: string[], rowStart: number, itemEnd: number): number;
/**
 * Merge one generated row into a composition (a profile patch) by row id.
 *
 * Idempotent by construction: an existing row with the same `- id:` is REPLACED whole — its block
 * is the enclosing column-0 list item, so an installer-written row inside `- insert:` and a
 * Web-editor-saved row at column 0 are both matched by {@link rowBlockSpan} — and anything else in
 * the patch stays byte-identical, because the patch usually carries rows this installer knows
 * nothing about. A missing row is appended.
 *
 * The platform seeds a fresh profile patch with the empty list `[]`
 * (`packages/boot/app-boot/src/profile.ts`, `PROFILE_PATCH_FILENAME`), which is a COMPLETE YAML
 * document: a block sequence appended after it is not parsable. That seed is therefore replaced, not
 * extended.
 * @param patchText - the current patch text (`''` for a fresh one).
 * @param row - the row text, as {@link composePresetRow} returns it.
 * @param rowId - the row id to replace or append.
 * @returns the merged patch text, newline-terminated.
 */
export declare function mergePresetRow(patchText: string, row: string, rowId: string): string;
/** The empty patch list the platform seeds a profile patch with; see {@link mergePresetRow}. */
export declare const EMPTY_PATCH_SEED = "[]";
/** Drop trailing blank lines only: a kept line's own terminator (a CRLF file's `\r`) is never touched. */
export declare function trimTrailingBlankLines(lines: string[]): string[];
/**
 * The text to write when a patch is left with no entries.
 *
 * A zero-byte patch file is not what the platform writes or parses; its own seed is the empty list.
 * @param patchText - the text {@link removePresetRow} returned.
 * @returns the platform's empty-list seed when nothing is left, the text otherwise.
 */
export declare function presetPatchText(patchText: string): string;
export {};
//# sourceMappingURL=composer.d.ts.map