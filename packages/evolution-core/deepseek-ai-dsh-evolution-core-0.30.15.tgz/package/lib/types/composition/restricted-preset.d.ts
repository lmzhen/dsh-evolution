import * as yaml from 'js-yaml';
export declare const entryListSchema: yaml.Schema;
import { type RestrictedPresetKind } from './preset-ids.ts';
export interface PresetDocumentLike {
    readonly agentPreset: string;
    readonly content: string;
}
export interface PresetRegistryLike {
    readDocument(agentPreset: string): Promise<PresetDocumentLike>;
    register(definition: RestrictedPresetDefinition): Promise<() => Promise<void>>;
}
export interface RestrictedPresetDefinition {
    readonly id: string;
    readonly name: string;
    readonly description: string;
    readonly order: number;
    readonly plugins: readonly unknown[];
}
export interface RestrictedPresetRequest {
    readonly kind: RestrictedPresetKind;
    readonly parentPresetId: string;
    readonly allow: readonly string[];
}
export type RestrictedPresetState = {
    readonly kind: 'ready';
    readonly presetId: string;
    readonly parentPresetId: string;
    readonly allow: readonly string[];
} | {
    readonly kind: 'failed';
    readonly code: 'E-324';
    readonly reason: string;
};
export declare function parsePresetRows(content: string): readonly unknown[];
export declare function composeRestrictedPresetDefinition(source: PresetDocumentLike, req: RestrictedPresetRequest): RestrictedPresetDefinition;
//# sourceMappingURL=restricted-preset.d.ts.map