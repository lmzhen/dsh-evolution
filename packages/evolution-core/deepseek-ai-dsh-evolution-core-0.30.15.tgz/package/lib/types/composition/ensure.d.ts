import type { Context } from '@deepseek-ai/cordis';
import { type RestrictedPresetRequest, type RestrictedPresetState } from './restricted-preset.ts';
export interface EnsureRestrictedPresetArgs extends RestrictedPresetRequest {
}
export declare function ensureRestrictedPreset(ctx: Context, req: EnsureRestrictedPresetArgs): Promise<RestrictedPresetState>;
/** Read-only view of the current registration (doctor runtime row). */
export declare function restrictedPresetState(ctx: Context, kind: RestrictedPresetRequest['kind']): RestrictedPresetState | undefined;
/** Release the registration for one kind (HMR/tests); the fiber effect also calls this. */
export declare function disposeRestrictedPreset(ctx: Context, kind: RestrictedPresetRequest['kind']): Promise<void>;
//# sourceMappingURL=ensure.d.ts.map