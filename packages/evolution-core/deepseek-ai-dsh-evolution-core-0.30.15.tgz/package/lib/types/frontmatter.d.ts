/**
 * Frontmatter parsing, normalization and validation for skill Markdown files.
 *
 * Split out of skill-store.ts (S2-1): pure functions over file text, no store
 * state. skill-store.ts re-exports the same names it exported before the split,
 * so the package export surface is unchanged.
 */
import type { SkillLimits } from './limits.ts';
export interface Frontmatter {
    name?: string;
    description?: string;
    [key: string]: unknown;
}
export declare function frontmatterBlock(content: string): {
    block: string;
    lines: string[];
    end: number;
    nl: string;
} | null;
/**
 * One frontmatter read (V27 G2.1): the values, the body, and every signal the
 * strict-YAML platform catalog derives from the same block. Returned by
 * {@link parseFrontmatter} so a caller never has to parse the block twice to
 * reach a description and the catalog verdict.
 */
export interface FrontmatterRead {
    frontmatter: Frontmatter;
    /** P0′: the structured `metadata:` mapping, when the strict parser loaded one.
     * Published as an OBJECT (never stringified): nested mappings used to be dropped
     * because a lossy string could be picked up by a routing field — keeping it
     * structured removes that risk while giving the one consumer the nested
     * `metadata.hermes.related_skills` form the real corpus actually writes. */
    metadata?: Record<string, unknown> | undefined;
    body: string;
    /** Raw entries whose UNQUOTED value the strict catalog cannot load as
     * written. Quotes are included, so a value already normalized by the write
     * path (`normalizeFrontmatter`) is never re-flagged. */
    unsafeValues: Array<{
        key: string;
        value: string;
    }>;
    /** Whether the frontmatter is not valid AS WRITTEN for the strict platform
     * catalog: the strict parser rejects the block, or an unquoted value would
     * read as something other than its text (a dropped ` # ` comment, a
     * number/bool shorthand the catalog refuses as a string field), or a
     * platform string field carries a non-string value. The write path quotes
     * such a value on its next edit. */
    catalogInvalid: boolean;
    /** Platform string fields (`name`/`description`/`whenToUse`) whose YAML value
     * is not a string: the strict catalog reads such a field as ABSENT and, for an
     * absent name/description, ignores the whole file (P2-9/v37). */
    platformStringSplit: PlatformStringSplit[];
}
/** One `name`/`description`/`whenToUse` entry the strict catalog cannot read as
 * a string, with the YAML kind the parser found. */
export interface PlatformStringSplit {
    key: string;
    /** The YAML type read for this field. `scalar` covers number/boolean (the
     * E-47 auto-quote repair handles those); `sequence`/`mapping` are the shapes
     * no rewrite can repair without inventing text — see `validateFrontmatter`. */
    kind: 'sequence' | 'mapping' | 'scalar' | 'null';
}
/**
 * Parse a SKILL.md: its frontmatter values and body, or `null` when the file
 * has no frontmatter block or no body. Every consumer of frontmatter values
 * goes through here — the write path's validation, `list()`'s published
 * description, `relatedSkillNames` and the audit — so all of them read the same
 * bytes the same way.
 *
 * @param content - the SKILL.md text.
 * @returns the read, or `null` when there is no block or no body.
 */
export declare function parseFrontmatter(content: string): FrontmatterRead | null;
/**
 * Whether this file's frontmatter is valid as written for the strict platform
 * catalog (see `FrontmatterRead.catalogInvalid`). Body-independent (a body-less
 * file is still judged), and derived from the same read as `parseFrontmatter` —
 * so the audit's verdict and the values the family publishes for one file can
 * never disagree (V27 G2.1).
 *
 * @param content - the SKILL.md text.
 * @returns `true` when the strict parser rejects the block or an unquoted value would read as something else.
 */
export declare function frontmatterCatalogInvalid(content: string): boolean;
/** YAML plain-scalar hazards that make an UNQUOTED frontmatter value
 * unloadable to the platform catalog (strict YAML parser): `: ` (mapping
 * separator), ` #` (comment start), a trailing `:` (a mapping marker),
 * or a leading YAML indicator. The evolution `parseFrontmatter` is
 * deliberately lenient, so violations silently split family-visibility from
 * platform-visibility (0.3.11 inkos-harness case: the description carried
 * "…: " and the catalog dropped the whole skill). Already-quoted values and
 * well-formed flow collections (`[a, b]` / `{a: b}`) are considered safe.
 * 0.3.16 (E-47): null/bool/number-shaped plain scalars are flagged too — they
 * parse as booleans/numbers on the platform while the family keeps the string
 * (a `description: true` split-brain).
 * This rule is only the FAST PATH — the write path re-verifies every rewrite
 * with the real YAML parser (see normalizeFrontmatter), so an incomplete
 * approximation can never corrupt a multiline flow value (P3-4). */
export declare function yamlPlainScalarNeedsQuotes(value: string): boolean;
export interface FrontmatterNormalizeResult {
    content: string;
    changed: boolean;
    /** Frontmatter keys whose values were auto-quoted. */
    fields: string[];
    /** Values that cannot be auto-quoted safely (control characters, or a
     * rewrite that failed the real-parser verification — a multiline flow
     * collection line etc. is left untouched and reported here, so the write
     * path rejects instead of silently damaging a value; 0.3.14). */
    issues: string[];
}
/**
 * Normalize a SKILL.md frontmatter block into catalog-loadable YAML: values
 * that YAML forbids unquoted get quotes — double quotes normally, single
 * quotes (with `''` doubling) when the value contains `"` or `\` (both legal
 * unescaped inside single-quoted YAML). Idempotent; only single-line
 * `key: value` entries are touched; body text is never modified; line-ending
 * style is preserved. **Every rewrite is re-verified with the real YAML
 * parser** (`yaml` — the package the platform's skill-filesystem catalog parses
 * with, YAML 1.2 core schema; PLAN S2.1, 2026-09-16 — the former "js-yaml, the
 * same parser" claim was false: js-yaml speaks YAML 1.1 full and diverged on
 * dates, timestamps and 1.1 int forms): if the
 * rewritten block no longer parses, or a rewritten value's parsed content
 * differs from the original, the rewrite is rolled back and reported in
 * `issues` (fail-loud, never a silent value corruption — P3-4).
 *
 * V10-02 (P2-3): the rewrite decision is PER LINE — each entry parses its own
 * value, so a duplicated key can never route one entry's unsafe value into a
 * different line's rewrite (the old key→Map lookup rewrote the FIRST (safe)
 * line with the SECOND line's quoted value, and the last-wins YAML reader
 * masked the damage). A duplicated key is itself invalid input and is
 * reported in `issues` (the write path refuses) instead of being rewritten.
 */
export declare function normalizeFrontmatter(content: string): FrontmatterNormalizeResult;
/**
 * Skill names referenced by a SKILL.md's `related_skills` frontmatter
 * (B-line G3, rc.44): the single parsing source for the quality references
 * factor and the learning-graph edges. The DSH frontmatter parser keeps the
 * YAML value as a string (`"[a, b]"`), so names are scanned out of it; each
 * must satisfy the skill-name shape and the referencing skill itself is
 * excluded. Pure and deduplicated.
 */
export declare function relatedSkillNames(content: string, exclude?: string): string[];
/** S1.2 (v37 P2-1): the content limit applies to the bytes that LAND ON DISK.
 * Every write normalizes with `trimEnd() + '\n'`, so judging the raw argument let
 * a 100_000-character body with no trailing newline land as 100_001 bytes — and
 * every later patch/update of that skill was then refused, which made it
 * unmaintainable through `skill_manage` with no repair path at all. */
/** The bytes that land on disk for a SKILL.md write — the ONE accounting basis
 * shared by the content limit and the cost estimate (design §5.2). */
export declare function skillMdOnDisk(content: string): string;
/** Whether `content` would exceed `limit` once written. */
export declare function exceedsContentLimit(content: string, limit: number): boolean;
/** S1.2: the repair path — a write that makes an already-over-limit file smaller.
 * Only a NET SHRINK is exempt; an equal or larger write stays refused. */
export declare function shrinksOverLimit(next: string, current: string | null | undefined, limit: number): boolean;
export declare function validateFrontmatter(content: string, expectedName?: string, limits?: SkillLimits, 
/** On-disk bytes, so a NET SHRINK of an over-limit file is allowed (S1.2). */
current?: string | null): string | null;
/** Hermes authoring quality bar for descriptions — see constants.ts
 * (0.3.16 T-4 moved the single source there; the public re-export sits behind
 * the package root, which re-exports constants anyway). */
export interface AuthoringFeedback {
    /** Frontmatter description length in characters (0 when absent). */
    descriptionChars: number;
    /** Whether the description exceeds the authoring bar (60) while still passing the platform limit. */
    over60: boolean;
    /** Whether the description contains a colon (the standard requires double-quote wrapping). */
    hasColon: boolean;
    /** Advice lines appended to mutation success messages. */
    lines: string[];
}
/**
 * Advisory authoring feedback (P0): evaluate frontmatter against the
 * authoring bar WITHOUT changing platform validation semantics. The bar is
 * the quality target, `validateFrontmatter`'s limits are the compatibility
 * floor, and this bridge layer tells the model when its text would be
 * truncated or route-poor instead of silently shipping it.
 */
export declare function authoringFeedback(frontmatter: Frontmatter): AuthoringFeedback;
/** A1-15 (v18) / P2-2 (v19): the io layer marks an error `committed: true` when
 * the rename landed and only the directory fsync failed. Every single-file
 * writer must treat that as "written, durability unconfirmed" — never as a
 * plain failure (which a caller would retry, or a two-phase caller roll back).
 * v28 G2.1 (EVO-IO-05): this is a delegation to the seam's own
 * `isCommittedWarning` — the marker predicate has exactly one definition. */
//# sourceMappingURL=frontmatter.d.ts.map