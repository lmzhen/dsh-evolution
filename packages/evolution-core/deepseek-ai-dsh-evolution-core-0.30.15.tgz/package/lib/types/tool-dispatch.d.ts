/**
 * The family's ONE reader of platform tool-dispatch events.
 *
 * The platform records a finished tool call under two different event
 * vocabularies and only one of them is written per dispatch, chosen by the
 * mounted tool runtime's mode:
 *
 * - native mode: \`tool/call\` (with \`callId\`) settled by \`tool/result\`, the
 *   write sites being core/agent-loop/src/tool-calls.ts:264 and :282.
 * - PTC mode: \`tool/ptc-dispatch-start\` and \`tool/ptc-dispatch\` (with
 *   \`subCallId\`), the write sites being core/tools/src/ptc.ts:534 and :509.
 *
 * A consumer that matches a vocabulary directly therefore goes blind in the
 * other mode while still appearing to work — the defect this module exists to
 * make impossible. Every family consumer reads dispatches through
 * \`ToolDispatchNormalizer\` (or the pure helpers below) and matches on
 * \`ToolDispatchSignal\` fields only; \`verify-arch-guards\` rule N11 rejects a
 * dispatch event-type comparison anywhere else.
 *
 * ## The one-dispatch invariant
 *
 * One dispatch produces exactly one \`ToolDispatchSignal\`, no matter how many
 * events carry it: a start/settle pair for a PTC sub-dispatch, a call/result
 * pair for a native call, or both vocabularies for the same call. Deduplication
 * and outcome folding are keyed by the platform's own per-vocabulary call
 * identity, which is stable across the pair (the platform's event JSDoc:
 * "the pairing ids (matching the \`tool/ptc-dispatch-start\` with the same
 * \`subCallId\`)").
 *
 * ## Layer
 *
 * Cross-cutting normalization: the reader half of the dispatch vocabulary,
 * next to \`signals.ts\` (which folds the signals this module emits). Both are
 * consumers; neither subscribes to the platform bus itself.
 * @module
 */
/** How the platform delivered one dispatch. */
export type ToolDispatchKind = 
/** A model-authored call, logged as \`tool/call\` and settled by \`tool/result\`. */
'native'
/** A sub-dispatch of a code program, logged as the PTC dispatch pair. */
 | 'program';
/** The platform event type carrying a PTC sub-dispatch start. */
export declare const PTC_DISPATCH_START_EVENT = "tool/ptc-dispatch-start";
/** The platform event type carrying a PTC sub-dispatch settle. */
export declare const PTC_DISPATCH_EVENT = "tool/ptc-dispatch";
/** The platform event type carrying a native tool call. */
export declare const NATIVE_CALL_EVENT = "tool/call";
/** The platform event type carrying a native tool result. */
export declare const NATIVE_RESULT_EVENT = "tool/result";
/**
 * The dispatch vocabulary this module owns. A consumer must never compare
 * against these literals itself (rule N11); it compares \`kind\` instead.
 */
export declare const DISPATCH_EVENT_TYPES: readonly string[];
/**
 * Model-visible session frames: the message types plus the ONE dispatch vocabulary above.
 * Consumers classify through this list instead of naming event literals (rule N11).
 */
export declare const MODEL_SESSION_EVENT_TYPES: readonly string[];
/**
 * One normalized tool dispatch.
 *
 * Every field is derived from a platform event payload; the record is mutable
 * and is updated in place when a later event of the same dispatch settles it,
 * so a consumer that reacted at start already holds the outcome.
 */
export interface ToolDispatchSignal {
    /** \`native\` | \`program\` (a code-program sub-dispatch); the \`run_code\` root itself reads as \`native\`. */
    readonly kind: ToolDispatchKind;
    /** \`callId\` for a native call, \`subCallId\` for a PTC sub-dispatch — the platform's own identity. */
    readonly callId: string;
    /** The outer call: \`parentCallId\` for a PTC sub-dispatch, the call's own id for a native call. */
    readonly rootCallId: string;
    /** Dispatched tool name, always a non-empty string. */
    readonly name: string;
    /** Arguments as dispatched: a JSON string in native mode, the normalized object in PTC mode. */
    readonly arguments: unknown;
    /** Settled outcome: \`true\` succeeded, \`false\` failed, \`undefined\` still in flight. */
    ok: boolean | undefined;
}
/**
 * \`TypeError\` thrown when a payload that claims to be a dispatch event
 * violates the platform's event declaration. Named so a deployment can tell this
 * refusal apart from a generic failure in a log line.
 */
export declare class ToolDispatchPayloadError extends TypeError {
    name: string;
}
/**
 * The ledger key of one dispatch: a scope-qualified call id.
 *
 * v43 audit (FLOW4-4): a normalizer shared by every session (skill-usage's live listener holds ONE
 * process-wide instance) used the bare call id, so two sessions that produced the same id — PTC
 * sub-call ids are short, and an id-less payload falls back to a type+payload key that is not
 * unique by construction — collided: the second session's read was absorbed as "already seen" and
 * never counted, and a settle in one session flipped the other's `ok`. Callers that span sessions
 * pass the session id as `scope`.
 * @param callId - the dispatch's call id (or its payload-derived fallback).
 * @param scope - the owning session id, or '' for a fold that never leaves one session.
 * @returns the key both the ledger and every projection fold dedupe on.
 */
export declare function dispatchKeyOf(callId: string, scope?: string): string;
/**
 * The pure half of the ledger: what one event says about one dispatch.
 *
 * The DECISION (which dispatch, and whether this event is the one that opens it) lives here and
 * only here; carriers differ in what they keep — the class below keeps consumer-visible mutable
 * signals, the family's `evolutionReads`/`evolutionSignals` projection units keep plain-JSON
 * ledgers. `name` is empty on an event that only settles an already-opened dispatch (a native
 * `tool/result`), and `outcome` is present exactly when the event carried one.
 * @param event - one session event; any non-dispatch event answers `null`.
 * @param scope - the owning session id, or '' for a single-session fold.
 * @returns the step, or `null` when the event is not a dispatch.
 */
export declare function dispatchStepOf(event: {
    type: string;
    data?: unknown;
}, scope?: string): DispatchStep | null;
/** One ledger step: what one event tells a fold about one dispatch. */
export interface DispatchStep {
    /** The scoped ledger key ({@link dispatchKeyOf}). */
    readonly key: string;
    /** How the platform logged this dispatch (native call or PTC program). */
    readonly kind: ToolDispatchKind;
    /** The dispatch's call id, unscoped. */
    readonly callId: string;
    /** The program root this dispatch belongs to (its own id for a native call). */
    readonly rootCallId: string;
    /** The dispatched tool name; empty when the event only settles a dispatch. */
    readonly name: string;
    /** Raw arguments as logged (a JSON string natively, an object in PTC mode). */
    readonly arguments: unknown;
    /** Present exactly when the event carried an outcome. */
    readonly outcome?: {
        readonly ok: boolean;
    };
}
/**
 * The family's single dispatch ledger: absorbs platform events in log order,
 * emits one \`ToolDispatchSignal\` per dispatch, and folds later events of the
 * same dispatch into the record it already emitted.
 *
 * Consumers keep the \`ToolDispatchSignal\` object they received and re-read it
 * later; no consumer needs to correlate events itself.
 */
export declare class ToolDispatchNormalizer {
    private readonly records;
    /** S2-P2-14: cap for the LEDGER (and the settle markers) — opt-in, meant for
     * the long-lived live listener (skill-usage) whose ledger is pure dedup
     * state and would otherwise grow with the process lifetime. `Infinity` (the
     * default, used by whole-log folding) keeps every dispatch. Eviction is
     * oldest-first: a call/result pair spans one tool call, so an evicted
     * dispatch can never be re-paired within any realistic window. */
    private readonly maxTracked;
    /** S2-P2-12: call ids whose outcome has already been reported to the settle
     * channel — a replayed result event must not settle the same dispatch twice. */
    private readonly settledIds;
    constructor(options?: {
        maxTracked?: number;
    });
    /**
     * Absorb one session event.
     * @param event - the event to absorb; any non-dispatch event is ignored.
     * @returns the dispatch's signal when this event FIRST reveals the dispatch,
     * otherwise \`null\` (the paired event of an already-emitted dispatch, or a
     * non-dispatch event). A \`null\` return is never a dispatch to count again.
     */
    advance(event: {
        type: string;
        data?: unknown;
    }, scope?: string): ToolDispatchSignal | null;
    /**
     * S2-P2-12: the SETTLE channel. \`advance\` answers \`null\` for the paired
     * event that settles an already-emitted dispatch, so a consumer that must act
     * on the OUTCOME (e.g. count successful skill reads only) cannot tell which
     * dispatch a \`null\` belonged to. Call this with the same event AFTER
     * \`advance\`: it answers the settled dispatch exactly once (replayed settle
     * events answer \`null\`).
     * @param event - the event already absorbed by \`advance\`.
     * @returns the dispatch this event settled, or \`null\`.
     */
    settledSignalOf(event: {
        type: string;
        data?: unknown;
    }, scope?: string): ToolDispatchSignal | null;
    /** Oldest-first eviction once the ledger (or the settle markers) overflows. */
    private evict;
    /** Every emitted dispatch, in first-seen order. */
    get signals(): readonly ToolDispatchSignal[];
    /**
     * Fold every event of a session log, in order.
     * @param events - the log, oldest first.
     * @returns one signal per dispatch, in first-seen order.
     */
    foldAll(events: Iterable<{
        type: string;
        data?: unknown;
    }>): ToolDispatchSignal[];
}
/**
 * Read one event into a dispatch record without a ledger (the pure half of the
 * fold). Unlike the ledger it does NOT dedupe: a caller that walks a log and
 * emits its own lines needs the call line on the event that opens the result.
 * @param event - one session event; an absent event (an over-advanced index)
 * answers \`null\` rather than throwing.
 * @returns the dispatch this event opens, or \`null\` for any other event.
 */
export declare function readDispatchSignal(event: {
    type?: string;
    data?: unknown;
} | undefined): {
    kind: ToolDispatchKind;
    callId: string;
    rootCallId: string;
    name: string;
    arguments: unknown;
} | null;
/**
 * Is this dispatched tool name a single-skill read?
 * @param name - the dispatched tool name.
 * @returns \`true\` only for the read tool whose arguments name one skill.
 */
export declare function isSkillReadToolName(name: string): boolean;
/**
 * Does this signal read one skill, and did it not fail?
 * @param signal - a normalized dispatch.
 * @returns the skill name the dispatch read, or \`undefined\` when the dispatch
 * is not a skill read or has failed. A dispatch whose outcome is still pending
 * counts as a read: the platform settles every started sub-dispatch, so pending
 * is a live-window state, not a failure.
 */
/** Tool names whose dispatch reads one FILE — the deployment's file tool
 * (default `read`). A differently named tool is configured, not guessed. */
export declare const DEFAULT_SUPPORT_READ_TOOL_NAMES: readonly string[];
/** One support-file read attributed to a skill (design §5.5). */
export interface SupportReadHit {
    skill: string;
    /** Skill-root-relative path, e.g. `references/design-x.md`. */
    rel: string;
}
/**
 * Read one dispatch as a SUPPORT-FILE read attributed to a skill: a read of
 * `<root>/<skill>/<support dir>/…` is demand evidence for that one file, the
 * way `skillReadNameOf` is demand evidence for a whole body.
 * @param signal - a settled dispatch.
 * @param options - the deployment's file-tool names and its skills root; an
 *   empty root falls back to the `/skills/` marker in the path.
 * @returns the skill name and the skill-root-relative path, or `null` when the
 *   dispatch is not a support-file read. Pure: no IO, no service lookup.
 */
export declare function supportFileReadOf(signal: ToolDispatchSignal, options: {
    toolNames: readonly string[];
    root: string;
}): SupportReadHit | null;
export declare function skillReadNameOf(signal: ToolDispatchSignal): string | undefined;
/**
 * Fold one session log into its deduplicated dispatches.
 * @param events - the log, oldest first. Pass an array, not a live snapshot
 * iterator, when the log can grow while folding.
 * @returns one signal per dispatch, in first-seen order.
 */
export declare function foldToolDispatches(events: Iterable<{
    type: string;
    data?: unknown;
}>): ToolDispatchSignal[];
/**
 * Every skill name this log read through a dispatch, deduplicated by dispatch.
 * @param events - the log, oldest first.
 * @returns the names read by at least one non-failed skill dispatch.
 */
export declare function collectReadSkillNames(events: Iterable<{
    type: string;
    data?: unknown;
}>): Set<string>;
/**
 * Does this dispatched tool name touch the skill library (read or mutate)?
 * @param name - the dispatched tool name.
 * @returns \`true\` for any skill-library tool. This is the review cadence's
 * skill signal, which has always covered reads and writes alike.
 */
export declare function isSkillToolName(name: string): boolean;
/**
 * Does this dispatched tool name open a code program?
 * @param name - the dispatched tool name.
 * @returns \`true\` for the tool whose sub-dispatches are \`program\` kind.
 */
export declare function isProgramToolName(name: string): boolean;
/**
 * Assert that a payload really is the dispatch event it claims to be.
 *
 * The normalizer is deliberately lenient (it also folds persisted logs, where a
 * payload may predate the current declaration). S1-E7 (honesty fix): this
 * function is an OPT-IN gate — NO production consumer calls it; the shipped
 * listeners fold tolerant (`'malformed'` synthesis) precisely because a
 * throwing gate wired into every session event would brick the family on any
 * upstream payload drift. Deployments that want fail-loud behavior call this
 * from their own `session/event` listener. It never silently downgrades: an
 * unrecognized event type or a payload missing a declared field throws a named
 * \`ToolDispatchPayloadError\`.
 * @param event - the session event to check.
 * @returns nothing; throws when the payload violates the platform declaration.
 */
export declare function assertDispatchPayload(event: {
    type: string;
    data?: unknown;
}): void;
/**
 * Total dispatches in a log, deduplicated.
 * @param events - the log, oldest first.
 * @returns the number of distinct dispatches, one per dispatch regardless of
 * how many events carried it.
 */
export declare function countDispatches(events: Iterable<{
    type: string;
    data?: unknown;
}>): number;
//# sourceMappingURL=tool-dispatch.d.ts.map