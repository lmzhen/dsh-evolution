/**
 * B3 / G4 (0.3.78): the persisted-write inventory — WHICH file the family
 * writes, WHO writes it, and WHAT keeps two writers apart.
 *
 * The table lives in `persisted-write-inventory.json` at the package root so
 * the TypeScript side, the architecture gate (`verify-arch-guards` rule N20)
 * and the regression specs read ONE file (the row-overrides.json pattern).
 *
 * "What keeps two writers apart" has exactly three answers in this family:
 * - `transact`       — the IO backend's cross-process write lock (transactIo);
 * - `write-lock`     — the per-target `<path>.lock` protocol of the skill tree;
 * - `instance-claim` — the per-home single-instance claim (instance-scope.ts),
 *   for a writer whose sweeps cannot be expressed as one locked file.
 * A site that answers with NONE of them is the "two instances, one file" class:
 * a per-instance serial queue looks like serialization and is not.
 * @module @deepseek-ai/dsh-evolution-core/src/write-inventory
 */
/** How concurrent writers of one site are kept apart. */
type WriteSerialization = 'transact' | 'write-lock' | 'instance-claim';
/** One declared persisted write site. */
export interface PersistedWriteSite {
    /** Stable id; referenced by the gate's failure text and by the specs. */
    readonly id: string;
    /** The path(s) written, with the roots the family resolves at runtime. */
    readonly path: string;
    /** Repo-relative module that owns the write. */
    readonly writer: string;
    /** The serialization the writer implements (see the module docblock). */
    readonly serializedBy: WriteSerialization;
    /** Literal that must appear in `writer` — the gate's proof of the claim. */
    readonly marker: string;
    /** The instance key the writer holds when `serializedBy` is instance-claim. */
    readonly instance?: string;
    /** Module-scope state keys (N12 registry keys) this writer keeps, if any. */
    readonly state: readonly string[];
    /** One line on what the file holds; the inventory reads as a whole. */
    readonly note: string;
}
/** One root symbol of the inventory's own legend. `segments` is the path tail the symbol appends to
 * its base (empty for the home itself), and `basedOn` names the symbol it extends. The gate
 * `verify-write-inventory.mjs` checks those segments against the resolver's SOURCE, so the legend
 * cannot drift from the code that resolves it. */
export interface WritePathSymbol {
    /** Name of the core resolver that produces this root (or 'caller' for a caller-supplied path). */
    readonly resolver: string;
    /** Path segments appended to the base root, in order. */
    readonly segments: readonly string[];
    /** The symbol this one extends, when it is not rooted at the DSH home itself. */
    readonly basedOn?: string;
}
/** Instance keys held by writer services — the single source shared by the
 * claim site and the inventory row that declares it (rule N20 checks the row's
 * `instance` names one of these). */
export declare const INSTANCE_KEYS: {
    /** The per-home curator: report writing + the retention sweep. */
    readonly curator: "evolution-curator";
};
/**
 * The declared persisted write sites, in file order.
 *
 * v43 audit (S2-3 / P1-10): this used to be a module-scope readFileSync plus
 * parse, so an unshipped asset threw AT IMPORT — one absent file took the whole
 * family's load down (0.3.79 shipped a tarball without this asset and every
 * package failed to load). The read is lazy now: importing the package never
 * fails on this asset, while the first caller still gets a loud, descriptive
 * failure instead of an empty table ("no declared write sites" would silently
 * disable rule N20).
 * @internal S2.4 (PLAN 2026-09-16): no production caller — the arch guard
 * reads the JSON asset directly; the tests are the only in-tree consumers.
 * @returns the sites, in file order.
 */
export declare function persistedWriteSites(): readonly PersistedWriteSite[];
/** The inventory's symbol legend — the roots every declared path is written against, with the
 * segments the gate checks against the resolver's source.
 * @internal no production caller — the gates read the JSON asset directly. */
export declare function writePathSymbols(): Readonly<Record<string, WritePathSymbol>>;
/** Sites serialized by the per-home instance claim, with their instance keys.
 * @internal S2.4 (PLAN 2026-09-16): no production caller — the arch guard
 * reads the JSON asset directly; the tests are the only in-tree consumers. */
export declare function instanceClaimedWriteSites(): readonly (PersistedWriteSite & {
    readonly instance: string;
})[];
/** One declared site by id. An undeclared id throws — a stale caller must fail
 * loud rather than read "nothing is declared".
 * @internal S2.4 (PLAN 2026-09-16): no production caller — the arch guard
 * reads the JSON asset directly; the tests are the only in-tree consumers. */
export declare function persistedWriteSite(id: string): PersistedWriteSite;
export {};
//# sourceMappingURL=write-inventory.d.ts.map