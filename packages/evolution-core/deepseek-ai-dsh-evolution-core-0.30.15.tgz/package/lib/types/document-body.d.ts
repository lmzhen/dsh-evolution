/**
 * The document a reader sees: the body without its leading frontmatter block.
 * @param content - the stored bytes of one version.
 * @returns the text to render; unchanged when there is no frontmatter the reader accepts.
 */
export declare function displayBodyOf(content: string): string;
/** How much of one version the reader is looking at. */
export interface ReadingStats {
    /** Characters in the stored version. */
    readonly totalChars: number;
    /** Characters the panel holds (the route's own bound). */
    readonly shownChars: number;
    /** Whether anything was left out. */
    readonly truncated: boolean;
}
/**
 * How much of a version the panel is showing.
 * @param full - the whole stored text.
 * @param shown - the part the route handed over.
 * @returns the counts, so the panel can say what it is not showing.
 */
export declare function readingStats(full: string, shown: string): ReadingStats;
/**
 * One H2 section of a body: its title, its line span and how many times that title occurs.
 * @property count - occurrences of `title` in the SAME body; a candidate list may only offer 1.
 */
export interface H2Section {
    title: string;
    start: number;
    end: number;
    count: number;
}
/**
 * The H2 sections of a body, in document order — the ONE scan (G3).
 *
 * Both the restructure candidate list and the store anchor validation call this function, so a
 * candidate can only name a heading that exists EXACTLY ONCE and has content: the two rejections a
 * hand-written anchor used to hit ("no such heading", "ambiguous anchor") stop being reachable.
 * H2 is the section boundary (a section spans to the next H2 or EOF), matching the store.
 * @param body - the markdown after the frontmatter block.
 * @returns one row per H2 heading, with `count` filled in a second pass.
 */
export declare function h2Sections(body: string): H2Section[];
/** One move the panel can hand to `restructure` without the store refusing it. */
export interface RestructureCandidate {
    heading: string;
    toFile: string;
}
/**
 * The sections a restructure proposal may name: heading unique, section non-empty. Derived from
 * `h2Sections`, i.e. from the SAME scan the store validates against.
 * @param body - the markdown after the frontmatter block.
 * @returns move-ready pairs in document order; empty when nothing qualifies.
 */
export declare function restructureCandidates(body: string): RestructureCandidate[];
//# sourceMappingURL=document-body.d.ts.map