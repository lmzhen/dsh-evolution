/**
 * Open-ended `/evolution learn` prompt builder.
 *
 * `learn` is open-ended: the user can name anything they can describe — a
 * directory of code, an API doc URL, a workflow they just walked the agent
 * through, or pasted notes. The prompt instructs the live agent to gather the
 * named sources with its existing tools, then author a single SKILL.md via
 * `skill_manage` following `DSH_AUTHORING_STANDARDS`. There is no separate
 * distillation engine and no model-tool footprint.
 */
/**
 * Build the agent prompt for an open-ended `/evolution learn` request.
 *
 * @param userRequest free-text the user gave after `/evolution learn`; an
 *   empty string falls back to "the workflow we just went through".
 * @returns a complete instruction the agent runs as a normal turn.
 */
export declare function buildLearnPrompt(userRequest: string): string;
//# sourceMappingURL=learn-prompt.d.ts.map