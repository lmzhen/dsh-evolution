/** 技能名文法（与平台 `isSkillName` 等价：kebab-case，点前缀与下划线一律不是技能名）。 */
export declare const SKILL_NAME_RE: RegExp;
/** 名字是否是技能名 —— `._x`、`Bad_Name`、`.archive` 都返回 false。 */
export declare function isSkillName(name: string): boolean;
/** 相对技能根的路径是否落在平台会发现的位置（depth<=2 且最后一段是 SKILL.md 或 `<name>.md`）。 */
export declare function isPotentialSkillPath(relPath: string): boolean;
export interface DiscoveredSkill {
    name: string;
    path: string;
}
/**
 * 扫描一个技能根，返回平台**真正会发现**的技能（非递归、depth<=2、含 `SKILL.md` 的目录、
 * 名字过 kebab-case、跳过点前缀目录）。忽略目录里的边不得计入，也不得算悬空。
 *
 * @param root - 技能根目录。
 * @returns 按名字排序的技能列表（根缺失时返回空数组）。
 */
export declare function discoverSkillFiles(root: string): DiscoveredSkill[];
//# sourceMappingURL=skill-discovery.d.ts.map