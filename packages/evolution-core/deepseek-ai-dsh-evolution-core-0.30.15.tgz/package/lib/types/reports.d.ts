/**
 * 0.19.0 (S2): the family's ONE report-retention sweep.
 *
 * Reports accumulate by design (every run writes one), so each kind needs a
 * window or the reports home becomes an unbounded directory. The logic lived
 * inside the curator only; the maintenance run reports added in 0.19.0 needed
 * the same thing, and a second copy of "list, order, delete beyond the window"
 * is exactly the kind of near-duplicate this family treats as a defect.
 *
 * Three behaviours are the curator's, kept verbatim because they are the reason
 * the sweep is safe to run at all:
 *
 *   - An UNLISTABLE directory is not "no reports" — nothing is deleted and the
 *     caller is told (the same three-state rule the probe files use).
 *   - A report with no usable timestamp is KEPT (never delete what cannot be
 *     ordered) and the fact is said out loud once.
 *   - The order is TOTAL: declared time, then mtime, then name. A tie falling
 *     through to readdir order evicted a different set per platform (CI-caught).
 * @module
 */
import type { EvolutionIoLike } from './io.ts';
/**
 * The lock target a reports sweep holds for one home.
 *
 * `transactIo` takes the IO write lock on THIS path (minting `<path>.lock` with
 * the io protocol's `pid:token` body) and holds it for the whole task; nothing
 * ever writes the target, because the sweep's exclusion is the point. It lives
 * inside `<home>/reports` next to the directory it protects (the sweeps' own name
 * filters ignore it, and the lock file is removed on release).
 *
 * Moved here from evolution-curator in 0.19.0 (S2): the maintenance reports'
 * sweep needs the SAME exclusion, and a second lock would protect nothing.
 * @returns the lock target path.
 */
export declare function reportsSweepLockTarget(): string;
/** One retention window: files whose name starts with `prefix`, newest `keep` survive. */
export interface ReportBucket {
    prefix: string;
    keep: number;
}
/** Inputs for {@link sweepReports}. */
export interface SweepReportsOptions {
    io: EvolutionIoLike;
    /** Reports directory (`<evolutionHome()>/reports`). */
    dir: string;
    /** Buckets. The FIRST prefix that matches classifies a file — pass specific ones first. */
    buckets: readonly ReportBucket[];
    /** Warn channel for an unlistable directory or an unorderable report. */
    warn?: ((message: string) => void) | undefined;
    /** Prefix of the warning messages, naming the owning package. */
    owner: string;
}
/**
 * Delete the reports beyond each bucket's window, each with its `.md` digest.
 *
 * Best-effort by construction: pruning never fails the run that wrote a report.
 * @param options - io seam, directory, windows, warn channel and owner name.
 * @returns nothing; deletions and skips are reported through `warn`.
 */
export declare function sweepReports(options: SweepReportsOptions): Promise<void>;
//# sourceMappingURL=reports.d.ts.map