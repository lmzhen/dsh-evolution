/**
 * Threat scanning for agent-authored memory and skill content.
 *
 * Ported as a small, dependency-free subset of Hermes Agent's
 * `tools/threat_patterns.py` + hermes-claw `threats.ts`.
 *
 * Policy (P1-1, v19): a finding either BLOCKS the write or only REPORTS.
 * Blocking is reserved for shapes with no legitimate use in stored knowledge
 * (prompt-injection phrasing, credential exfiltration, the invisible-character
 * smuggling core). Typography and presentation characters that are legitimate
 * in ordinary prose — variation selectors (❤️), zero-width non-joiner, soft
 * hyphen from PDF paste, Arabic letter mark, Mongolian vowel separator — are
 * REPORT findings: they stay visible to operators and tests but never reject a
 * write. Blocking them turned every emoji into a security event.
 */
type ThreatScope = 'all' | 'context' | 'strict';
interface ThreatFinding {
    label: string;
    category: string;
    scope: ThreatScope;
    /** P1-1 (v19): `block` (default) refuses the write; `report` is an audit
     * trail entry only. Absent means `block`. */
    severity?: 'block' | 'report';
}
/**
 * Optional scan controls. Default behavior (`options` omitted) is unchanged:
 * every in-scope pattern blocks. Adapters that need to tolerate a specific
 * benign phrasing (e.g. a skill that legitimately opens with "You are now a ...")
 * can exclude that label by name here. This is opt-in and never widens strict
 * scope; it only permits callers to drop a known-innocent match.
 * V27 G-1: an exclusion drops the FINDING for that label — it never removes the
 * de-obfuscation the other patterns are matched against, so exempting the
 * unicode rules cannot re-open a splitting bypass.
 */
export interface ScanOptions {
    /** Pattern labels to skip during this scan. */
    excludeLabels?: readonly string[];
}
/** Minimum window size for the full-coverage scan (V6-05, 0.3.35). With the
 * proportional half-window step below, the overlap is `ceil(w/2)` — only a
 * window at or above this floor keeps the overlap above the longest pattern
 * span (~530 chars: `curl [^\n]{0,512} ...`), so a match straddling a window
 * boundary is fully inside at least one window (E-12, 0.3.16). The clamp
 * falls back to the default for a smaller caller value instead of risking a
 * blind zone. */
export declare const PATTERN_OVERLAP = 4096;
/**
 * Scan text at `scope`. Patterns are cumulative: `strict` includes all scopes.
 * `options.excludeLabels` removes matching patterns without changing `scope`.
 * `maxScanChars` is the WINDOW SIZE, not a total cap (E-12, 0.3.16): the whole
 * text is always scanned in overlapping windows, so content beyond 65,536
 * characters (skill files may run to 100,000) is no longer a blind zone.
 */
export declare function scanThreats(text: string, scope?: ThreatScope, maxScanChars?: number, options?: ScanOptions): ThreatFinding[];
/** Blocking policy (P1-1, v19): a finding blocks unless it is explicitly
 * `report`-only. Pattern findings carry no severity and therefore block as
 * before. */
export declare function evaluateThreat(text: string, scope?: ThreatScope, maxScanChars?: number, options?: ScanOptions): {
    blocked: boolean;
    findings: ThreatFinding[];
};
/** User-facing block message for memory writes. */
export declare function scanMemoryThreats(text: string, maxScanChars?: number, options?: ScanOptions): string | null;
/** User-facing block message for skill content writes. */
export declare function scanContentThreats(text: string, maxScanChars?: number, options?: ScanOptions): string | null;
/**
 * WD2 (0.3.56): the shared tail of every user-facing threat block — names the
 * deployable self-heal path so the model (or operator) can allowlist a
 * known-benign label. v20 (B-2) single source: the scan builders embed this
 * constant verbatim; do NOT re-word it per call site (the three former copies
 * — memory inline, content inline, and the dead `THREAT_EXEMPT_HINT` export,
 * whose docblock still claimed a store-side append that memory-store/skill-store
 * had already removed — had drifted apart). The evolution-threat guard channel
 * returns the scan message verbatim, so the hint rides along there too.
 */
export declare const THREAT_EXEMPTION_HINT = " A deployment that needs a specific label can exempt it via threatExemptLabels (see the README env/dial reference).";
export {};
//# sourceMappingURL=threats.d.ts.map