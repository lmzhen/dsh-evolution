/**
 * Self-evolution event log (rc.68): an append-only sidecar under
 * `$DSH_HOME/evolution/events.json` that is the single source of truth for
 * the self-improvement loop. Feedback increments and learn actions share one
 * ordered timeline (`seq` is the ordering key), so "feedback before/after a
 * learn on target X" is answerable. The aggregate `feedback.json` is a
 * rebuildable boot cache, never the truth.
 *
 * Usage events (C semantics, rc.73+): `type:'usage'` records are the
 * OBSERVATION WINDOW ANCHOR — written once, when the library's first observed
 * read (`view_count` 0 -> 1) happens. The anchor is the durable timeline record
 * of that moment: the churn-suppression gate itself (`usageObserved()`) reads
 * the usage SIDECAR's own first-view evidence, since reads were invisible to it
 * pre-A2 and no sidecar record can reach `view_count > 0` without the same
 * 0 -> 1 transition. `counts` on the event is a cumulative library-wide
 * snapshot (skills/views/use/patches) at that moment, and `window.opened` pins
 * the window start for the timeline. (V27 G3.3: `verify-event-pairing` requires
 * every persisted type to have a production reader or a declared external
 * contract — this one is the latter.)
 *
 * Rotation (rc.71, 007 design): when the active log reaches
 * `EVENT_LOG_ROTATE_AT` the older half is split into an archive
 * (`events-<lastArchivedSeq>.json`); the boot timeline merges active +
 * archives and dedupes by seq (active copy wins), so the rotation crash window
 * yields the identical timeline. Archival naming is STRICTLY numeric
 * (`/^events-\d+\.json$/`) — user files under the same directory are never
 * read as archives and never pruned (rc.72 G-2).
 */
import { type EvolutionIoLike } from './io.ts';
export declare const EVENT_LOG_VERSION = 1;
/** Active-log split point (rc.71): when the active log reaches this many events
 * the older half is rotated into an archive; the active stays bounded so a
 * single append stays O(active) instead of O(total-history). Tunable default —
 * callers may override per append (the tests use small values). */
export declare const EVENT_LOG_ROTATE_AT = 4000;
/** Number of archives retained (rc.71): older archives are pruned at rotation,
 * mirroring retainReports. The horizon covers the loop-analysis window. */
export declare const EVENT_LOG_RETAIN_ARCHIVES = 10;
/** Archive file prefix: `events-<lastArchivedSeq>.json`. The active file is
 * `events.json` and never matches this glob. */
export declare const EVENT_ARCHIVE_PREFIX = "events-";
export interface EvolutionEvent {
    /** Global monotonic order key, assigned inside the append transact. */
    seq: number;
    /** ISO timestamp at append time. */
    at: string;
    /** Tagged-union discriminator: feedback increments, learn actions, usage
     * observation anchors (C semantics: `usage` events carry the library-wide
     * count snapshot at the moment the observation window opened), and
     * maintain scans (011: verdict + recommendation count + runId). */
    type: 'feedback' | 'learn' | 'usage' | 'maintain';
    /** Fold key for a `feedback` event: required and non-empty there (P2-10),
     * optional on the other tags and on a record this version only reads. */
    target?: string | undefined;
    kind?: 'skill' | 'session' | undefined;
    rating?: 'positive' | 'negative' | undefined;
    note?: string | undefined;
    source?: string | undefined;
    request?: string | undefined;
    runId?: string | undefined;
    verdict?: string | undefined;
    recommendations?: number | undefined;
    /** Library-wide usage totals (usage events; counts are cumulative, not deltas). */
    counts?: {
        skills?: number;
        views?: number;
        use?: number;
        patches?: number;
    } | undefined;
    /** Anchor fields for one event (usage: the observation window). */
    window?: {
        opened?: string;
    } | undefined;
}
/** The durable-write shape of one event: `feedback` REQUIRES a `target` —
 * the fold key the aggregate is keyed by (P2-10). The other tags keep every
 * field optional, exactly as the runtime payload gate treats them. */
type EvolutionEventInput = (Omit<EvolutionEvent, 'seq' | 'at' | 'target'> & {
    type: 'feedback';
    target: string;
}) | (Omit<EvolutionEvent, 'seq' | 'at'> & {
    type: 'learn' | 'usage' | 'maintain';
});
export declare function eventsFile(home: string): string;
/** I-5 (v18): one lightweight description of the durable event payload
 * contract. The log is a FILE boundary (a host, a script or an older version
 * can write it), so `appendEvolutionEvent` refuses a record no consumer can
 * fold instead of persisting it and failing silently later. The process event
 * bus stays unvalidated — that is a typed same-process boundary.
 * @param event - the candidate event record.
 * @returns a human-readable issue, or null when the record is well-formed.
 */
export declare function evolutionEventPayloadIssue(event: {
    type?: unknown;
} & Partial<EvolutionEvent>): string | null;
export declare function parseEvolutionEvents(raw: string | null): EvolutionEvent[];
/**
 * List the numeric archives under the log's directory, sorted ascending by
 * their last-archived seq. Single glob predicate for the timeline, the
 * retention pass and the feedback migration check (rc.72 H-3).
 */
export declare function listEventArchives(io: EvolutionIoLike, path: string): Promise<string[]>;
/**
 * Append one event under the write lock (rc.68): `seq` = current max + 1
 * computed inside the transact, so two processes appending concurrently never
 * collide. A malformed log is refused (bytes preserved) and the append fails.
 * Returns the assigned seq.
 *
 * Rotation (rc.71, 007 design): when the active log reaches `rotateAt`, the
 * older half is copied into an archive inside the SAME transact (the archive
 * path has its own lock, so no recursion) and the active is replaced with the
 * newer half + the new event. seqs stay globally monotonic; a crash between
 * archive write and active write leaves both copies, which the timeline merge
 * dedupes by seq. An archive-write failure aborts the append (active keeps the
 * full old content — no loss) and the caller's best-effort handling applies.
 *
 * rc.72 G-1: when the ACTIVE is missing/whitespace but archives exist (a
 * deleted active, or B-2 self-heal), seq derivation consults the archive names
 * — the active restarts AFTER the highest archived seq, never at 1, so a new
 * event can never shadow an archived one in the seq-deduped timeline.
 */
export declare function appendEvolutionEvent(io: EvolutionIoLike, path: string, event: EvolutionEventInput, rotateAt?: number): Promise<number>;
/**
 * Prune old event archives (rc.71): keep the newest `EVENT_LOG_RETAIN_ARCHIVES`.
 * The name's numeric part is the last archived seq, so ordering is NUMERIC —
 * lexicographic would rank `events-10` before `events-2`. Only strictly
 * numeric names participate (rc.72 G-2: user files are never deleted).
 * Best-effort per removal; exported for the retention test.
 */
export declare function retainEventArchives(io: EvolutionIoLike, path: string): Promise<void>;
interface EventLogRead {
    events: EvolutionEvent[];
    /** True when THIS read DROPPED events the file may hold, so the result must
     * never be treated as the complete truth for that file. Three causes flag it:
     * syntax-level damage and a READ error (EISDIR/EACCES) — both refused on
     * append with their bytes untouched — and, since C-events-dispatch-1 (v43
     * audit), a body whose `version` this reader cannot interpret: F-338 keeps
     * such a body un-reshaped and never rewritten down, but its records ARE
     * missing from the read. A well-formed body with a damaged `events` field
     * stays UNflagged — REPLACEABLE garbage that reads as empty and is rewritten
     * at the next append (rc.70 F-1: read and append agree on the same boundary). */
    malformed: boolean;
}
/** Read the event log; a missing/whitespace-only file reads as empty, corrupt
 * content is flagged (and refused on append). A well-formed future-version body
 * is v1-incompatible: it reads as EMPTY and is now flagged malformed as well
 * (C-events-dispatch-1, v43). F-338's own guarantees are untouched — the reader
 * never mis-shapes a newer format and the append path refuses it up front, so
 * the original bytes survive — while the flag reports what the old reader hid:
 * every record that body holds is dropped from this read. */
export declare function readEvolutionEvents(io: EvolutionIoLike, path: string): Promise<EventLogRead>;
/**
 * Read the full timeline (rc.71): active log + all archives, merged by seq
 * (active copy wins, duplicates only arise from the rotation crash window),
 * sorted ascending. Per-file malformed flag as in `readEvolutionEvents`; a
 * flagged ARCHIVE (unreadable, damaged, or a future-version body this reader
 * cannot interpret) is SKIPPED — it never bricks the boot, the returned events
 * simply LACK that seq band, and `malformed` is the only signal that they do
 * (C-events-dispatch-1, v43: the flag is the consumer's contract; a truncated
 * timeline must never be folded back as if it were complete).
 */
export declare function readEvolutionTimeline(io: EvolutionIoLike, path: string, archives?: readonly string[]): Promise<EventLogRead>;
export {};
//# sourceMappingURL=evolution-events.d.ts.map