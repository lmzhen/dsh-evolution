import type { Context } from '@deepseek-ai/cordis';
import type { ChannelKind, ChannelState } from './types.ts';
/** Pure derivation (no side effects): the doctor reads this, the channel re-probes on every run. */
export declare function probeChannelState(ctx: Context, kind: ChannelKind): ChannelState;
export declare function subagentChannelState(ctx: Context, kind: ChannelKind): ChannelState;
//# sourceMappingURL=readiness.d.ts.map