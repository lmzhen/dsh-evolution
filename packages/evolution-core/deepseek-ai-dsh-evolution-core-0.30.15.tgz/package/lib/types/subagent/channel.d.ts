import type { Context } from '@deepseek-ai/cordis';
import type { SubagentChannel } from './types.ts';
export declare function createSubagentChannel(ctx: Context): SubagentChannel;
//# sourceMappingURL=channel.d.ts.map