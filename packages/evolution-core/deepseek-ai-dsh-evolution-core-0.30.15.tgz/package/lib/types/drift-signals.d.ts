/**
 * Library-level drift signals for the maintenance subagent (design 011).
 *
 * Deterministic fact checks over a skill-library snapshot: domain drift
 * (narrow names, near-duplicate groups, prefix clusters) and layer drift
 * (log-like bodies, duplicate headings, overlong lines, missing support-file
 * pointers, description over the authoring bar). Pure functions only — no IO,
 * no LLM, no services. Thresholds are imported from their owning modules
 * (skill-health / quality / skill-store), never duplicated.
 *
 * Distinct from `signals.ts` — the session-level review signal gate.
 */
import { type CitationReport } from './citations.ts';
import { type BodyCost } from './cost.ts';
/** One skill's library state; the assembler (not this module) reads IO. */
export interface DriftSkillSnapshot {
    name: string;
    /** SKILL.md content (frontmatter included). */
    body: string;
    /** Frontmatter description, when the assembler parsed it. */
    description?: string | undefined;
    /** Support-file relative paths (e.g. `references/x.md`), when known. */
    supportFiles?: readonly string[] | undefined;
    /** Quality score 0..1, when the assembler computed it; null/undefined = unknown. */
    quality?: number | null | undefined;
    /** Usage observation window status; null/undefined = unknown. */
    usageObserved?: boolean | null | undefined;
    /** Protection marker (`bundled`/`hub-installed`/`pinned`), when known (0.3.11). */
    protected?: string | null | undefined;
    /** Frontmatter values the strict-YAML platform catalog cannot load (0.3.11). */
    catalogInvalid?: boolean | undefined;
    /** Weighted context cost of the body (design §5.2); undefined = not measured. */
    cost?: BodyCost | undefined;
    /** Citation scan of the body (design §5.2); undefined = not scanned. */
    citations?: CitationReport | undefined;
    /** Per-support-file read counts (design §5.5); undefined = no evidence. */
    demand?: Readonly<Record<string, number>> | undefined;
    /** Idle age of the owning skill (design §5.6); undefined = no record to age. */
    liveness?: SkillLiveness | undefined;
    /** Character counts of support files that can possibly exceed the content cap
     * (design §16.6, V4); undefined = not measured. The assembler pre-filters by
     * byte size, which is complete for the oversize question. */
    supportChars?: Readonly<Record<string, number>> | undefined;
}
/** Retirement-proposal input for one skill (design §5.6). */
export interface SkillLiveness {
    /** Idle days since the lifecycle age anchor (`last activity ?? created_at`). */
    idleDays: number;
}
/** verdict=over means "relatively positioned above the threshold", never a violation. */
type DriftVerdict = 'pass' | 'over' | 'unknown';
export interface DriftSignal {
    id: string;
    verdict: DriftVerdict;
    /** Human-readable measured value; message text is redactable. */
    value: string;
    /** Threshold reference, when the signal has one. */
    threshold?: string | undefined;
    /** Extra evidence (matched shapes, line numbers, group members). */
    detail?: string | undefined;
}
interface DriftSkillAssessment {
    name: string;
    signals: ReadonlyArray<DriftSignal>;
    /** Passthrough from the snapshot (0.3.11): protection marker, catalog loadability. */
    protected?: string | null | undefined;
    catalogInvalid?: boolean | undefined;
}
export interface DriftReport {
    /** Library-wide signals (dedup_group, prefix_cluster, usage_observed). */
    library: ReadonlyArray<DriftSignal>;
    /** Per-skill signals. */
    skills: ReadonlyArray<DriftSkillAssessment>;
}
/** Physical line length at/above which a body line is reported overlong (011 §4). */
export declare const DRIFT_MAX_LINE_CHARS = 1500;
/** Signal-set version: bump whenever ids/thresholds change (011 §7 version coupling). */
export declare const DRIFT_SIGNALS_VERSION = "3";
/** Render-time nouns for the MAINTAIN_PROMPT placeholders (single vocabulary with the facts block). */
export declare const DRIFT_SIGNAL_NOUNS: Readonly<Record<string, string>>;
/** Detect support files the body never references (by basename or relative path). */
export declare function missingSupportPointers(body: string, supportFiles: readonly string[]): string[];
/** Support files the body mentions WITHOUT the sanctioned hook form (design
 * §5.6). Such a mention still counts as a pointer for `pointer_missing`, but
 * only the hook form keeps the file discoverable after a move — detail only.
 * A file carrying a `keep` marker is exempt: its mention IS the marker. */
export declare function unhookedSupportPointers(body: string, supportFiles: readonly string[]): string[];
/** Why a retirement report lists nothing (design §5.6). */
export type RetirementStatus = 'listed' | 'none' | 'no-age' | 'unscanned';
/** One support file proposed for retirement review. */
export interface RetirementCandidate {
    path: string;
    /** Whole idle days of the owning skill at scan time. */
    idleDays: number;
}
/** Retirement proposal for one skill: candidates plus the reason when empty. */
export interface RetirementReport {
    candidates: readonly RetirementCandidate[];
    status: RetirementStatus;
}
/** Support files with no readers, no citations and no `keep` marker whose owning
 * skill has been idle for at least the lifecycle stale window. PROPOSAL INPUT
 * only — nothing retires a file on its own — and an unmeasurable input (no age
 * evidence, no citation scan) yields an empty list WITH its reason, never a
 * silent "nothing qualifies".
 * @param snapshot - the skill's drift snapshot.
 * @param supportFiles - its enumerated support files, in listing order.
 * @returns the candidates plus the status that explains an empty list.
 */
export declare function retirementReport(snapshot: DriftSkillSnapshot, supportFiles: readonly string[]): RetirementReport;
/** Duplicate `## heading` occurrences: singleton results default to head of the file. */
export declare function duplicateHeadings(body: string): Array<{
    heading: string;
    count: number;
}>;
/** Physical lines over `max` characters: `{ lineNo, chars }`, 1-based line numbers. */
export declare function overlongLines(body: string, max?: number): Array<{
    lineNo: number;
    chars: number;
}>;
/** Narrow-name shapes detected in a skill name (empty = none). */
export declare function narrowNameMatches(name: string): string[];
/**
 * Compute all drift signals for a snapshot. Missing inputs (quality score,
 * usage window) yield `unknown` — never a fabricated verdict.
 */
export declare function computeDriftSignals(snapshots: ReadonlyArray<DriftSkillSnapshot>): DriftReport;
/** Convenience: fetch one signal from an assessment or library list. */
export declare function findDriftSignal(signals: ReadonlyArray<DriftSignal>, id: string): DriftSignal | undefined;
export {};
//# sourceMappingURL=drift-signals.d.ts.map