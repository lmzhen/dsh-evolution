/**
 * Fuzzy string matching and replacement for patch/restructure edits of skill files.
 *
 * Split out of skill-store.ts (S2-1): pure text functions with no store state.
 * The store imports the scan, the budgets and the replace entry points directly;
 * none of them is re-exported, so the package export surface is unchanged.
 */
/** V6-17 (0.3.37): the fuzzy-patch scan is O(n·m) with no input bound; a
 * non-exact anchor past these budgets would block the event loop (measured
 * ~6s at 20k×20k). Exact matches go through the fast `includes` path and stay
 * allowed regardless of size. */
export declare const FUZZY_MAX_PATTERN_CHARS = 4096;
export declare const FUZZY_MAX_WORK = 8000000;
/** Trim leading whitespace of the first line and trailing whitespace of the last line. */
export declare function trimPatternBoundaries(pattern: string): string;
export declare function fuzzyPatch(content: string, oldString: string, newString: string, replaceAll?: boolean): string | null;
/** Deterministic section-extraction plan facts; the caller owns the IO and the append semantics. */
//# sourceMappingURL=fuzzy-match.d.ts.map