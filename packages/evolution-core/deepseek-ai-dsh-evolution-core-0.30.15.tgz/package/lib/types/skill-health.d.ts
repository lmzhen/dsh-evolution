/**
 * Skill structure-health domain (rc.73 A1, 008 design): a SECOND assessment
 * dimension beside the six-factor usage quality — document hygiene, consumed
 * by the curator health view and the `/evolution skills health` command.
 *
 * PURE and DERIVED: nothing is persisted; every assessment is computed from
 * file facts at read time. The judgment split follows the original's
 * boundary/治理 layering — deterministic signals here, refinement proposals
 * stay in the review/curator judgment layer. Never become a 7th factor of
 * `computeQualityScores` (different dimension, different consumers).
 */
import { type LintFinding } from './skill-lint.ts';
export interface SkillHealthThresholds {
    /** Soft body limit: a body of `softBodyChars` or MORE -> 'warn'; >= 2x ->
     * 'needs-restructure'. V6-34 (0.3.37): the doc comment used to claim
     * "at/below stay healthy" while the engine warns at `>=` — fixed to the
     * implementation edge (the reason copy said "above"). */
    softBodyChars: number;
    /** Stamp-density ceiling per KB of body text: rc.NN / commit shas / ISO
     * dates per KB at/above this -> 'warn' (log-like content living in the
     * body — the "invalid info" indicator). */
    stampDensityPerKb: number;
    /** Patch count at/above this with zero reads -> 'warn' (write-ghost: the
     * skill is churned but nothing ever loads it). */
    churnMinPatches: number;
}
export declare const DEFAULT_HEALTH_THRESHOLDS: SkillHealthThresholds;
/**
 * Stamp regex shared by health assessment and the maintenance probe (single
 * source, 011). Two refinements over the naive form (F-320): the hex branch
 * requires at least one digit so coincidental all-letter English words
 * (`defaced`, `feedback`) are not counted as commit shas; the ISO branch
 * accepts a UTC `Z`, a numeric UTC offset (`+08:00`), or no timezone at all —
 * non-UTC timestamps used to escape detection (log-like content missed).
 *
 * Known boundary, recorded not fixed (C-22, v10 audit): the hex branch also
 * matches 7-40 char PURE-DIGIT strings (order numbers etc.), so stamp density
 * can be over-reported for such content. The misjudgment direction is "extra
 * stamp hits" only — never a miss — and no real incident exists; revisit only
 * if curator decisions are actually distorted (v10 deferral ledger).
 */
export declare const HEALTH_STAMP_RE: RegExp;
/**
 * Bodies below this size skip stamp-density assessment: a few dates or shas
 * in a short body are ordinary documentation, not log-like content. With the
 * 1KB density floor a 3-date sentence in a small skill measured 3.0/KB and
 * warned on a perfectly healthy body (audit 2026-08-31 X1).
 */
export declare const MIN_STAMP_BODY_CHARS = 2000;
export type SkillHealthVerdict = 'healthy' | 'warn' | 'needs-restructure';
/** Facts a caller already has; assessors never do IO.
 *
 * `bodyChars`/`bodyText` are the WHOLE `SKILL.md` text as read from disk
 * (frontmatter included), matching both callers: `SkillLibrary.assessHealth`
 * and `snapshotFromLibrary` feed `read()` verbatim. The field names predate
 * that convention; the thresholds are calibrated against the whole file, so a
 * caller must not strip frontmatter before measuring. */
interface SkillHealthSnapshot {
    skillName: string;
    bodyChars: number;
    bodyText?: string | undefined;
    /** Number of non-empty support groups (references/ templates/ scripts/). */
    supportGroups: number;
    /** Support FILES under references/ (contract §4), when the caller counted them; null = not measured. */
    supportFiles?: number | undefined;
    /** Usage-side patch count, when the caller has it (A2 churn dimension). */
    patchCount?: number | undefined;
    /** Usage-side view count, when the caller has it (A2 churn dimension). */
    readCount?: number | undefined;
}
interface SkillHealthDim {
    bodyChars: number;
    /** The same body on the token scale (limit basis) — the judged quantity. */
    bodyTokens: number;
    stampDensityPerKb: number | null;
    /** Raw stamp hits — the number the stamp rule reports as `count`. */
    stampHits: number | null;
    supportGroups: number;
    /** Support FILES under references/; null = the caller could not count them (never 0-as-unknown). */
    supportFiles: number | null;
    /** Usage churn facts; null when the caller supplied no counts. */
    churnPatches: number | null;
    churnReads: number | null;
}
export interface SkillHealthAssessment {
    verdict: SkillHealthVerdict;
    dims: SkillHealthDim;
    /** The same judgement as `reasons`, in diffable form: (rule id, severity, count). G1. */
    findings: LintFinding[];
}
/**
 * The findings for ONE body, computed by the engine that owns the judgement (G4).
 *
 * Deliberately a thin call into `assessStructureHealth`: a later consumer (the write receipt) needs
 * findings for a body it is about to store, and re-deriving the facts anywhere else would be a
 * SECOND judgement — the token-scale line, the /1024 stamp density and the soft/2 support threshold
 * all live in one place and must stay there.
 * @param skillName - the skill the body belongs to (used in messages).
 * @param content - the WHOLE SKILL.md text, frontmatter included (the engine's own convention).
 * @param supportGroups - non-empty support dirs; pass the real count, never a guess.
 * @param thresholds - the configured thresholds; defaults to the shipped ones.
 * @returns the findings, in rule order.
 */
export declare function lintBody(skillName: string, content: string, supportGroups: number, thresholds?: SkillHealthThresholds): LintFinding[];
export declare function assessStructureHealth(snapshot: SkillHealthSnapshot, thresholds?: SkillHealthThresholds): SkillHealthAssessment;
export {};
//# sourceMappingURL=skill-health.d.ts.map