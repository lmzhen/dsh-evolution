/**
 * Quality scoring and near-duplicate detection for the curated skill library.
 *
 * Pure functions over data inputs so the scoring policy is unit-testable and
 * the same math feeds the usage sidecar, the `skill_manage review` surface and
 * the learning graph. Weights follow the Hermes/hermes-claw six-factor model;
 * mutation maturity is a documented DSH approximation (single per-month patch
 * trend ratio replaces the claw timestamp-trend formula, since DSH usage
 * records only carry the last patched timestamp).
 *
 * Batch C (2026-09-27): the similarity half of this module is now TWO NAMED
 * QUESTIONS plus a declared projection — {@link identity} ("is it the same
 * text?") and {@link affinity} ("how much vocabulary do these two share?") asked
 * over {@link projectionText}. Callers name the question and the projection
 * instead of growing a fourth unnamed ruler (design §3C / §1 I2).
 * @module @deepseek-ai/dsh-evolution-core
 */
import type { UsageMap } from './usage.ts';
export interface QualityFactors {
    /** 0.25 — skill LOADS per day of age (view_count + use_count), capped at 1. */
    usageFrequency: number;
    /** 0.20 — 1 − patch/load (zero loads = stable). */
    stability: number;
    /** 0.20 — 1 under 30 idle days, linear decay to 0 at 180. */
    recency: number;
    /** 0.10 — in-degree / 3 (graph references), capped at 1. */
    references: number;
    /** 0.20 — patch cadence maturity (DSH approximation of the trend formula). */
    mutationMaturity: number;
    /** 0.05 — non-empty support subdirectories × 0.175, capped at 1. */
    richness: number;
}
export interface QualityScore {
    score: number;
    factors: QualityFactors;
    warn: boolean;
}
export declare const QUALITY_WEIGHTS: {
    readonly usageFrequency: 0.25;
    readonly stability: 0.2;
    readonly recency: 0.2;
    readonly references: 0.1;
    readonly mutationMaturity: 0.2;
    readonly richness: 0.05;
};
/** Score below which a skill is flagged for review. */
export declare const LOW_QUALITY_THRESHOLD = 0.3;
export declare function computeQualityScores(input: {
    usage: UsageMap;
    referenceCounts?: ReadonlyMap<string, number>;
    supportDirs?: ReadonlyMap<string, number>;
    now?: Date;
}): Map<string, QualityScore>;
/** Named similarity question 1 — "is it the same text?" — as a normalized
 * content hash: case- and whitespace-insensitive, so two texts that differ only
 * in formatting are the SAME text here. Invariant under which projection the
 * caller read the text from.
 *
 * C-26 (v10 audit): NOT named `contentHash` — mutations.ts exports a
 * contentHash of RAW bytes, this one hashes the NORMALIZED text for dedup
 * grouping. Same helper as that rename, now a named question. */
export declare function identity(text: string): string;
/** Which text a similarity question is asked about. Declared by the caller. */
export type SimilarityProjection = 'body' | 'summary';
/** The one input shape both projections read from: a caller passes what it has. */
export interface SimilarityInput {
    /** The whole SKILL.md — the `body` projection. */
    content?: string;
    /** The skill name — half of the `summary` projection. */
    name?: string;
    /** The frontmatter description — half of the `summary` projection. */
    description?: string;
}
/**
 * The declared projection: WHICH text a comparison weighs.
 *
 * `body` is the library-wide scan's projection (whole SKILL.md, read by the
 * caller). `summary` is name + description in one string — the projection a
 * listing already publishes (`SkillSummary` carries both fields, and a body is
 * attached only when the caller asks for it) — so a summary comparison never
 * reads a body OF ITS OWN: the create-time hint is fed by the listing pass the
 * tool already pays for its frontmatter, and calls no read of its own.
 */
export declare function projectionText(projection: SimilarityProjection, input: SimilarityInput): string;
/** The comparable vocabulary of one text: lowercase alphanumeric runs, plus
 * whole CJK runs (a Chinese description tokenizes by punctuation, not by word —
 * deliberately: the ruler is one home, and a real tokenizer is a different
 * question than "do these two share vocabulary?"). */
export declare function vocabulary(text: string): ReadonlySet<string>;
/** Named similarity question 2 — "how much vocabulary do these two share?" —
 * Jaccard over two {@link vocabulary} sets, 0 (nothing in common, or either side
 * empty) to 1 (identical vocabulary). Set-based on purpose: the bulk scan
 * memoizes each name's set once and only the comparisons are budgeted. */
export declare function affinity(a: ReadonlySet<string>, b: ReadonlySet<string>): number;
/** The `affinity` level at which two bodies are treated as the same skill
 * (design §3C: the default is unchanged at 0.95 — it is now a NAME, because the
 * docblock below has linked it since PLAN-R2 while the code carried a bare
 * literal). Callers may still pass their own level. */
export declare const DEDUP_SIMILARITY_THRESHOLD = 0.95;
/** PLAN-R2 P2-8 (2026-09-16): default cap on two-name comparisons in
 * {@link computeDedupGroups}. A 2000-skill library is ~2M pairs; the old
 * unbounded two-two Jaccard ran seconds to tens of seconds per
 * review/`dedup_group` probe. 250k comparisons bounds that to well under a
 * second while staying far above every real library's pair count. Only
 * pairwise comparisons are budgeted — materializing a name's token set
 * (memoized, once per name) and the exact-hash pre-union phase are not. */
export declare const DEDUP_MAX_PAIR_COMPARISONS = 250000;
/** PLAN-R2 P2-8 (2026-09-16): result of the near-duplicate scan. `truncated`
 * reports that the pairwise scan stopped at the comparison budget: groups
 * already found are valid, but pairs beyond the budget were never examined. */
export interface DedupScanResult {
    groups: string[][];
    truncated: boolean;
}
/**
 * Two-phase near-duplicate clustering: exact normalized-hash groups first,
 * then token-Jaccard edges at {@link DEDUP_SIMILARITY_THRESHOLD} with a token
 * ratio guard, union-find across the whole set.
 *
 * PLAN-R2 P2-8 (2026-09-16): each name's token set is materialized once
 * (memoized map), each pair takes an O(1) size-ratio short-circuit before the
 * intersection, and the pairwise loop is bounded by
 * `maxPairComparisons` (default {@link DEDUP_MAX_PAIR_COMPARISONS}); hitting
 * the budget stops the scan and `truncated: true` says so. Small libraries
 * (below the budget) behave exactly as the unbounded scan did.
 */
export declare function computeDedupGroups(input: {
    contents: ReadonlyMap<string, string>;
    threshold?: number;
    /** Pair-comparison budget (PLAN-R2 P2-8). Defaults to
     * {@link DEDUP_MAX_PAIR_COMPARISONS}; a smaller value truncates earlier. */
    maxPairComparisons?: number;
}): DedupScanResult;
/**
 * The create-time near-duplicate question (batch C, design §3C-2): WHICH
 * existing skills is this authoring candidate about to near-copy?
 *
 * It is the SAME {@link affinity} question as the library-wide scan, asked over
 * the `summary` projection — the one a listing already publishes
 * (`SkillSummary` carries `name` and `description`; nothing here can see a
 * body, which is the point: a create must not pay a SECOND whole-tree pass — the
 * listing's own frontmatter read is what feeds this comparison). Deliberately hint-only: the caller writes regardless, and the
 * matches are news, not a gate (G4 — the create-time foreground behavior is
 * unchanged).
 *
 * The default level is far below the scan's {@link DEDUP_SIMILARITY_THRESHOLD}
 * because the projection is thinner: a name plus one sentence shares far fewer
 * tokens than two bodies, and a hint that fires on every new skill is noise.
 * Exact same-name candidates are skipped — the library's own create refuses
 * those, and this line must not repeat that refusal.
 */
export declare const SUMMARY_DUPLICATE_HINT_THRESHOLD = 0.5;
/** The fields {@link nearDuplicateSummaries} weighs — a structural subset of
 * `SkillSummary`, so a listing feeds it without a conversion. */
export interface SummaryCandidate {
    name: string;
    description?: string;
}
export interface SummaryMatch {
    name: string;
    /** The `summary`-projection {@link affinity} in 0..1. */
    score: number;
}
export declare function nearDuplicateSummaries(input: {
    candidate: SummaryCandidate;
    existing: ReadonlyArray<SummaryCandidate>;
    /** Level at which a match is reported. Defaults to
     * {@link SUMMARY_DUPLICATE_HINT_THRESHOLD}. */
    threshold?: number;
    /** Cap on returned matches, closest first. Defaults to 3. */
    limit?: number;
}): SummaryMatch[];
/**
 * Prefix-cluster index over a name set (rc.67 merge heuristic, input side):
 * the curator prompt asks the model to identify "prefix clusters — skills
 * sharing a first word or domain keyword"; the deterministic index supplies
 * stable ground truth instead of letting the model infer clusters from the
 * raw list. Key = first alphanumeric run of the lowercased name; groups with
 * at least two members, largest first then alphabetical. Orientation-only:
 * nomination authority stays with the LLM and the candidate-pool gates.
 */
export declare function computePrefixClusters(names: ReadonlyArray<string>): Array<{
    key: string;
    members: string[];
}>;
//# sourceMappingURL=quality.d.ts.map