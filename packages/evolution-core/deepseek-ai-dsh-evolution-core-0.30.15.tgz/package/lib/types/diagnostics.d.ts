export declare const DIAGNOSTICS_VIEW_SCHEMA_VERSION: 2;
export declare const DIAGNOSTICS_FACT_KEYS: readonly ["platform-line", "family-version", "install-form", "preset-ids", "readonly-contract", "upgrade-order", "fallback-map"];
export declare const DIAGNOSTICS_RUNTIME_KEYS: readonly ["subagent-channel", "restricted-preset", "host-surface", "session-fold", "platform-services", "runs", "platform-pairing", "install-form-detected"];
export type DiagnosticsFactKey = (typeof DIAGNOSTICS_FACT_KEYS)[number];
export type DiagnosticsRuntimeKey = (typeof DIAGNOSTICS_RUNTIME_KEYS)[number];
export type DiagnosticStatus = 'ok' | 'warn' | 'fail' | 'unknown';
export interface DocFactRow {
    readonly key: DiagnosticsFactKey;
    readonly label: string;
    readonly value: string;
    readonly home: string;
}
export interface DiagnosticRow {
    readonly key: DiagnosticsRuntimeKey;
    readonly label: string;
    readonly status: DiagnosticStatus;
    readonly detail?: string;
    readonly remedy?: string;
}
export interface DiagnosticsView {
    readonly schemaVersion: typeof DIAGNOSTICS_VIEW_SCHEMA_VERSION;
    readonly generatedAt: string;
    readonly facts: readonly DocFactRow[];
    readonly runtime: readonly DiagnosticRow[];
}
//# sourceMappingURL=diagnostics.d.ts.map