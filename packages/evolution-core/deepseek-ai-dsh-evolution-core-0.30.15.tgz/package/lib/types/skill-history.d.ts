/**
 * Skill content history: content-addressed blobs plus a per-skill version index.
 *
 * Why it exists: `.mutations.json` records before/after HASHES and calls every automated edit
 * "reviewable and replayable" — but a hash cannot be replayed. With no content store, the only way
 * back was a whole-tree snapshot (`.backups`, keep=5) or `.archive` (removed skills only), so
 * reverting one skill cost the collateral of every other change in that window. This module keeps
 * the content, keyed by skill and version.
 *
 * Invariants (design `dsh-evolution-skill-history-design.md` §1):
 *  - HISTORY IS HISTORY: the skill tree stays the single truth for "current content"; nothing here
 *    feeds a judgment — callers read back content and version NUMBERS only.
 *  - BEST-EFFORT, like the mutation audit: a failed history write warns and never fails the write
 *    that already landed.
 *  - Blobs are content-addressed, so identical bodies are stored once (across skills too).
 *  - Versions are numbered by `v` (max+1), NOT by the clock: a moved system clock must not reorder
 *    history (KiroCrew's `v<N>` choice, independently arrived at). Numbering and the index read-modify-write run
 *    under the INDEX's own io lock, so two writers of one skill cannot mint the same number.
 *  - The array's ORDER is append order, and the index is appended after the content lock is released, so two
 *    writers of ONE skill can interleave their appends. Each entry therefore carries `beforeHash` — the content
 *    it replaced, read under that writer's lock — and that link, not the position, is what `undo` follows
 *    ({@link orderVersions} rebuilds the content order for display when the chain is complete).
 *
 * NOT here: blob garbage collection. Trimming drops INDEX entries; orphan blobs stay until a
 * sweeper collects them, because a reference count would have to span every skill's index and that
 * belongs to the curator's whole-library pass, not to the write path.
 * @module @deepseek-ai/dsh-evolution-core/skill-history
 */
import { type EvolutionIoLike } from './io.ts';
/** Root-level history directory. Dot-prefixed so skill discovery skips it. */
export declare const HISTORY_DIR = ".history";
/** Versioned index shape, so a future field can migrate without guessing. */
export declare const HISTORY_INDEX_VERSION = 1;
/** The action label for a predecessor the index had never seen (content found on disk before this
 * feature existed, or a hand-edited tree): it says "this is what was there", not what wrote it. */
export declare const BASELINE_ACTION = "baseline";
/** G3b: one unit's head. Exactly one of the two forms is present (they never coexist). */
export interface UnitHead {
    /** Representative shard: the unit's WHOLE manifest of moves (one entry per written path). */
    moves?: readonly Readonly<Record<string, unknown>>[];
    /** Representative shard: the skills this unit wrote, so members resolve without a directory scan. */
    sources?: readonly {
        readonly skill: string;
        readonly dest?: string;
    }[];
    /** Cross-skill landmark: the skill that owns the unit (route-only; never carries `moves`). */
    skill?: string;
}
/** One recorded version of one skill. */
export interface SkillVersion {
    /** Monotonic per skill; the identity, unlike {@link SkillVersion.at}. */
    v: number;
    at: string;
    /** G3a: the unit this entry belongs to (one tree change = one unit); absent on entries recorded before it. */
    unitId?: string;
    /** G3b: the unit HEAD. A representative shard carries `{ moves, sources }` (`moves` is the whole
     * manifest of the unit, `sources` names the skills it wrote); a cross-skill landmark carries
     * `{ skill }` only, and the two forms are mutually exclusive. Discriminate on `moves !== undefined`
     * (a landmark also carries `unitId`, so that field can never discriminate). */
    unitHead?: UnitHead;
    /** The mutation that produced it (`create`/`update`/`patch`/…), or {@link BASELINE_ACTION}. */
    action: string;
    /** sha256 of the stored content. */
    hash: string;
    /** Content length in characters, so a listing needs no blob read. */
    chars: number;
    /** The content this write REPLACED, as its hash — absent on a create, on a baseline, and on any
     * entry written before 0.10.0. The array's ORDER is append order, which two writers of one skill
     * can interleave (the index is appended after the content lock is released); this link is computed
     * from the bytes a write lock actually read, so it is the authoritative predecessor. */
    beforeHash?: string;
    /** One line saying what this write changed, when the deployment turned the summarizer on
     * (registry `skillVersionSummary`). Absent is a first-class state: the faces say so instead of
     * inventing a sentence, and a version recorded before the feature existed simply has none. */
    summary?: string;
    /**
     * Which support file these bytes came from, RELATIVE to the skill directory (`references/foo.md`),
     * when this entry records a support-file write or remove. Absent is a first-class state: content
     * versions never carry it, and every entry recorded before this field existed has none — the bytes
     * in the blob store do not carry the name, so a legacy entry stays nameless rather than guessed.
     */
    path?: string;
}
/** One history write, carrying the content the caller already holds. */
export interface VersionRecordInput {
    skillName: string;
    action: string;
    /** Content before the mutation, or null when there was none (create/restore). */
    before: string | null;
    /** Content after the mutation, or null when there is none (archive/remove_file). */
    after: string | null;
    at: string;
    /** The one-line summary of THIS write, or undefined when the deployment does not summarize. */
    summary?: string;
    /** The support file this write touched, relative to the skill directory; undefined for content. */
    path?: string;
    /** G3a: the unit this write belongs to — one tree change writes N paths under ONE id. */
    unitId?: string;
    /** G3b: present only on the unit's representative shard (see {@link SkillVersion.unitHead}). */
    unitHead?: UnitHead;
}
/** The version numbers one write produced; a side with no content contributes nothing. */
export interface RecordedVersions {
    beforeVersion?: number | undefined;
    afterVersion?: number | undefined;
}
/** The root-level history directory. */
export declare function historyRoot(root: string): string;
/** Content-addressed blob path: identical bodies share one file, across skills too. */
export declare function blobPath(root: string, hash: string): string;
/** One skill's index file. */
export declare function historyIndexFile(root: string, name: string): string;
/**
 * The versions in CONTENT order (oldest first), rebuilt from the chain links, for display.
 *
 * The stored array is append order, which interleaves when two writers of one skill audit out of
 * order; the links say what actually replaced what. The rebuild runs only when it can account for
 * EVERY entry (exactly one start and a forward link for each step) — otherwise the stored order is
 * returned unchanged, because a partial reconstruction would be a worse answer than the honest one.
 * @param versions - the stored index, oldest first as recorded.
 * @returns the same entries, in content order when the chain is complete.
 */
export declare function orderVersions(versions: readonly SkillVersion[]): SkillVersion[];
/** Which artifact one recorded version holds.
 *
 * `content` is the skill's own SKILL.md body. `support` is a support file's bytes: a `write_file`
 * or `remove_file` mutation stores them in the SAME index as the body's versions, so a skill that
 * ever wrote a support file has two chains in one index. `other` is an entry whose action does not say
 * which artifact the bytes belong to — a `baseline` predecessor found on disk, or an action that
 * records no content of its own (`pin`/`unpin`/`archive` record only predecessors).
 *
 * The split is FAIL-CLOSED: an action this module does not know reads as `other` rather than being
 * assumed to be the body, so a caller that offers "restore this version" never advertises bytes the
 * index cannot vouch for. `tests/skill-history.spec.ts` pins every action the library can write, so a
 * new one cannot land unclassified. */
export type VersionTarget = 'content' | 'support' | 'other';
/**
 * Which artifact one recorded version holds, from the action that produced it.
 * @param action - the entry's action label.
 * @returns the artifact class; `other` when the label does not say.
 */
export declare function versionTarget(action: string): VersionTarget;
/**
 * Which artifact one INDEX ENTRY holds.
 *
 * {@link versionTarget} reads the ACTION, which is enough for the entries a write mints under its own
 * label and is NOT enough for a {@link BASELINE_ACTION}: a baseline minted for a support write holds
 * that FILE's previous bytes while its action says only "this is what was there". Two facts recover
 * the artifact:
 *
 *  - `path` is written exactly when the bytes come from a support file, on BOTH entries one support
 *    write can mint, so it decides on its own;
 *  - an entry recorded before `path` existed has none, and the link is the evidence left: a support
 *    write names the content it replaced through `beforeHash`, so a baseline that a support write
 *    names as its predecessor holds that file's bytes.
 *
 * The inference runs only for a baseline. Every other entry keeps the action's verdict, which is also
 * the fail-closed one for an action this module does not know.
 * @param entry - one entry of a skill's index.
 * @param index - the index the entry came from: the legacy link is only readable across the whole
 *   index. Omitting it answers from `path` and the action alone.
 * @returns the artifact class; `other` when nothing attributes the bytes.
 */
export declare function entryTarget(entry: SkillVersion, index?: readonly SkillVersion[]): VersionTarget;
/** The versions of one skill, split by the artifact they hold. */
export interface VersionGroups {
    /** The body's versions, plus predecessors no evidence attributes to a support file. */
    readonly content: SkillVersion[];
    /** Support-file versions: real history, but not restorable over SKILL.md. */
    readonly support: SkillVersion[];
}
/**
 * Split one index into the skill body's chain and the support files' versions.
 *
 * Both share ONE index, so a skill that ever wrote a support file has two chains and
 * {@link orderVersions} cannot account for every entry (it falls back to the stored order). Splitting
 * first lets each group rebuild its own order, and keeps the body's chain intact by leaving every
 * entry whose artifact nothing attributes in it — a `baseline` predecessor is usually the body's
 * first link, and only the support-file baselines {@link entryTarget} recovers leave it.
 * @param versions - the stored index, oldest first as recorded.
 * @returns the two groups, each in content order when its chain is complete.
 */
export declare function partitionVersions(versions: readonly SkillVersion[]): VersionGroups;
/**
 * When this skill's content last changed: the newest `at` across BOTH chains, or null when the index
 * holds nothing.
 *
 * The stored array is APPEND order and two writers of one skill can interleave, so the answer is the
 * maximum timestamp rather than the tail. Every `at` this family writes is the same ISO-8601 UTC
 * form, so comparing the strings is comparing the instants.
 * @param versions - every entry the index holds, in any order.
 * @returns the newest timestamp, or null when there is none to report.
 */
export declare function latestVersionAt(versions: readonly SkillVersion[]): string | null;
/** What one index file's bytes said. `absent` (no file yet) and `unreadable` (bytes that cannot be
 * understood: malformed JSON, a foreign shape, an entry this reader would have to drop, or a writer
 * NEWER than this reader) are DIFFERENT facts — the recorder must never replace the second with an
 * index derived from "nothing", so it preserves those bytes instead. */
export type HistoryIndexState = {
    readonly kind: 'ok';
    readonly versions: SkillVersion[];
} | {
    readonly kind: 'absent';
} | {
    readonly kind: 'unreadable';
};
/**
 * Read one index body for a RECORDER: "understood", "no file", or "cannot be understood".
 * A file whose shape is right but which carries an entry this reader would have to drop counts as
 * unreadable — dropping it silently would be the overwrite the audit posture forbids.
 * @param raw - the index file's bytes, or null when absent.
 * @returns the three-state answer.
 */
export declare function readHistoryIndex(raw: string | null): HistoryIndexState;
/**
 * Parse one index body for a READER. Malformed content, a foreign shape, or a version NEWER than this
 * reader all read as empty — the audit posture: never guess. A recorder must use
 * {@link readHistoryIndex} instead, because it has to PRESERVE bytes it cannot understand.
 * @param raw - the index file's bytes, or null when absent.
 * @returns the versions, oldest first.
 */
export declare function parseHistoryIndex(raw: string | null): SkillVersion[];
/**
 * The index after this write, and the version numbers it produced. Pure, so the versioning rules
 * are testable without io.
 *
 * Two rules matter here: a predecessor the index has never seen gets a BASELINE entry (so the state
 * before this mutation is recoverable even for a skill that predates the feature), and re-writing
 * identical content mints NO new version (the library's no-op updates must not grow history).
 * @param versions - the current index, oldest first.
 * @param input - the write being recorded.
 * @param keep - how many versions to retain per skill.
 * @returns the trimmed index and the recorded numbers.
 */
export declare function nextHistoryIndex(versions: readonly SkillVersion[], input: VersionRecordInput, keep: number): {
    versions: SkillVersion[];
    recorded: RecordedVersions;
};
/** Shrink level at which the retention line speaks: a body that keeps less than this share of the
 * previous one is a rewrite, not an edit. */
export declare const RETENTION_FEEDBACK_KEEP_RATIO = 0.5;
/** Floor on the REPLACED body: below this a ratio is noise (a 40-character skill cut in half is not
 * news), so the line stays off for small skills. */
export declare const RETENTION_FEEDBACK_MIN_CHARS = 200;
/** What {@link contentRetentionFeedback} reads: the one write it describes. */
export interface RetentionFeedbackInput {
    /** The skill's name, for the sentence. */
    readonly name: string;
    /** The action that produced the write; only a whole-body replacement is described. */
    readonly action: string;
    /** The replaced body, or null when the skill had none (create / restore). */
    readonly before: string | null;
    /** The body now on disk, or null when it was removed (archive / remove_file). */
    readonly after: string | null;
}
/**
 * The anti-overwrite feedback line (design §4, item 3): says how much of the previous body a
 * replacement kept, so a destructive rewrite is visible in the same message that reports the write.
 *
 * Computed where the replaced bytes are still in hand — the write path's own in-lock read — instead of
 * re-reading the file from a caller (that second read would race the writers this library serializes).
 * It is FEEDBACK, never a gate: no ratio refuses a write, and the function owns no configuration
 * (a toggle nobody reads would be configuration that does nothing).
 *
 * @param input - the write being described.
 * @returns the line, or null when the write is not a significant whole-body replacement.
 */
export declare function contentRetentionFeedback(input: RetentionFeedbackInput): string | null;
/**
 * Read one skill's versions, oldest first.
 * @param root - the skills root.
 * @param io - the io seam.
 * @param name - the skill name.
 * @returns the versions; an absent or unreadable index reads as empty (never a throw).
 */
export declare function loadVersions(root: string, io: EvolutionIoLike, name: string): Promise<SkillVersion[]>;
/**
 * One version's content.
 * @param root - the skills root.
 * @param io - the io seam.
 * @param name - the skill name.
 * @param v - the version number.
 * @returns the content, or null when the version or its blob cannot be read (never '').
 */
export declare function loadVersionContent(root: string, io: EvolutionIoLike, name: string, v: number): Promise<string | null>;
/**
 * Record the content one mutation produced, best-effort.
 *
 * Blobs are written FIRST: the index must never reference content that is not on disk, and a failed
 * blob write aborts the whole record (the caller warns; the mutation itself stands).
 * @param root - the skills root.
 * @param io - the io seam.
 * @param input - the write being recorded.
 * @param keep - how many versions to retain per skill.
 * @returns the version numbers, or null when there was no content to record.
 */
export declare function recordVersions(root: string, io: EvolutionIoLike, input: VersionRecordInput, keep: number): Promise<RecordedVersions | null>;
/** What kind of change one recorded version carries, as a CLOSED set. */
export type VersionActionKind = 'baseline' | 'create' | 'patch' | 'update' | 'restore' | 'delete' | 'archive' | 'consolidate' | 'restructure' | 'merge' | 'support-write' | 'support-remove' | 'other';
/**
 * Classify one version action for display. Fail-closed like {@link versionTarget}: an action this
 * module does not know reads as `other` rather than being guessed, and `tests/skill-history.spec.ts`
 * pins every action the library can write, so a new one cannot land unclassified.
 * @param action - the entry’s action label.
 * @returns the kind the faces switch on.
 */
export declare function versionActionKind(action: string): VersionActionKind;
/** One changed region between two bodies — the shape the platform’s diff card eats. */
export interface TextDiffHunk {
    readonly path: string;
    readonly oldText: string;
    readonly newText: string;
}
/** What one whole-body replacement changed, as facts. */
export interface TextDiffFacts {
    readonly linesAdded: number;
    readonly linesRemoved: number;
    readonly hunks: readonly TextDiffHunk[];
    /** True when a changed region was longer than the window, so its text is a prefix. */
    readonly truncated: boolean;
}
/** Lines one changed region may carry before it is windowed and flagged. */
export declare const TEXT_DIFF_MAX_LINES = 40;
/** Characters one windowed side may carry, so a single enormous line cannot travel whole. */
export declare const TEXT_DIFF_MAX_CHARS = 4000;
/**
 * The facts of one whole-body replacement: how many lines the changed region gained and lost, and
 * that region itself as one hunk.
 *
 * The algorithm is the honest one for "what did this edit touch": common leading and trailing lines
 * are trimmed away and what remains is ONE contiguous region. It is not a minimal edit script — a
 * body edited in two distant places reports their span as one region — and that limitation is the
 * reason the faces show the region as context rather than as a line-by-line proof.
 * @param before - the body the write replaced.
 * @param after - the body the write stored.
 * @param path - the path the hunk names (the platform’s diff card requires one).
 * @param maxLines - the window a region’s text is capped to.
 * @returns the counts, the windowed hunk, and whether the window cut anything.
 */
export declare function textDiffFacts(before: string, after: string, path: string, maxLines?: number): TextDiffFacts;
/** Characters one generated summary may carry. */
export declare const VERSION_SUMMARY_MAX_CHARS = 80;
/**
 * The fixed prompt the optional per-write summarizer runs (registry `skillVersionSummary`).
 *
 * Model-visible, so it is written from the model’s perspective and pinned: the tests assert that it
 * carries the skill name, the character cap and both bodies, because a silent change to a prompt is a
 * silent change to what every recorded version says.
 * @param input - the skill, the action, and the two bodies (null when absent).
 * @returns the prompt text.
 */
export declare function versionSummaryPrompt(input: {
    name: string;
    action: string;
    before: string | null;
    after: string | null;
}): string;
/**
 * Reduce a model answer to the one line the index stores.
 * @param raw - the model’s answer, whatever shape it came in.
 * @param maxChars - the character cap.
 * @returns the one line, or undefined when there is nothing usable (callers store no summary).
 */
export declare function normalizeVersionSummary(raw: string, maxChars?: number): string | undefined;
/** A relative age, in the shape the platform’s own `relativeTime(at, now)` returns. */
export interface RelativeAge {
    readonly unit: 'now' | 'minutes' | 'hours' | 'days' | 'months' | 'years';
    readonly n: number;
}
/**
 * How long ago an ISO timestamp was, as a bucket plus a count — never as a sentence.
 *
 * The shape deliberately mirrors the platform’s `relativeTime` (`ui-primitives`), so a face that later
 * may import the platform helper swaps one call and keeps its dictionary; the WORDS live in the
 * faces (the panel’s locale dictionary, the command surface’s English), which is why this module
 * returns numbers.
 * @param at - an ISO timestamp, or any string `Date.parse` understands.
 * @param nowMs - the reference instant.
 * @returns the bucket and its count; an unparsable timestamp reads as `now` with 0.
 */
export declare function elapsedSince(at: string, nowMs: number): RelativeAge;
//# sourceMappingURL=skill-history.d.ts.map