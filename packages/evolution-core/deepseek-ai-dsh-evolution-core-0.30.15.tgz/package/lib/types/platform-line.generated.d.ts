/** The frozen platform line this release targets (peers/engines/anchors derived from version+floor). */
export declare const PLATFORM_LINE: {
    readonly version: "0.2.1-rc.2";
    readonly floor: "0.2.1-rc.1";
    readonly previousAnchor: "0.2.0-rc.2";
    readonly peersRange: "^0.2.1-rc.1";
    readonly enginesRange: ">=0.2.1-rc.1 <0.2.2-0";
    readonly upstreamRef: "dsh-v0.2.1-rc.2";
};
//# sourceMappingURL=platform-line.generated.d.ts.map