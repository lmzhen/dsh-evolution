/**
 * Structural IO seam for the evolution plugin family.
 *
 * Every evolution package passes `ctx.evolutionIo.provider()`; standalone
 * consumers (and the core's own tests) can use `nodeEvolutionIo`.
 */
import { open } from 'node:fs/promises';
export interface EvolutionIoLike {
    readText(path: string): Promise<string | null>;
    writeText(path: string, content: string): Promise<void>;
    remove(path: string): Promise<void>;
    list(path: string): Promise<string[]>;
    exists(path: string): Promise<boolean>;
    rename(path: string, destination: string): Promise<void>;
    copy(path: string, destination: string): Promise<void>;
    /**
     * Optional byte-size probe for the read guard. Return the file's size in
     * bytes, or `null` when the file does not exist (ENOENT/ENOTDIR);
     * V8-23⑨ (0.3.49): the doc claimed "stat failure → null" but the
     * implementation propagates other stat errors — only missing-file is a
     * "guard not applicable" signal, a real stat failure is an IO error.
     * An implementation without this probe gets no guard: consumers treat an
     * unknown size as "guard not applicable".
     */
    size?(path: string): Promise<number | null>;
    /**
     * Optional atomic read-modify-write on one file: the read and the write run
     * inside a single cross-process lock, so two processes that share DSH_HOME
     * cannot interleave their RMW sequences. `task` receives the current content
     * (`null` when missing) and returns the next content; returning `null`
     * deletes the file. A backend without it falls back to plain read+write and
     * the caller keeps its single-process chain as the second layer.
     * 0.3.16: sync returns are allowed (0.3.16 S1.14 X-1 — mutated callers with
     * no await in the task need no Promise residue).
     */
    transact?(this: void, path: string, task: (current: string | null) => string | null | Promise<string | null>): Promise<void>;
    /**
     * Optional symlink probe (G7). `true` = the path is a symlink, `false` = a
     * real entry, `null` = guard not applicable (backend without the probe or
     * the path does not exist). Consumers treat `null` as "let it through".
     */
    isSymlink?(this: void, path: string): Promise<boolean | null>;
    /**
     * Optional mtime-generation probe (0.3.18, E-71): the path's mtime in
     * milliseconds since epoch, or `null` when unknown (unsupported backend,
     * missing path, stat failure). Intended as a cheap invalidation stamp for a
     * cached directory listing; a backend without it keeps event-driven
     * invalidation only. v20 correction: the former "NO in-tree consumer" note
     * (V9-07, 0.3.51) went stale — in-tree consumers exist, and a
     * custom backend that omits `mtime` degrades them silently (every call
     * site is optional-call + null-fallback, so omission stays legal):
     *   - evolution-curator: run-report recency ordering (2 call sites);
     *   - evolution-commands: `.bak` freshness probe in the preset installer.
     * S3-P2-10: evolution-skill-catalog's summaries stamp — the third consumer —
     * moved to a NAMES-based stamp over `list()` (a required seam method): the
     * root-mtime stamp was invalidated by the family's own sidecar flushes in
     * the watched root, so every usage-counter write paid a full rescan. The
     * names stamp is sidecar-immune and works on mtime-less backends. Register
     * new consumers here (the seam contract).
     */
    mtime?(this: void, path: string): Promise<number | null>;
}
/**
 * Run `task` inside `io.transact` when the backend provides it; otherwise fall
 * back to a plain read → task → write/remove sequence (no cross-process lock —
 * callers keep their single-process serialize chain as the second layer). A
 * byte-identical task result skips the write (C-07 — parity with the
 * node backend's V5-03 short-circuit).
 */
export declare function transactIo(io: EvolutionIoLike, path: string, task: (current: string | null) => string | null | Promise<string | null>): Promise<void>;
/**
 * V43 F-4 (S0-6): the shared "the transaction really invoked the task" guard.
 * A backend that implements `transact` but never calls `task` resolves
 * cleanly, so every caller that reads the outcome out of the task itself (a
 * result slot filled inside it, a `Promise<void>` save path) reported success
 * for a write that never happened — the silent-lost-write family the inline
 * C-01 (memory-store) and V6-19 (skill-store) guards cover one call site at a
 * time. Wrap the task handed to `transactIo`/`io.transact` and probe after
 * the call: `invoked()` for a path that owns a structured refusal, or
 * `assertInvoked()` for a void-returning path with no result channel (the
 * family's fail-loud discipline, same wording as skill-store's guard).
 *
 * The wrapper is an identity pass-through — neither the backend nor the task
 * sees a difference — and a task that IS invoked but skips the write (a
 * dedupe no-op) counts as invoked: the probe answers "did the write path get
 * to decide", not "did bytes change".
 * @param what - the write being attempted, named in the thrown message
 */
export interface TransactTaskGuard {
    /** Wrap the task handed to the transact backend, marking its invocation. */
    wrap<A, R>(task: (current: A) => R): (current: A) => R;
    /** Did the backend invoke the wrapped task? */
    invoked(): boolean;
    /** Throw when the backend never invoked it (nothing was written). */
    assertInvoked(): void;
}
/** Build a {@link TransactTaskGuard} for one write path. See its doc. */
export declare function transactTaskGuard(what: string): TransactTaskGuard;
/** Lazy adapter over an IO provider registry, shared by every evolution consumer. */
export declare function evolutionIoAdapter(provider: () => EvolutionIoLike): EvolutionIoLike;
/**
 * Retry a rename that a peer is temporarily holding on Windows (EPERM/EBUSY):
 * exponential backoff (50ms doubling, capped at 800ms) with a ~2s total
 * budget, matching the write-lock cadence (C-28 — the old 3x50ms
 * budget turned a transient antivirus hold into a permanent write failure).
 * A non-transient code surfaces immediately; a persistent EPERM/EBUSY
 * rethrows with a pointer at the usual causes instead of a bare errno.
 * `fn` is the rename primitive, injectable for deterministic tests.
 *
 * v22 (LOCK-5) documented platform limit: POSIX rename-over-existing is
 * atomic for concurrent READERS, but Windows MoveFileExW(REPLACE_EXISTING)
 * can make the target briefly invisible (ENOENT) while the replacement is in
 * flight. The retry budget above covers the WRITE side only — a LOCKLESS
 * reader (`readText`/`readJson` on a path it does not hold the lock for) can
 * observe that window and see "missing" for a file that was just committed.
 * Verified harmless today: every lockless-read consumer treats the transient
 * miss as self-healing state (no consumer persists a read of null into a
 * write), and distinguishing that ENOENT from a genuinely absent file in
 * `readText` would tax every ordinary missing-file probe. Revisit only if a
 * consumer appears that must never transiently miss.
 *
 * @param tmp - the source path to rename.
 * @param target - the destination path.
 * @param fn - the rename primitive (defaults to `node:fs/promises.rename`).
 * @returns a promise that resolves once the rename succeeds.
 */
export declare function renameWithRetry(tmp: string, target: string, fn?: (from: string, to: string) => Promise<void>): Promise<void>;
/**
 * V10-06 (P1-1): the crash-durable tmp half of the upstream storage-json
 * `writeAtomic` protocol (storage-json/src/atomic.ts:24-40): exclusive-create
 * a same-directory tmp (`wx` — never clobbers), write, `handle.sync()`,
 * close, then hand the tmp to `commitTmp` for the rename. Without the fsync a
 * power loss could land the rename (metadata) before the data blocks and
 * leave an empty/truncated target — which the state-json E-9 quarantine then
 * amplifies into a permanent fail-loud. The tmp name keeps the
 * `<target>.<pid>.<rand>.tmp` shape so sweepStaleTmps keeps matching.
 * Mode parity note: no explicit mode is passed (upstream uses 0o600) — this
 * seam also writes operator-editable skill/memory files, so the previous
 * `writeFile` default (0o666 & ~umask) is deliberately preserved.
 * `openImpl` is injectable so the sync-failure regression test can drive a
 * failing `handle.sync()` deterministically.
 */
export declare function writeDurableTmp(target: string, content: string, openImpl?: typeof open): Promise<string>;
/**
 * True when the pid is alive (EPERM = alive but unowned; ESRCH = gone).
 * V18 single source: the node backend's lock takeover and SkillLibrary's
 * stranded-lock sweep must use the same liveness rule.
 */
export declare function isProcessAlive(pid: number): boolean;
/**
 * V27 G1.3: the error `commitTmp` throws when the rename landed but the parent
 * directory fsync failed — the bytes ARE visible, only their durability is
 * unconfirmed. A consumer that treats it as a plain failure reports "not
 * written" for a write that happened (and a two-phase caller may try to roll
 * back a visible write). Every transaction consumer must therefore treat this
 * shape as SUCCESS-with-warning, never as a rejection.
 */
export declare function isCommittedWarning(error: unknown): boolean;
/**
 * Build the Node IO backend: plain fs promises, durable tmp + rename commits (crash atomicity) and
 * ONE concurrency guarantee of its own — writes to the same path are serialized in-process (see
 * `inProcessWrite`). G2 S4 removed the cross-process write lock and its takeover protocol; the
 * plugin path gets cross-process safety from the platform provider (`ctx.fs`).
 */
export declare function nodeEvolutionIo(): EvolutionIoLike;
/** F-211: the fs surface atomicWriteFiles uses — injectable so the commit-phase
 * rename-failure path is deterministically testable. Defaults to node:fs.
 * `mtime` (optional) probes a path's last-write time so the failed-commit
 * recovery message can name the generation it restored from. */
interface FsOps {
    writeFileSync(path: string, data: string | Uint8Array): void;
    existsSync(path: string): boolean;
    copyFileSync(from: string, to: string): void;
    renameSync(from: string, to: string): void;
    rmSync(path: string, options?: {
        force?: boolean;
        recursive?: boolean;
    }): void;
    mtime?(path: string): number | null;
}
/**
 * S6.3 (E-40): atomically replace a set of files within one directory.
 * Each file is staged to a sibling `<name>.tmp`, then renamed into place
 * (atomic on the same filesystem); a pre-existing file keeps a single
 * `<name>.bak`. A failure at ANY staging step removes the staged temps and
 * leaves the previous files untouched — a half-written target is impossible
 * up to the staging and backup phases.
 *
 * F-211: the rename COMMIT phase does not carry the same guarantee. When a
 * filesystem refuses to overwrite the destination, the code removes it and
 * retries the rename; if the retry ALSO fails the destination is gone. The
 * single `.bak` created above still holds the previous content, so the target
 * is restored from it (best-effort) before the original rename error is
 * rethrown, so a failed commit never leaves the file missing.
 *
 * V4-17: the `.bak` is refreshed to the committed content after every
 * successful commit, so a later failed commit always recovers to the most
 * recent good generation (a once-at-first-install `.bak` could otherwise
 * restore content several installs old). The recovery error names the `.bak`
 * source (and mtime when available) so the caller knows the generation it
 * restored from.
 */
export declare function atomicWriteFiles(targetDir: string, writes: Array<{
    name: string;
    content: string | Uint8Array;
}>, fs?: FsOps, logger?: (message: string) => void): void;
export {};
//# sourceMappingURL=io.d.ts.map