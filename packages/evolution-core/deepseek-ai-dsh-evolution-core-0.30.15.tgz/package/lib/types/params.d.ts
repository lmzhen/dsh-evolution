/**
 * Parameter id consolidation (G0/S0.2): one semantic gets ONE id.
 *
 * Nine places in this family carry the same value under two carriers: three use
 * the SAME name in two carriers (reviewMode, staleAfterDays, archiveAfterDays —
 * resolved by the existing policy-shadows-row rule) and six use DIFFERENT names.
 * This module owns the six: the policy/snapshot name is the canonical id, the
 * plugin-row name is a deprecated alias kept readable since 0.6.x. Removal was
 * planned for 0.7.0 and is deferred: the aliases still ship, so no later version
 * is claimed here.
 *
 * Reading stays compatible (a carrier still spelling the legacy name resolves),
 * writing is strict (the write path accepts canonical ids only, so no new
 * document is created under a deprecated name).
 * @module
 */
/** Deprecated alias (plugin-row name) -> canonical id (policy/snapshot name). */
export declare const PARAM_ALIASES: Readonly<Record<string, string>>;
/**
 * Resolve any parameter id to its canonical form.
 * @param id - canonical id or deprecated alias.
 * @returns the canonical id; ids without an alias pass through unchanged.
 */
export declare function resolveParamId(id: string): string;
/**
 * Whether an id is a deprecated alias.
 * @param id - parameter id to test.
 * @returns true when the id must be migrated to its canonical form.
 */
export declare function isDeprecatedParamId(id: string): boolean;
/**
 * Guard for the write path: only canonical ids may be written.
 * @param id - parameter id a caller intends to write.
 * @returns the canonical id.
 * @throws {Error} when the id is a deprecated alias; the message names both ids.
 */
export declare function canonicalWriteId(id: string): string;
/**
 * Read a parameter from a carrier that may still spell the legacy name.
 * @param carrier - config/snapshot object to read from, or undefined.
 * @param id - canonical id (a deprecated alias is accepted and resolved first).
 * @returns the canonical value when present, else the alias value, else undefined.
 */
export declare function readParam(carrier: object | undefined, id: string): unknown;
/** Exposure group (design §7.2): the unit a developer changes together.
 *
 * A DOC-SECTION axis, not the exposure decision: the group says which family of knobs a value
 * belongs to, the tier says who may change it. `internal` here is a group id with no rows today;
 * the `why: 'internal'` a non-E3 row carries is a different value on the other axis (the reason it
 * has no settings card) — the shared spelling is a coincidence, not a routing rule. */
export type ParamGroup = 'library' | 'write-caps' | 'review' | 'memory' | 'curator' | 'deployment' | 'merge' | 'internal';
/**
 * Chinese display name per group, one entry per line (the scripts read this block
 * by text, the same way they read PARAM_NAMESPACES). The raw group id is what
 * `--group` accepts and what the JSON face reports; this only names it on screen.
 */
export declare const PARAM_GROUP_LABELS: Readonly<Record<ParamGroup, string>>;
/** Exposure tier (design §7.1): the interface combination a parameter gets. */
export type ParamTier = 'E0' | 'E1' | 'E2' | 'E3' | 'E4';
/** Where the authoritative value lives. */
export type ParamAuthority = 'code' | 'cordis' | 'install';
/**
 * One parameter's exposure contract (design §8.1).
 *
 * MACHINE-READ CONTRACT: the entries below are written ONE PER LINE with the
 * key order id, group, tier, authority, owner, applies, docAnchor, summary so
 * the .mjs generators (`gen-param-docs.mjs`, `verify-param-registry.mjs`) can
 * parse this text without importing TypeScript. `param-registry.spec.ts`
 * asserts that the parsed text and this runtime array agree, so the two sides
 * cannot drift.
 *
 * `applies` is the SETTINGS-side timing: 'none' means the parameter is not
 * writable through the user layer (a cordis.yml change still follows the
 * deployment's patch-reload policy).
 *
 * UI METADATA (0.7.0): every E3 row carries the tail
 * `label, hint, control, unit, values` — in that order, directly after
 * `summary`, still one entry per line — plus an OPTIONAL trailing
 * `valueLabels` (0.9.0). E3 is the only tier the settings cards render, so the
 * card's Chinese name, help text, control kind, unit suffix and value domain
 * come from THIS registry and nowhere else; the browser half is generated from
 * this text (`gen-param-client-view.mjs`). Non-E3 rows must NOT carry the tail
 * (there is no UI surface for them); `control: 'select'` requires a non-empty
 * pipe-joined `values`, and `valueLabels` — allowed on select rows only — names
 * those values for display, one label per value, in the same order. The stored
 * value is never translated: only what the control shows.
 */
/** Why a parameter has NO settings card (the `why` half of the exposure key, 0.21.0 / G2).
 * `internal` = timeouts, retries, cooldowns, weights, caps and windows; `deployment` = mount
 * switches and library-scope policy; `security` = safety surfaces (never user-writable);
 * `identity` = providers/models/registered names; `path` = per-row directories; `install` = what
 * the installer freezes. Exactly one of `card`/`why` rides every row, and the tier decides which. */
export type ParamWhy = 'deployment' | 'security' | 'identity' | 'path' | 'install' | 'internal';
export interface ParamExposure {
    id: string;
    group: ParamGroup;
    tier: ParamTier;
    authority: ParamAuthority;
    owner: string;
    applies: 'live' | 'restart' | 'none';
    docAnchor: string;
    summary: string;
    /** Card label (Chinese, short). Required on E3 rows. */
    label?: string;
    /** Card help text (Chinese, one sentence). Required on E3 rows. */
    hint?: string;
    /** Which control the card renders for this field. Required on E3 rows. */
    control?: 'number' | 'switch' | 'select' | 'text';
    /** The settings card this row appears on — its OWN row id (the platform keys a card by the Loader
     * entry id, and a card may only render its own row's Config). Required on E3 rows. */
    card?: string;
    /** The registered reason this row has NO card. Required on every non-E3 row; mutually exclusive
     * with `card`. This is what makes "an E3 row that no card renders" unspellable. */
    why?: ParamWhy;
    /**
     * A cross-field constraint this row must satisfy, declared ONCE here (U-4). The card checks it
     * before a save is attempted and the Host write path derives the same check from the same column,
     * so "保存前就知道输入合不合法" needs no second rule table. Only relations with real behaviour
     * behind them are declared; this is not a constraint language.
     */
    relation?: {
        /** The sibling id in the SAME group whose value this row may not go below. */
        readonly atLeast?: string;
    };
    /** Unit suffix shown next to a number (empty when it carries none). */
    unit?: string;
    /** Pipe-joined allowed values; non-empty exactly when control is 'select'. */
    values?: string;
    /**
     * Pipe-joined display names for `values`, same order and count (optional).
     * The stored value stays the raw one; this only names it on the card.
     */
    valueLabels?: string;
}
/**
 * The parameter registry. G1/S1.1 seeds it with the review group (G-C); the
 * remaining groups land in S2.1. E3 = behaviour preference the user may change
 * (live); E2 = resource or identity knob that stays with the deployment.
 */
export declare const PARAM_EXPOSURE: readonly ParamExposure[];
/** The settings namespace each OWNER PACKAGE registers (design §7.2).
 *
 * Keyed by owner rather than by group because a namespace has exactly one
 * registrant (the platform refuses a second registration of the same name),
 * while a group may span packages — group 'memory' is served by memory-files and
 * tool-memory, each owning its own section. A package without an entry has no
 * user layer (its knobs stay deployment-only). */
export declare const PARAM_NAMESPACES: Readonly<Record<string, string>>;
/**
 * The rows whose settings namespace CHANGED with the platform-line move (G3): the
 * platform keys a settings section by the Loader entry id now, while 0.1.x let each
 * plugin register a free-form namespace — this table is the difference, DERIVED from
 * {@link PARAM_NAMESPACES} so freezing a row id renames it in one place.
 *
 * It is the migration's TARGET (`rowId`) and its SOURCE (`namespace`, the section a
 * stored value sits in). Rows whose two names already agree are absent: there is
 * nothing to move for them.
 */
export declare const NAMESPACE_MIGRATIONS: readonly {
    readonly namespace: string;
    readonly rowId: string;
}[];
/**
 * The LEGACY settings namespace one owner package used to register through the family's
 * own seam (0.1.x). It is no longer what the platform calls the section: the platform
 * derives a settings namespace from the Loader entry id, and this registry's `owner` field
 * IS that row id, so a live lookup uses {@link paramRowId}. What remains here is the
 * migration SOURCE (G3 moves a user layer out of this string and into the row id).
 * @param owner - owner package directory name (the map's key).
 * @returns the legacy namespace that owner registered.
 * @throws when the owner has no entry in {@link PARAM_NAMESPACES}.
 */
export declare function paramNamespace(owner: string): string;
/**
 * The settings id one row's user layer lives under, or undefined when the owner publishes
 * no user layer at all (a deployment-only row: its knobs are E2 and never reach a settings
 * section). The platform derives a settings namespace from the Loader entry id and reports
 * it in `settings.describe()` / `configForms.get(entryId)`, and an owner package's row id is
 * its own name — spelled the same in every bundle patch.
 *
 * This is the id to LOOK UP with; {@link paramNamespace} keeps the legacy string the 0.1.x
 * seam registered, which is the G3 migration source and never a live lookup key.
 * @param owner - owner package directory name (the row id).
 * @returns the entry id the platform reports for that row, or undefined for a row without
 *   a user layer.
 */
export declare function paramSettingsId(owner: string): string | undefined;
/**
 * The settings id of a row that MUST have a user layer (an owner reading its own section).
 * @param owner - owner package directory name (the row id).
 * @returns the entry id the platform reports for that row.
 * @throws when the owner publishes no user layer.
 */
/** The keys the USER set in one row's settings namespace (G1 §8.4-A).
 *
 * The settings user layer is read in exactly ONE place, and it reads KEY NAMES, never values: the
 * platform resolves the user layer into the row's live fields, so a value always comes from the
 * row. The precedence rule (user > policy) needs to know WHICH keys the user set, or a deployment
 * policy would silently override the user. S2.9 (T3-10): review and curator each had their own
 * reader, so one key could be resolved two ways.
 * @param ctx - the plugin context (a `get(name)` view is enough).
 * @param rowId - the row's registry namespace (`paramRowId(<package>)`).
 * @returns the keys present in that row's user layer.
 */
export declare function userSetKeys(ctx: {
    get(name: string): unknown;
}, rowId: string): ReadonlySet<string>;
/** ONE key's effective value, in the design's precedence (G1 §8.4-A): the user layer (whose value
 * already arrived through the row's live field) → the deployment policy snapshot → the row itself.
 * S2.9 (T3-10): both readers of the policy row resolve through this, so a new key cannot get one
 * answer on the review side and another on the curator side.
 * @param userSet - the keys the user set (see {@link userSetKeys}).
 * @param row - the row's live fields.
 * @param snapshot - the deployment policy snapshot, when a policy row is mounted.
 * @param key - the key being resolved.
 * @returns the effective value.
 */
export declare function pickWithPolicy<R extends object, K extends keyof R & string>(userSet: ReadonlySet<string>, row: R, snapshot: Partial<Record<K, R[K]>> | undefined, key: K): R[K];
export declare function paramRowId(owner: string): string;
/**
 * Structural view of the platform settings provider: only the members the family
 * still uses are named.
 *
 * G1 removed the family's own settings seam (`installParamSection`): a volatile row
 * field carries the user layer by itself, so what remains is the WRITE face
 * (`update`) and the one read the precedence rule needs — `describe()`, for the KEY
 * NAMES the user set. A value is never read from here. Declared locally so this module
 * keeps its zero-import, zero-dependency shape.
 */
export interface SettingsProviderLike {
    /** Merge a patch into one namespace's user layer. A stale `expectedRevision`
     * rejects with the platform's SETTINGS_CONFLICT error. */
    update?(namespace: string, patch: object, expectedRevision?: number): Promise<void>;
    describe?(options?: {
        redactSecrets?: boolean;
    }): {
        ns: string;
        /** Current resolved section (schema defaults < base < user). */
        value?: unknown;
        /** Raw user section: a key's PRESENCE marks a user override. */
        user?: Record<string, unknown>;
        /** Monotonic revision of that raw section; a write sends it back. */
        revision?: number;
        /** Owner's declared effect timing. */
        applies?: 'live' | 'restart';
    }[];
}
/**
 * Number-typed read over {@link readParam}: the family's tunables are numbers,
 * and a value of another type reads as absent so the caller's default applies
 * (the same outcome the numeric clamps produce for a malformed value).
 * @param carrier - config/snapshot object to read from, or undefined.
 * @param id - canonical id (a deprecated alias is accepted and resolved first).
 * @returns the resolved number, or undefined when absent or not a number.
 */
export declare function readNumberParam(carrier: object | undefined, id: string): number | undefined;
//# sourceMappingURL=params.d.ts.map