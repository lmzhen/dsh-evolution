/**
 * G3b: resolve a unit's members from the skills named in its head's `sources[]`.
 *
 * Pure core (no io): the caller hands in each candidate skill's index TEXT, so this function can be
 * tested with synthetic indexes. Membership is decided ONLY by the known keys -- never by scanning a
 * directory -- and the result order is the `sources[]` order with the head skill first (deterministic:
 * no Map/Set iteration order leaks into the output).
 */
import type { SkillVersion, UnitHead } from './skill-history.ts';
export interface UnitMemberSlice {
    readonly skill: string;
    readonly entries: readonly SkillVersion[];
}
export interface UnitMemberIssue {
    readonly skill: string;
    readonly reason: 'index-absent' | 'unit-absent';
}
export interface UnitConflict {
    readonly kind: 'missing' | 'foreign' | 'duplicated';
    readonly path: string;
}
export interface UnitMembers {
    readonly members: readonly UnitMemberSlice[];
    readonly missing: readonly UnitMemberIssue[];
    readonly conflicts: readonly UnitConflict[];
}
export interface UnitHeadInput {
    readonly skill: string;
    readonly unitId: string;
    readonly sources: readonly {
        readonly skill: string;
    }[];
    readonly unitHead?: UnitHead;
}
/** Candidate skills: head first, then `sources[]` order, DEDUPLICATED (sources may name the head). */
export declare function candidateSkills(head: UnitHeadInput): string[];
export declare function resolveUnitMembersFromIndexes(head: UnitHeadInput, indexes: ReadonlyMap<string, string | null>, readEntries: (text: string) => readonly SkillVersion[]): UnitMembers;
/** A unit's members are trustworthy only when nothing is missing and nothing conflicts. */
export declare function unitMembersAreComplete(members: UnitMembers): boolean;
/** Minimal io view the shell needs (structural, so this module imports no io type). */
export interface UnitMemberIo {
    readText(path: string): Promise<string | null>;
}
/**
 * The io shell (A19.2): open ONLY the known keys -- never enumerate a directory. A skill whose index
 * file is unreadable becomes `null` (index-absent), which the core then reports by name.
 */
export declare function resolveUnitMembers(root: string, io: UnitMemberIo, head: UnitHeadInput, indexPath: (root: string, name: string) => string, readEntries: (raw: string | null) => readonly SkillVersion[]): Promise<UnitMembers>;
/** G3b: a LANDMARK carries the owning skill and no manifest (the two forms never coexist). */
export declare function isLandmark(entry: SkillVersion): boolean;
/** A landmark is jumpable only when its owner exists AND that index still holds the unit. */
export type LandmarkVerdict = {
    readonly jumpable: true;
} | {
    readonly jumpable: false;
    readonly reason: 'not-a-landmark' | 'owner-absent' | 'unit-absent';
};
/** @param entry - the entry being judged. @param ownerEntries - the owner skill's index, or null when
 * the owner has no readable index. */
export declare function landmarkVerdict(entry: SkillVersion, ownerEntries: readonly SkillVersion[] | null): LandmarkVerdict;
/** One cross-index orphan: a landmark whose owner or unit can no longer be reached. */
export interface StaleRouteStub {
    readonly skill: string;
    readonly v: number;
    readonly owner: string;
    readonly reason: 'owner-absent' | 'unit-absent';
}
/**
 * Scan a whole corpus (skill name -> index entries, or null when unreadable) for stale route stubs.
 * Sorted by (skill, version, owner): a function of the corpus, not of the caller's map order.
 */
export declare function staleRouteStubs(indexes: ReadonlyMap<string, readonly SkillVersion[] | null>): StaleRouteStub[];
//# sourceMappingURL=unit-members.d.ts.map