import type { SkillActionResult } from './skill-store.ts';
import type { UnitUndoPlan } from './unit-undo-plan.ts';
export interface UnitUndoSink {
    readSkill(skill: string): Promise<string | null>;
    readSupport(skill: string, path: string): Promise<string | null>;
    /** Read one blob by hash; null means the blob is gone. */
    readBlob(hash: string): Promise<string | null>;
    /** Optional archived-member probe; without it the restore itself is the first proof. */
    hasArchived?(skill: string): Promise<boolean>;
    restoreFromArchive(skill: string): Promise<SkillActionResult>;
    archive(skill: string, reason: string): Promise<SkillActionResult>;
    updateSkill(skill: string, body: string, anchor: {
        sha256: string;
    }): Promise<SkillActionResult>;
    writeSupportFile(skill: string, path: string, content: string, anchor: {
        sha256: string;
    }): Promise<SkillActionResult>;
    removeSupportFile(skill: string, path: string, anchor: {
        sha256: string;
    }): Promise<SkillActionResult>;
}
export interface UnitUndoExecution {
    readonly ok: boolean;
    readonly message: string;
    readonly reverted: readonly string[];
}
export declare function executeUnitUndo(plan: UnitUndoPlan, sink: UnitUndoSink): Promise<UnitUndoExecution>;
//# sourceMappingURL=unit-undo.d.ts.map