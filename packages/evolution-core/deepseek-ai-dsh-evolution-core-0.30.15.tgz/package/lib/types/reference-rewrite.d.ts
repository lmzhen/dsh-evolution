/**
 * Reference re-homing plans (0.5.0 V1, design §16.7).
 *
 * A consolidation moves one skill's body under ANOTHER skill root, where every
 * support-dir reference resolves against that other root (design §2.1). This
 * module plans what has to happen to the support files and to the body's
 * references for the move to leave no dangling link. Pure: the caller owns IO,
 * decides the destination names, and decides whether the plan is applied (V2)
 * or only reported (V1). Cross-skill rewriting is out of scope by design (§14) —
 * a plan covers ONE body.
 */
/** One re-homed support file: source-relative path -> target-relative path. */
export interface ReferenceMove {
    /** Path inside the skill the body comes FROM. */
    from: string;
    /** Path inside the skill the body moves TO. */
    to: string;
}
/** One reference the plan rewrites, in body line order. */
export interface ReferenceRewriteEdit {
    /** 1-based line in the body being moved. */
    line: number;
    /** The resolved target before the move. */
    from: string;
    /** The resolved target after the move. */
    to: string;
    /** The verbatim token as it appears in the body (`raw`), so a rewrite replaces
     * exactly what is there and leaves a trailing `#fragment` in place. */
    raw: string;
}
/** What one consolidation plan does to one body's references. */
export interface ReferenceRewritePlan {
    /** References whose target changes (a re-homed file). */
    edits: readonly ReferenceRewriteEdit[];
    /** Cited files the moves give no destination: applying this plan would dangle. */
    unresolved: readonly string[];
    /** Targets still absent from the target file list after the moves. */
    residualDangling: readonly string[];
    /** The moves the body actually NEEDS: a support file the body never cites stays
     * with the archived package instead of being copied into the target for
     * nothing (upstream's wording is "every needed support file"). */
    moves: readonly ReferenceMove[];
}
/**
 * Provisional re-homing rule. The naming style for re-homed files is still an
 * open decision (design §16.3 B5); this rule only fires on a COLLISION, where
 * something has to give: a path that the target already occupies gets the source
 * name as a prefix (`references/a.md` -> `references/<source>-a.md`). Nested
 * destinations are deliberately avoided: the support listing is one level deep,
 * so a file moved into a subdirectory would drop out of the listing entirely.
 * @param sourceFiles - the moving skill's support files.
 * @param targetFiles - the destination skill's support files.
 * @param sourceName - the moving skill's name, used as the collision prefix.
 * @returns the moves plus the paths that collided (for the report).
 */
export declare function planRehoming(sourceFiles: readonly string[], targetFiles: readonly string[], sourceName: string): {
    moves: ReferenceMove[];
    collisions: string[];
};
/**
 * Plan the reference rewrites for one body that is moving into another root.
 * @param input - the body, the MOVING skill's file list, the re-homing moves and
 *   the destination's file list (with the moved paths already included).
 * @returns the edits, the cited files without a destination, and any target that
 *   the destination file list cannot prove (applying such a plan would dangle).
 */
export declare function planReferenceRewrite(input: {
    content: string;
    files: readonly string[];
    moves: readonly ReferenceMove[];
    targetFiles: readonly string[];
}): ReferenceRewritePlan;
/**
 * Apply a plan's edits to the body (V2). Line-wise and literal: line N gets its
 * FIRST occurrence of the recorded token replaced, everything else is copied
 * byte for byte — no regex, so a token that happens to contain regex
 * metacharacters cannot rewrite more than it matched.
 * @param content - the body the plan was computed against.
 * @param edits - the plan's edits.
 * @returns the rewritten body (identical to the input when there is nothing to do).
 */
export declare function applyReferenceRewrite(content: string, edits: readonly ReferenceRewriteEdit[]): string;
/**
 * One-line, model-facing summary of a plan, for the consolidation refusal and
 * for the V2 apply path's audit text.
 * @param plan - the plan to describe.
 * @returns a compact sentence naming counts, the moves and any residual risk.
 */
export declare function describeReferenceRewrite(plan: ReferenceRewritePlan): string;
//# sourceMappingURL=reference-rewrite.d.ts.map