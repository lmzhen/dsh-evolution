/**
 * The control-plane protection sets, held once and queried everywhere
 * (decision B, rc.44 plan M2): the lifecycle engine, the scope view, the LLM
 * nomination gate and the control-plane consolidate all answer "is this name
 * off limits — and why" from the same instance, so the gate sets can never
 * drift apart the way the three pre-rc.46 implementations did.
 *
 * Scope boundary: a GateSet covers NAME-SET protections only. Marker-based
 * protections (pinned / bundled / hub-installed) are file markers resolved by
 * `SkillLibrary.writeProtection` / `deleteProtection` — they depend on the
 * filesystem and the write origin, not on a name list.
 * @module @deepseek-ai/dsh-evolution-core
 */
type GateReason = 'excluded' | 'referenced' | 'suppressed' | 'protected-builtin';
interface GateSetInputs {
    exclude?: ReadonlySet<string> | undefined;
    referenced?: ReadonlySet<string> | undefined;
    suppressed?: ReadonlySet<string> | undefined;
}
export declare class EvolutionGateSet {
    readonly exclude: ReadonlySet<string>;
    readonly referenced: ReadonlySet<string>;
    readonly suppressed: ReadonlySet<string>;
    constructor(inputs?: GateSetInputs);
    /**
     * The first protection blocking this name, or null. Any hit blocks — the
     * order is diagnostic only, so a name in two sets reports the first.
     */
    blockReason(name: string): GateReason | null;
    isBlocked(name: string): boolean;
}
/** Build a GateSet from the curator-style config field names. */
export declare function createGateSet(config: {
    excludeSkillNames?: ReadonlySet<string>;
    referencedSkillNames?: ReadonlySet<string>;
    suppressedNames?: ReadonlySet<string>;
}): EvolutionGateSet;
export {};
//# sourceMappingURL=gates.d.ts.map