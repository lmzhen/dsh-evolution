export type SessionEventClass = 'model' | 'plugin-record' | 'unknown';
/** Frames the model authored/saw (the only frames evidence, reads and usage accounting may consume). */
import { MODEL_SESSION_EVENT_TYPES } from './tool-dispatch.ts';
export { MODEL_SESSION_EVENT_TYPES as MODEL_SESSION_EVENTS };
/** Classify one session event WITHOUT interpreting it (pure). */
export declare function classifySessionEvent(event: {
    readonly type?: unknown;
    readonly ignorable?: unknown;
}): SessionEventClass;
/** True when the event must be skipped by evidence/usage readers (tolerant, never fatal). */
export declare function isIgnorableEvent(event: {
    readonly type?: unknown;
    readonly ignorable?: unknown;
}): boolean;
//# sourceMappingURL=session-fold.d.ts.map