/**
 * Skill usage telemetry sidecar: `$DSH_HOME/skills/.usage.json`.
 * Format-compatible with Hermes Agent / hermes-claw core fields.
 */
import { type EvolutionIoLike } from './io.ts';
type SkillState = 'active' | 'stale' | 'archived';
export interface UsageRecord {
    created_by: string | null;
    use_count: number;
    view_count: number;
    patch_count: number;
    last_used_at: string | null;
    last_viewed_at: string | null;
    last_patched_at: string | null;
    created_at: string;
    state: SkillState;
    pinned: boolean;
    archived_at: string | null;
    quality_score?: number | undefined;
    quality_warn?: boolean | undefined;
    /** P1-1 (v15): feedback-owned quality signal. Field ownership contract —
     * `quality_score`/`quality_warn` are written ONLY by the curator's
     * six-factor `scoreTree`; `feedback_score`/`feedback_warn` are written ONLY
     * by the feedback channel (`SkillUsageRegistry.setFeedbackQuality`);
     * `foldCuratorFields` refreshes the quality_* pair tree-wide and must never
     * touch feedback_*. The lifecycle engine and the scope view read the UNION
     * of both warn flags, which is what makes negative feedback decision-
     * relevant again. */
    feedback_score?: number | undefined;
    feedback_warn?: boolean | undefined;
    /** Demand evidence per SUPPORT FILE (design §5.5): how many observed reads
     * landed on each `references/…`-style path of this skill. Absent on every
     * record written before this field existed, and on skills whose support
     * files were never read — absence means "no evidence", never "zero demand". */
    support_reads?: Record<string, number> | undefined;
}
export type UsageMap = Map<string, UsageRecord>;
export declare function usageFile(root: string): string;
export declare function emptyRecord(): UsageRecord;
/**
 * Field-level normalization for one sidecar record (rc.42 audit P2-3): the
 * spread used to copy any junk through verbatim, so a corrupted file could
 * carry `use_count: "3"` into the quality math and lifecycle comparisons as
 * NaN. Every field falls back to its `emptyRecord()` baseline unless it has
 * exactly the declared type; an invalid `created_at` anchors the age clock at
 * now (first-sight defer semantics for a record whose age is unknowable).
 * Timestamps additionally require a parseable date (N-3): `"not-a-date"`
 * would otherwise survive the type check as Invalid Date.
 * Pure — exported for unit tests; `loadUsage` is the production caller.
 */
export declare function normalizeUsageRecord(record: unknown): UsageRecord;
/** Sidecar bound: a pathological path set must not grow the usage file forever. */
export declare const MAX_SUPPORT_READ_PATHS = 200;
export declare function loadUsage(root: string, io?: EvolutionIoLike): Promise<UsageMap>;
/**
 * Atomic read-modify-write on the usage sidecar (rc.50 P2-2): `task` receives
 * the map parsed from the current on-disk state and may mutate it; the result
 * is persisted inside the same transact so a second process sharing DSH_HOME
 * cannot interleave its RMW and lose a counter update. Callers keep their own
 * single-process serialize chain as the second layer.
 */
export interface UsageMutateOptions {
    /** P2-9 (v19): called when malformed entries had to be quarantined before the
     * task could run. The guard preserves bytes AND keeps the facility working;
     * this callback is how that stays observable. */
    onQuarantine?: ((message: string) => void) | undefined;
}
export declare function mutateUsage(root: string, io: EvolutionIoLike, task: (map: UsageMap) => void | Promise<void>, options?: UsageMutateOptions): Promise<void>;
/** Curator-owned usage fields (rc.67 K-2): the curator writes ONLY this set —
 * lifecycle state, archive stamp, the six-factor quality pair, and the
 * marker-mirrored pin flag; counters and activity stamps belong to the
 * tool-telemetry side and are never copied by a fold. P2-12 (v39): the
 * combined `applyCuratorFields` wrapper had no production caller (folds go
 * through {@link foldCuratorFields}), so the two field copies below are the
 * whole contract. */
/** Copy only the lifecycle pair (state/archived_at) — see the ownership split
 * rationale above. */
export declare function applyCuratorLifecycleFields(disk: UsageRecord, curated: UsageRecord): void;
/**
 * Copy the recomputed meta pair (quality_score/quality_warn + the
 * marker-mirrored pin flag) — refreshed tree-wide each run by design, so a
 * concurrent curator run's lifecycle changes are never reverted by them.
 * P1-1 (v15): the feedback pair (`feedback_score`/`feedback_warn`) is
 * deliberately NOT copied — it is feedback-owned (see the field-ownership
 * contract on {@link UsageRecord}) and must survive curator runs untouched.
 */
export declare function applyCuratorMetaFields(disk: UsageRecord, curated: UsageRecord): void;
/**
 * Fold a curator run-start snapshot onto the current on-disk map (rc.67 K-2):
 * each curated record is projected onto its disk peer by copying only the
 * curator-owned fields, so a concurrent tool-side bump between snapshot and
 * save survives. Records absent from the snapshot are left untouched; a
 * curated record with no disk peer is seeded from the snapshot. `stateOwned`
 * (rc.72 H-1) restricts the lifecycle pair to the names this run ACTUALLY
 * transitioned — a concurrent curator run's archive/restore is never reverted
 * by a stale snapshot; without it both pairs apply everywhere.
 */
export declare function foldCuratorFields(disk: UsageMap, curated: UsageMap, stateOwned?: ReadonlySet<string>, runStartStates?: ReadonlyMap<string, string>): string[];
/** Whole-file usage write (V6-37, 0.3.37): this is the ONE path that bypasses
 * the malformed-defense and the transact lock — prefer `mutateUsage` for any
 * read-modify-write so a concurrent writer cannot lose its update and a
 * malformed sidecar stays recoverable. Kept for fixture/test seeding.
 * @internal P3-16 (v14): no production caller (verified by grep); exported for
 * the family's tests only. Do not use it to write the sidecar in new code. */
export declare function saveUsage(root: string, map: UsageMap, io?: EvolutionIoLike): Promise<void>;
export declare function getRecord(map: UsageMap, name: string): UsageRecord;
export declare function bumpView(map: UsageMap, name: string, when?: Date): void;
export declare function bumpUse(map: UsageMap, name: string, when?: Date): void;
export declare function bumpPatch(map: UsageMap, name: string, when?: Date): void;
/** Count one observed support-file read (design §5.5). The map is created on
 * first evidence only — a skill with no support reads keeps the field absent. */
export declare function bumpSupportRead(map: UsageMap, name: string, rel: string, when?: Date): void;
export declare function markAgentCreated(map: UsageMap, name: string): void;
export declare function latestActivityAt(record: UsageRecord): string | null;
/** Days between an ISO timestamp (falling back to `created`) and `now`. An
 * unparseable date counts as 0 days: NaN silently froze every age comparison
 * (A2-9). */
export declare function daysSinceIso(iso: string | null, created: string, nowMs: number): number;
/** Idle days of one skill since its lifecycle age anchor (`last activity ??
 * created_at`) — the SAME anchor the curator's transitions use, so the
 * maintenance view and the lifecycle can never disagree about staleness. */
export declare function idleDays(record: UsageRecord, now?: Date): number;
/**
 * Whether the library has ANY observed read evidence (C observation window):
 * reads were invisible to the usage sidecar before A2, so `view_count` zero
 * means "never read" ONLY after the first observed read exists anywhere in
 * the map. Before that, churn-based signals (write-ghost) are untrustworthy
 * and callers must suppress them. Pure and derived — never persisted.
 */
export declare function usageObserved(usage: ReadonlyMap<string, UsageRecord>): boolean;
/**
 * Curator suppression sidecar: built-in skills the curator has archived stay
 * suppressed across re-seeds, so the lifecycle never fights a re-created
 * bundled skill. Best-effort load/save, mirroring the usage sidecar posture.
 * Versioned shape ({ version, names }) with legacy plain-array compat.
 */
export declare const SUPPRESSED_FILE_VERSION = 1;
export declare function suppressedFile(root: string): string;
export declare function loadSuppressedNames(root: string, io?: EvolutionIoLike): Promise<ReadonlySet<string>>;
/**
 * Plain wholesale write of the suppression sidecar (tests and fixture seeding).
 * @internal S2.4 (PLAN 2026-09-16, audit P2-31): NO production consumer
 * (verified by grep; production suppressions go through
 * {@link updateSuppressedNames}) — exported for the family's tests only. Do
 * not use it to write the sidecar in new code.
 *
 * The write rides the {@link transactIo} channel (the same lock the RMW
 * writer uses), not the former naked read → `io.writeText`: that form was an
 * unserialized read-modify-write — the last `saveSuppressedNames` in this file
 * with no lock, while its sibling `saveUsage` already carried the `@internal`
 * test-only note. Version discipline is unchanged (V24-09 / S2-14): a read
 * failure surfaces (an unreadable sidecar is never written over), a newer
 * on-disk schema is warned about and preserved byte-for-byte (the
 * byte-identical result short-circuits the write), and a malformed sidecar is
 * still overwritten with the v1 shape (the historical plain-writer posture).
 */
export declare function saveSuppressedNames(root: string, names: ReadonlySet<string>, io?: EvolutionIoLike): Promise<void>;
/**
 * Atomic read-modify-write on the suppression sidecar (rc.50 P2-2): `task`
 * receives the set parsed from the current on-disk state and may mutate it;
 * the result is persisted inside the same transact so a second process
 * sharing DSH_HOME cannot interleave its RMW. Best-effort posture unchanged.
 */
export declare function updateSuppressedNames(root: string, io: EvolutionIoLike, task: (names: Set<string>) => void | Promise<void>): Promise<void>;
export {};
//# sourceMappingURL=usage.d.ts.map