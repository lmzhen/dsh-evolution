/**
 * The write-admission sequence: ONE ordered table of the reasons a skill write is refused.
 *
 * Two points read this table (design `dsh-evolution-write-gate-design.md` §3). The ADMISSION
 * point (`execute`, BEFORE the approval seam) runs every gate that applies to `'admission'`, so a
 * write that is refused is never staged and never spends the operator's attention twice. The
 * EXECUTION point (the `executeCore` funnel, reached by the direct path and by the approval
 * replay) runs the gates that apply to `'execution'`: the stored plan of a replayed write passed
 * no schema, and the protected list can change while a record sits pending, so those verdicts are
 * re-decided at the bytes.
 *
 * Order is part of the contract: a gate that can only refuse comes before one that needs a round
 * trip with the operator, so a write that is refused anyway never asks anything.
 *
 * A gate decides whether a write may be ATTEMPTED. The library decides whether it can be
 * PERFORMED — its own structured refusals (a restructure element that is not an object, a patch
 * anchor that no longer matches, an `absorbed_into` that does not exist) stay where the bytes are
 * read.
 *
 * Rule bodies live in `evolution-core` (the read-before-write rule in `skill-reads`, the
 * required-argument table in `SKILL_ACTION_REQUIRED_FIELDS`); this module owns the ORDER and the
 * applicability of each gate, which is an execution-point fact of this tool.
 * @module @deepseek-ai/dsh-evolution-core/write-gates
 */
import { type WriteConfirm, type WriteConfirmMode } from './write-authority.ts';
import type { ConfirmContext } from './write-authority.ts';
import { type WriteOrigin } from './index.ts';
/** The point whose verdict is being taken. */
export type WriteGatePoint = 'admission' | 'execution';
/** What every gate reads. */
/**
 * G1/1.2: the policy snapshot's protected list, read through an `unknown` boundary.
 *
 * This used to be package-private to tool-skill-manage, which is why the graph commands could not ask
 * the same question and ended up enforcing nothing. It lives here so every write entry point reads the
 * SAME list from the SAME place; the `unknown` boundary stays because the Context augmentation types the
 * getter non-optionally while at runtime the policy row may be absent.
 * @param policy - `ctx.get('evolutionPolicy')`, or anything else when the row is not mounted.
 * @returns the protected names, or undefined when no policy snapshot is readable.
 */
/**
 * G1/1.2: what a write entry point must supply for the shared admission sequence.
 *
 * The gates need policy, confirm, the session's read set and a warn sink; every caller can obtain those
 * from its own `ctx`, but assembling them into a valid `WriteGateContext` is the seam's business, not each
 * caller's. Without this, "all five entry points call the same entry" means five hand-built contexts and
 * five chances to leave `protectedNames` out - which is exactly how the graph commands ended up enforcing
 * nothing.
 */
export interface SkillWriteGateServices {
    /** `ctx.get('evolutionPolicy')`, or anything else when the row is not mounted. */
    readonly policy: unknown;
    /** The human confirm seam; `undefined` refuses to ask (the gates then refuse the write). */
    readonly confirm: WriteConfirm | undefined;
    /** Names this session read successfully; `undefined` when the session log is not readable. */
    readonly readNames: ReadonlySet<string> | undefined;
    /** Report a degraded gate; must not throw. */
    readonly warn: (message: string) => void;
    /** The registry's `skillWriteConfirm`; `auto` (the default) skips the question. */
    readonly confirmMode?: WriteConfirmMode;
    /** The registry's `skillWriteConfirmTimeoutSeconds`, read only in `timeout` mode. */
    readonly confirmTimeoutSeconds?: number;
    /** Lazily read the target's own words for the confirmation card. */
    readonly describeTarget?: (() => Promise<ConfirmContext | undefined>) | undefined;
}
/**
 * Assemble a gate context from a caller's services. The protected list is read HERE, so no caller can
 * forget it or read it from a second place.
 * @param services - the four required services plus the optional registry knobs.
 * @param request - the point asking, the arguments under test, and the write origin.
 * @returns a context the shared sequence accepts.
 */
export declare function skillWriteGateContext(services: SkillWriteGateServices, request: {
    readonly point: WriteGatePoint;
    readonly args: unknown;
    readonly origin: WriteOrigin;
}): WriteGateContext;
export declare function protectedSkillNamesOf(policy: unknown): readonly string[] | undefined;
export interface WriteGateContext {
    /** The point asking: the tool's admission of a call, or its execution at the bytes. */
    readonly point: WriteGatePoint;
    /** The parsed (admission) or stored (replay) arguments — unvalidated, hence the shape gate. */
    readonly args: unknown;
    /** The library write origin: `foreground` is the operator's own session. */
    readonly origin: WriteOrigin;
    /** The policy snapshot's protected list; `undefined` when no policy row is mounted. */
    readonly protectedNames: readonly string[] | undefined;
    /** Names this session read successfully; `undefined` when the session log is not readable. */
    readonly readNames: ReadonlySet<string> | undefined;
    /** The human confirm seam — read only by the gates that apply to `'admission'`. */
    readonly confirm: WriteConfirm | undefined;
    /** The registry's `skillWriteConfirm`: `auto` (the default) skips the question entirely. */
    readonly confirmMode?: WriteConfirmMode;
    /** The registry's `skillWriteConfirmTimeoutSeconds`, read only in `timeout` mode. */
    readonly confirmTimeoutSeconds?: number;
    /** Read the target's own words for the confirmation card. LAZY on purpose: a write that is not
     * asked about must not pay a read for a question nobody sees. Absent means "say nothing extra". */
    readonly describeTarget?: (() => Promise<ConfirmContext | undefined>) | undefined;
    /** Report a degraded gate; must not throw. The implementation decides how often it speaks — the
     * shipped seam latches once per PROCESS, because the conditions it reports (no question service,
     * an unreadable session log) belong to the deployment, not to one write. */
    readonly warn: (message: string) => void;
}
/**
 * Run the sequence for one write attempt.
 * @param context - the asking point, the write, and the seams the human-facing gate needs.
 * @returns the FIRST refusal, or null when every applicable gate passed. Both points return the
 *   message as the tool result unchanged, so the two entries refuse with identical wording.
 */
export declare function runWriteGates(context: WriteGateContext): Promise<string | null>;
//# sourceMappingURL=write-gates.d.ts.map