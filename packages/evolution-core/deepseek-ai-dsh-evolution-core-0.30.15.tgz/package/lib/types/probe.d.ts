/**
 * V41 phase-1 follow-up: the read THREE-state (P2-25 sibling of N14).
 *
 * A read has three outcomes, not two: the value is there, it is genuinely not
 * there, or we could not decide (IO error, unreadable store, missing
 * provider). Collapsing the third into either of the others is how a broken
 * store reads as "empty" and a guard silently passes — the class N14 registers.
 * Migration target for the pre-existing two-state patches (protectionUnknown /
 * unverifiable): constructors are prefixed so the type can never be confused
 * with a value, and only `present` yields a value.
 */
import type { EvolutionIoLike } from './io.ts';
/**
 * The io surface the three-state probes actually use: three READS. Narrowing it here is deliberate -
 * a probe cannot write, and typing these parameters as the full `EvolutionIoLike` made every read-only
 * caller (e.g. reachability.ts) fail to compile for a capability it must not have.
 */
export type ProbeIo = Pick<EvolutionIoLike, 'list' | 'readText' | 'mtime'>;
export type Probe<T> = {
    kind: 'present';
    value: T;
} | {
    kind: 'absent';
} | {
    kind: 'unknown';
    reason: string;
};
export declare function probePresent<T>(value: T): Probe<T>;
export declare function probeAbsent<T>(): Probe<T>;
export declare function probeUnknown<T>(reason: string): Probe<T>;
export declare function isPresent<T>(probe: Probe<T>): probe is {
    kind: 'present';
    value: T;
};
export declare function isAbsent<T>(probe: Probe<T>): probe is {
    kind: 'absent';
};
export declare function isUnknown<T>(probe: Probe<T>): probe is {
    kind: 'unknown';
    reason: string;
};
/** Only a PRESENT probe yields a value; absent and unknown both fall back. */
export declare function valueOr<T>(probe: Probe<T>, fallback: T): T;
export declare function mapProbe<T, U>(probe: Probe<T>, transform: (value: T) => U): Probe<U>;
/** The reason an `unknown` probe carries (message, never a bare String(object)). */
export declare function probeReason(error: unknown): string;
/**
 * ENOENT/ENOTDIR are the ONE read failure that means "it is not there"; every
 * other failure is an IO error and stays unknown (same split as the node
 * backend's own isMissing, V8-23⑨ for the size probe).
 */
export declare function isMissingPath(error: unknown): boolean;
/**
 * Three-state directory listing. The node backend already answers `[]` for a
 * MISSING directory (its own rc.50 P2-4 contract) and THROWS for an unreadable
 * one, so the value this adds is the second half: a backend that throws ENOENT
 * reads as absent, an EACCES/EIO reads as unknown — where a bare
 * `catch { return [] }` served a broken store as an empty one (the N14 class).
 */
export declare function probeList(io: ProbeIo, dir: string): Promise<Probe<string[]>>;
/**
 * Three-state TEXT read of one file. A missing path (ENOENT/ENOTDIR, or a backend whose read
 * answers null) is `absent`; every other failure is `unknown` with its reason. The distinction is
 * the whole point (N14/O-7): "I could not read this file" and "this file is not there" lead to
 * opposite decisions once a write is about to replace the bytes — treating the first as the
 * second is how a broken store reads as empty and a rescue copy never happens.
 * @param io - the IO seam.
 * @param path - the file to read.
 * @returns the probe.
 */
export declare function probeText(io: ProbeIo, path: string): Promise<Probe<string>>;
/**
 * Three-state mtime read. Absent covers both "the path is missing" and "this
 * backend has no mtime probe" — the seam cannot tell those apart, so consumers
 * that must know say so in their own log line. A stat that FAILS is unknown.
 */
export declare function probeMtime(io: ProbeIo, path: string): Promise<Probe<number>>;
/** The timestamp a curator run report DECLARES: `startedAt` (the run's own start), then `at` (the
 * stamp the error writer sets on every report — F-327/P2-4).
 * @param parsed - the parsed report, or anything else.
 * @returns epoch milliseconds, or null when neither field carries a parseable time.
 */
export declare function declaredReportStamp(parsed: unknown): number | null;
/** The time one curator run report is ordered by — ONE口径 for every reader (S2.9/T3-12): the
 * declared stamp above, then the optional mtime probe as the fallback. `null` means "no usable
 * time", and that single answer serves both consumers: such a report is never the LATEST (the
 * panel) and is never DELETED (the retention sweep), which is exactly the pair of answers the two
 * readers disagreed on when one ordered by the declared stamp and the other by mtime alone.
 * @param io - the IO seam; a backend without `mtime` simply has no fallback.
 * @param path - the report file the probe reads.
 * @param parsed - the already-parsed report.
 * @returns epoch milliseconds, or null.
 */
export declare function reportTime(io: EvolutionIoLike, path: string, parsed: unknown): Promise<number | null>;
//# sourceMappingURL=probe.d.ts.map