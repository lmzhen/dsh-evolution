/**
 * The Host data-plane contract + Fetch-shaped helpers every family route surface shares (W1/W6).
 *
 * WHY THIS IS IN CORE: HOST_ROUTES is the ONE path table (clients are generated from it), and the
 * response/body helpers are thin platform-Request utilities. The loopback fence that used to live here
 * is GONE (G4): trust, browser auth and owner admission are applied by the platform's connection
 * carrier BEFORE a route's fetch(request) runs, so a family copy of those rules was a second admission
 * path (and did diverge).
 *
 * Layering: pure transport. Nothing here knows about skills, approvals, curators or route tables.
 * @module @deepseek-ai/dsh-evolution-core/http-routes
 */
import type { Context } from '@deepseek-ai/cordis';
/** Largest request body a family route accepts; a bigger one reads as "no body" (400 from the handler). */
export declare const MAX_REQUEST_BODY_BYTES: number;
/**
 * Read one JSON request body that must be an OBJECT, bounded.
 * @param request - the platform Fetch Request handed to a route.
 * @param maxBytes - the body bound (defaults to MAX_REQUEST_BODY_BYTES).
 * @returns the body as a plain object, or null when it is absent, oversized, not JSON, or not an object.
 */
export declare function readJsonObject(request: Request, maxBytes?: number): Promise<Record<string, unknown> | null>;
export type HttpMethod = 'GET' | 'HEAD' | 'POST';
export type HostRoutePath = `/api/dsh-evolution/${string}`;
export interface HostRouteSpec {
    readonly path: HostRoutePath;
    readonly methods: readonly HttpMethod[];
    readonly requestBody: 'buffered' | 'streaming';
}
export interface ConnectionFetchRouteLike extends HostRouteSpec {
    fetch(request: Request): Promise<Response>;
}
export interface DecisionAudit {
    readonly channel: 'connection.fetch' | 'command';
    readonly principal: 'owner';
    readonly deploymentAllowsRemote: boolean;
}
export declare const HOST_ROUTES: {
    readonly approval: {
        readonly pending: "/api/dsh-evolution/approval/pending";
        readonly preview: "/api/dsh-evolution/approval/preview";
        readonly approve: "/api/dsh-evolution/approval/approve";
        readonly reject: "/api/dsh-evolution/approval/reject";
    };
    readonly skillHistory: {
        readonly skills: "/api/dsh-evolution/skill-history/skills";
        readonly versions: "/api/dsh-evolution/skill-history/versions";
        readonly diff: "/api/dsh-evolution/skill-history/versions/diff";
        readonly body: "/api/dsh-evolution/skill-history/versions/body";
        readonly undo: "/api/dsh-evolution/skill-history/undo";
        readonly health: "/api/dsh-evolution/skill-history/health";
    };
    readonly skillHealth: {
        readonly rows: "/api/dsh-evolution/skill-health/rows";
    };
    readonly merge: {
        readonly view: "/api/dsh-evolution/merge/view";
        readonly rows: "/api/dsh-evolution/merge/rows";
        readonly body: "/api/dsh-evolution/merge/body";
        readonly history: "/api/dsh-evolution/merge/history";
    };
    readonly diagnostics: {
        readonly view: "/api/dsh-evolution/diagnostics";
    };
};
export type HostSurface = {
    readonly available: true;
    readonly allowsRemoteAuthorities: boolean;
} | {
    readonly available: false;
    readonly code: 'E-325';
    readonly reason: 'connection-missing' | 'service-absent';
};
export declare function hostSurface(ctx: Context): HostSurface;
/**
 * Register the family host surface on the platform's exact-route carrier.
 *
 * The platform owns admission (Host/Origin hygiene + browserAuth + exact-route owner peer) and the
 * disposer is bound to the CALLING fiber, not the connection service: the connection service can
 * outlive a reloaded family fiber, so the family must release its own registrations on dispose.
 * Routes carry the audit snapshot taken at registration time (deployment-level facts only — the
 * exact-route handler receives a Request, not the peer identity).
 */
export declare function registerHostRoutes(owner: Context, build: (audit: DecisionAudit) => readonly ConnectionFetchRouteLike[]): void;
export declare function json(status: number, body: unknown): Response;
export declare function methodNotAllowed(allowed: readonly HttpMethod[]): Response;
//# sourceMappingURL=http-routes.d.ts.map