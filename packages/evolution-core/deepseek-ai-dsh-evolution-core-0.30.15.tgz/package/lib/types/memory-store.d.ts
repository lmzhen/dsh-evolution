/**
 * File-backed durable memory with Hermes-compatible semantics.
 * Stores are MEMORY.md and USER.md under $DSH_HOME/memories (~/.dsh/memories).
 */
import { type EvolutionIoLike } from './io.ts';
export { ENTRY_DELIMITER } from './constants.ts';
export type MemoryTarget = 'memory' | 'user';
export interface MemoryOperation {
    action: 'add' | 'replace' | 'remove';
    facts?: string | undefined;
    /** PLAN-R2 P2-6 (2026-09-16): the dsh-memory contract's alias. applyBatchCore
     * resolves the pair through core's `payloadText` (T3-06/A34), so a provider
     * reusing this store directly can write the tool-memory schema shape without
     * a normalization shim. */
    content?: string | undefined;
    old_text?: string | undefined;
}
export interface MemoryApplyResult {
    ok: boolean;
    message: string;
    entries: string[];
    chars: number;
    limit: number;
}
export declare function memoryRoot(env?: NodeJS.ProcessEnv): string;
export interface MemoryStoreOptions {
    memoryCharLimit?: number;
    userCharLimit?: number;
    addDatePrefix?: boolean;
    root?: string;
    maxConsolidationFailures?: number;
    io?: EvolutionIoLike;
    /** V10-03 (P2-18): deployment-declared benign pattern labels (ScanOptions.
     * excludeLabels) applied to every threat check of this store (writes and
     * the renderContext filter). Default empty — the strict ANY-hit-blocks
     * policy is unchanged; deploy configs opt in. */
    threatExemptLabels?: readonly string[];
}
export type { EvolutionIoLike };
export declare class MemoryStore {
    readonly memoryLimit: number;
    readonly userLimit: number;
    readonly addDatePrefix: boolean;
    readonly root: string;
    private readonly maxFailures;
    private readonly io;
    /** V10-03 (P2-18): see MemoryStoreOptions.threatExemptLabels. */
    private readonly threatExemptLabels;
    /** V6-16 (0.3.37): same-process RMW serialization (the SkillLibrary queue) —
     * on a backend WITHOUT a transact lock two concurrent callers compute on the
     * same old content and the last rename wins, silently dropping one op's
     * update. The node backend's cross-process lock already serializes; this
     * chain covers the no-transact custom backends. */
    private readonly serial;
    private failureCount;
    private lastFailureAt;
    constructor(options?: MemoryStoreOptions);
    /** V10-03 (P2-18): ScanOptions shared by every threat check of this store —
     * the constructor's exempt labels, empty by default (behavior unchanged). */
    private threatScanOptions;
    /** V10-03 (P2-18): the strict-scan write gate. A block message names the hit
     * label (scanMemoryThreats already embeds it) plus the self-heal hint. */
    private memoryThreatBlock;
    limitFor(target: MemoryTarget): number;
    /** P2-1 (v18): the generated date prefix participates in duplicate detection
     * only when THIS store writes it. With addDatePrefix=false a fact's own
     * leading `## YYYY-MM-DD\n` is content, not a generated prefix. */
    private dedupeKey;
    /**
     * Read-guard probe: `{ size, limit }` when the on-disk file exceeds
     * `limit * READ_GUARD_FACTOR` bytes, `null` when it is absent, unknown
     * (backend without a size probe), under the bound, or the target has no
     * limit configured.
     */
    private oversizedFile;
    read(target: MemoryTarget): Promise<string[]>;
    resetFailures(): void;
    private failure;
    /**
     * StorageHint percentage must clamp at 100 like the render header: a drifted
     * entry can push chars past the limit, and "Storage at 125%" contradicts the
     * clamped usage indicator.
     */
    private storageHint;
    /**
     * Best-effort raw-copy backup of the on-disk file to `<file>.bak` before a
     * refusal, so an externally modified (or oversized) file stays recoverable.
     * Copies bytes instead of reading them so a pathologically large file is
     * never loaded just to back it up. Failure to back up does not change the
     * refusal semantics. V8-23⑫ (0.3.49): ONE fixed backup name per target —
     * a fresh refusal overwrites it (the previous timestamped names accumulated
     * per drift incident with no retention policy). V9-08 (0.3.51) declares the
     * two failure shapes: (1) the pre-copy remove of the previous `.bak` fails —
     * harmless, because the copy contract is overwrite (`cp force`);
     * (2) the copy itself fails (disk/backend) — returns `null` and the refusal
     * message simply carries no backup suffix; the refusal semantics and the
     * on-disk file are untouched either way.
     */
    private backupFile;
    /**
     * Read-guard refusal for write paths. Returns the refusal result when the
     * target file is oversized, `null` otherwise. The file is skipped for
     * reading (never loaded), backed up by raw copy, and the model is told to
     * fix it manually — mirroring the drift refusal so corrupted state is never
     * silently overwritten.
     */
    private oversizedRefusal;
    /**
     * The ONE memory write skeleton (V27 G2.5): oversized read-guard pre-transact,
     * one transaction over the target path, and the C-01 structured refusal when a
     * backend never invokes the task. `addChained` and `applyBatchChained` supply
     * only their own in-transaction core, so the two write paths cannot drift in
     * their guard order, their missing-file handling or their error text.
     *
     * @param target - memory target being written
     * @param core - the in-transaction read-modify-write for the locked body
     * @param shrinkOnly - v29 MEM-02: every queued operation REMOVES an entry
     *   (the recovery path for a limit lowered under existing content). The
     *   oversized read-guard is skipped for these batches: a canonical file
     *   written under a ≥10× higher limit trips the `limit × 10` byte bound, and
     *   the guard's "fix the file manually" refusal would pre-empt exactly the
     *   shrink recovery MEM-01 advertises. The load is bounded by what the store
     *   itself wrote under the old limit.
     * @returns the core's result, or the oversized / contract-violation refusal
     */
    private chainedWrite;
    add(target: MemoryTarget, facts: string): Promise<MemoryApplyResult>;
    private addChained;
    /**
     * Single-entry add inside the transaction: shared checks (oversized,
     * drift, threat) and the content computation. `raw` is the locked view
     * (`current`) — never a second IO read. `write: null` means "no change".
     */
    private addCore;
    /**
     * The single drift evaluation. `raw` is in canonical form when it byte-matches
     * `render(normalizeEntries(raw))`; anything else means it was edited outside
     * MemoryStore (empty/`§`-only entries, stray blank lines, leading or trailing
     * delimiters — structural anomalies the writer would quietly normalize away).
     * Both write paths derive this from their locked view and `detectDrift` from
     * a fresh read, so a write and a later read can never disagree about the same
     * bytes.
     *
     * An absent, empty, or whitespace-only body is the "never written" state
     * (rc.42 audit P1-6): it parses to zero entries, and the canonical form
     * `'\n'` can never byte-match it, so flagging it would permanently refuse
     * every write path — including the repairs the model would need to make.
     * Such files are adopted instead of flagged.
     *
     * Returns one of:
     * - `'external'` — non-canonical body, i.e. real external modification. This
     *   includes the Hermes-parity signal #2 (an entry larger than the whole-file
     *   limit): that shape is only meaningful as external evidence on a
     *   NON-canonical body, because free-form external appends never render
     *   canonically.
     * - `'over-limit'` — v28 MEM-01: a CANONICAL body whose entries exceed the
     *   CURRENT configured limit. Those bytes were written by this store under a
     *   previous (higher) limit, so they are not external drift; treating them as
     *   such misattributed a config change to an "external editor" and bricked
     *   every write path (the advertised recovery — remove/consolidate — is
     *   exactly what the drift gate refused). Callers route this state to a
     *   config-naming refusal and let shrink-only batches through.
     * - `null` — no drift: writable as-is.
     *
     * @param target - memory target whose char limit bounds one parsed entry
     * @param raw - on-disk body, or `null` when the file does not exist
     */
    private driftKind;
    /** External-drift predicate: canonical-form violations only (see
     * {@link driftKind}). `detectDrift` and the write paths share it, so a write
     * and a later read never disagree about the same bytes. */
    private drifted;
    /**
     * Drift refusal for a body already read under the write lock, or `null` when
     * writing may proceed. Both write paths return this unchanged, so their
     * refusals stay byte-identical and each carries the same backup.
     *
     * The `'over-limit'` state never refuses shrink-only batches (`shrinkOnly`):
     * removing entries is the advertised recovery for a limit lowered under
     * existing content, and the batch's own final limit check still gates the
     * result.
     *
     * @param target - memory target that owns the drifted file
     * @param raw - locked file body
     * @param shrinkOnly - every queued operation removes an entry (no growth)
     * @returns the refusal to hand back, or `null` to continue writing
     */
    private driftRefusal;
    applyBatch(target: MemoryTarget, operations: MemoryOperation[]): Promise<MemoryApplyResult>;
    private applyBatchChained;
    /** Batch RMW inside the transaction. `write: null` = failure/no-op, disk untouched. */
    private applyBatchCore;
    renderContext(): Promise<string>;
    /**
     * Detect on-disk drift for a caller that holds no locked view: `true` when the
     * file is not in canonical form, or when its size trips the read guard. The
     * write paths apply the same predicate (`drifted`) to the body they read under
     * the lock, so a write and a follow-up read agree about the same bytes.
     *
     * @param target - memory target to inspect
     * @returns whether the file on disk counts as externally drifted
     */
    detectDrift(target: MemoryTarget): Promise<boolean>;
}
//# sourceMappingURL=memory-store.d.ts.map