import type { Context } from '@deepseek-ai/cordis';
export declare const name = "evolution-io-node-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map