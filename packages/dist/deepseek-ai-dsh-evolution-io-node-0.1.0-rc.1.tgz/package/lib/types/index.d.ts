/**
 * Local atomic node:fs IO provider.
 * @module @deepseek-ai/dsh-evolution-io-node
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "evolution-io-node";
export declare const inject: string[];
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map