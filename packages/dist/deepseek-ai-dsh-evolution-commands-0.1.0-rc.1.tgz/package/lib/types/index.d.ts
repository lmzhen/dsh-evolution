/**
 * Human commands for the evolution family: /evolution status|pending.
 * @module @deepseek-ai/dsh-evolution-commands
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "evolution-commands";
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map