/**
 * Session projection for self-evolution activity.
 * @module @deepseek-ai/dsh-evolution-activity
 */
import type { Context } from '@deepseek-ai/cordis';
import { z } from 'zod';
export interface EvolutionActivityItem {
    planId: string;
    kind: string;
    memoryApplied: number;
    skillApplied: number;
    rejectedOps: number;
    at: number;
}
export interface EvolutionActivityProjection {
    items: EvolutionActivityItem[];
}
export interface State {
    items: EvolutionActivityItem[];
}
type SessionEventLike = {
    type: 'evolution/plan-applied';
    data: {
        planId: string;
        memoryApplied: number;
        skillApplied: number;
        rejectedOps: number;
    };
    time: number;
} | {
    type: string;
};
export declare function applyState(state: State, event: SessionEventLike, maxItems?: number): State;
export declare const name = "evolution-activity";
export interface Config {
    maxItems?: number;
}
export declare const Config: z.ZodObject<{
    maxItems: z.ZodDefault<z.ZodNumber>;
}, z.core.$strip>;
export declare function apply(ctx: Context, rawConfig?: Config): void;
export {};
//# sourceMappingURL=index.d.ts.map