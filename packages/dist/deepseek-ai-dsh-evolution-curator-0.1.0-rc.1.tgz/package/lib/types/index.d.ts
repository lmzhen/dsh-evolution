/**
 * Deterministic skill lifecycle curator with interval gate and archive.
 * @module @deepseek-ai/dsh-evolution-curator
 */
import { Context, Service } from '@deepseek-ai/cordis';
import type Schema from '@deepseek-ai/schemastery';
import { SkillLibrary } from '@deepseek-ai/dsh-evolution-core';
import { type CuratorRunReport } from '@deepseek-ai/dsh-evolution-core';
declare module '@deepseek-ai/cordis' {
    interface Context {
        evolutionCurator: EvolutionCurator;
    }
}
export interface Config {
    enabled?: boolean;
    intervalHours?: number;
    staleAfterDays?: number;
    archiveAfterDays?: number;
    /** Spend one LLM review pass on stale candidates before the deterministic archive step. */
    llmReview?: boolean;
    curatorProvider?: string;
    /** Quality-warned skills may turn stale after this many idle days. */
    qualityWarnStaleAfterDays?: number;
    /** Skip automatic runs while any session was active within this many hours (0 disables). */
    minIdleHours?: number;
    /** Skill names excluded from the automated lifecycle. */
    excludeSkillNames?: string[];
    /** Include usage records whose created_by is not 'agent' in lifecycle decisions. */
    manageUnmanaged?: boolean;
}
export declare class EvolutionCurator extends Service {
    static inject: string[];
    static Config: Schema<Config>;
    readonly skills: SkillLibrary;
    private readonly io;
    private readonly enabled;
    private readonly intervalHours;
    private readonly staleAfterDays;
    private readonly archiveAfterDays;
    private readonly llmReview;
    private readonly curatorProvider;
    private readonly qualityWarnStaleAfterDays;
    private readonly minIdleHours;
    private readonly excludeSkillNames;
    private readonly manageUnmanaged;
    private lastRun;
    private timer;
    constructor(ctx: Context, config?: Config);
    private lifecycle;
    start(): void;
    stop(): void;
    /**
     * Optional Hermes-curator LLM pass. The model may only NOMINATE pruning
     * candidates; archive/restore remains a control-plane operation and every
     * nominated name is still checked against lifecycle thresholds and
     * protected markers before any file move.
     */
    recommend(candidates: string[]): Promise<string[]>;
    private skippedReport;
    run(): Promise<{
        stale: string[];
        archived: string[];
        errors: string[];
        report: CuratorRunReport;
        skipped?: string;
    }>;
    private recentSessionActive;
    latestReport(): Promise<CuratorRunReport | null>;
}
export default EvolutionCurator;
//# sourceMappingURL=index.d.ts.map