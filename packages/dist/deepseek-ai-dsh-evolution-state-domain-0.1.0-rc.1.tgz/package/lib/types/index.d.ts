/**
 * storage-domain provider for evolution state.
 *
 * When this provider is mounted, review/curator/pending records live in the
 * DSH storage-domain data form: schema-validated, change-emitting, durable KV
 * with whatever backend the domain facility routes (`json`, `sqlite`, remote
 * RPC, …). The provider is one of several implementations of the same seam.
 * @module @deepseek-ai/dsh-evolution-state-domain
 */
import type { Context } from '@deepseek-ai/cordis';
import { z } from 'zod';
import type { CuratorStateRecord, PendingRecord, ReviewStateRecord } from '@deepseek-ai/dsh-evolution-state-storage';
export declare const name = "evolution-state-domain";
export declare const inject: string[];
export declare const reviewStateSchema: z.ZodObject<{
    turnsSinceMemory: z.ZodNumber;
    turnsSinceSkill: z.ZodNumber;
    lastTurn: z.ZodNumber;
}, z.core.$strip>;
export declare const curatorStateSchema: z.ZodObject<{
    lastRunAt: z.ZodNumber;
    runCount: z.ZodNumber;
    lastSummary: z.ZodString;
    paused: z.ZodBoolean;
}, z.core.$strip>;
export declare const pendingSchema: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodUnion<readonly [z.ZodLiteral<"memory">, z.ZodLiteral<"skill">, z.ZodLiteral<"skill_batch">, z.ZodLiteral<"capability">]>;
    summary: z.ZodString;
    args: z.ZodUnknown;
    createdAt: z.ZodString;
    status: z.ZodUnion<readonly [z.ZodLiteral<"pending">, z.ZodLiteral<"approved">, z.ZodLiteral<"rejected">]>;
    resolvedAt: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export declare const EVOLUTION_DOMAIN: {
    name: string;
    version: number;
    tables: {
        review_state: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, ReviewStateRecord>;
        curator_state: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, CuratorStateRecord>;
        pending: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, PendingRecord>;
    };
};
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map