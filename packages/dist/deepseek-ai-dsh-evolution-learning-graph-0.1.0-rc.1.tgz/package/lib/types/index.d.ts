/**
 * Learning graph over skills and memory.
 * @module @deepseek-ai/dsh-evolution-learning-graph
 */
import type { Context } from '@deepseek-ai/cordis';
export interface GraphNode {
    id: string;
    kind: 'skill' | 'memory';
    label: string;
}
export interface GraphEdge {
    from: string;
    to: string;
    type: 'related' | 'memory_skill';
}
export interface LearningGraph {
    nodes: GraphNode[];
    edges: GraphEdge[];
}
/** Build a small deterministic graph from usage records and memory entries. */
export declare function buildLearningGraph(usage: ReadonlyMap<string, {
    use_count?: number;
    pinned?: boolean;
}>, memoryEntries: readonly string[]): LearningGraph;
export declare const name = "evolution-learning-graph";
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map