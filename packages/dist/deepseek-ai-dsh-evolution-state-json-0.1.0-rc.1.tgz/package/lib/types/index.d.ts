/**
 * JSON-file evolution state provider over the IO seam.
 *
 * This is the portable provider: `ctx.evolutionIo` may be node:fs today and a
 * network/shared medium tomorrow without any state-format changes.
 * @module @deepseek-ai/dsh-evolution-state-json
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "evolution-state-json";
export declare const inject: string[];
export interface Config {
    root?: string;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, rawConfig: Config): void;
//# sourceMappingURL=index.d.ts.map