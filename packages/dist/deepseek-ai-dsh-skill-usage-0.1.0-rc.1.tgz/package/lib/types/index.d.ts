/**
 * Skill usage telemetry service for the evolution family.
 * @module @deepseek-ai/dsh-skill-usage
 */
import { Context, Service } from '@deepseek-ai/cordis';
import type Schema from '@deepseek-ai/schemastery';
import { type UsageMap } from '@deepseek-ai/dsh-evolution-core';
declare module '@deepseek-ai/cordis' {
    interface Context {
        skillUsage: SkillUsageRegistry;
    }
}
export interface Config {
    root?: string;
}
export declare class SkillUsageRegistry extends Service {
    static inject: string[];
    static Config: Schema<Config>;
    readonly root: string;
    private readonly io;
    private usage;
    private chain;
    constructor(ctx: Context, config?: Config);
    private map;
    flush(): Promise<void>;
    /** Serialize read-modify-write cycles so concurrent record calls never lose updates. */
    private mutate;
    record(name: string, kind: 'use' | 'view' | 'patch', at?: Date): Promise<void>;
    report(): Promise<UsageMap>;
    markAgentCreated(name: string): Promise<void>;
    /** Write feedback-derived quality onto the usage sidecar; curator reads it. */
    setQuality(name: string, score: number, warn: boolean): Promise<void>;
}
export default SkillUsageRegistry;
//# sourceMappingURL=index.d.ts.map