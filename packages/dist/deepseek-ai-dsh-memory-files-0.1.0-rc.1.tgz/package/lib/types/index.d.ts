/**
 * Local layered memory provider for `ctx.memory`.
 * @module @deepseek-ai/dsh-memory-files
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "memory-files";
export declare const inject: string[];
export interface Config {
    providerName?: string;
    memoryCharLimit?: number;
    userCharLimit?: number;
    addDatePrefix?: boolean;
    root?: string;
    /** How many consolidation failures one turn tolerates before the tool tells the model to stop retrying. */
    maxConsolidationFailures?: number;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, rawConfig: Config): void;
//# sourceMappingURL=index.d.ts.map