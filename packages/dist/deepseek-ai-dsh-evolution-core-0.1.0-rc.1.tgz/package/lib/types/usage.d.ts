/**
 * Skill usage telemetry sidecar: `$DSH_HOME/skills/.usage.json`.
 * Format-compatible with Hermes Agent / hermes-claw core fields.
 */
import { type EvolutionIoLike } from './io.ts';
export type SkillState = 'active' | 'stale' | 'archived';
export interface UsageRecord {
    created_by: string | null;
    use_count: number;
    view_count: number;
    patch_count: number;
    last_used_at: string | null;
    last_viewed_at: string | null;
    last_patched_at: string | null;
    created_at: string;
    state: SkillState;
    pinned: boolean;
    archived_at: string | null;
    quality_score?: number;
    quality_warn?: boolean;
}
export type UsageMap = Map<string, UsageRecord>;
export declare function usageFile(root: string): string;
export declare function emptyRecord(): UsageRecord;
export declare function loadUsage(root: string, io?: EvolutionIoLike): Promise<UsageMap>;
export declare function saveUsage(root: string, map: UsageMap, io?: EvolutionIoLike): Promise<void>;
export declare function getRecord(map: UsageMap, name: string): UsageRecord;
export declare function bumpView(map: UsageMap, name: string, when?: Date): void;
export declare function bumpUse(map: UsageMap, name: string, when?: Date): void;
export declare function bumpPatch(map: UsageMap, name: string, when?: Date): void;
export declare function markAgentCreated(map: UsageMap, name: string): void;
export declare function latestActivityAt(record: UsageRecord): string | null;
//# sourceMappingURL=usage.d.ts.map