/**
 * Skill library management for the self-evolution plugin.
 *
 * Skills live under `$DSH_HOME/skills` (`~/.dsh/skills` by default), matching
 * the default dsh skill-filesystem user root. The plugin only manages skills
 * it created unless a `.hermes-managed` marker opts a skill in. Archival is a
 * move to `.archive/` — never a hard delete.
 */
import { type EvolutionIoLike } from './io.ts';
export declare const SKILL_NAME_RE: RegExp;
export declare const MAX_SKILL_NAME_LENGTH = 64;
export declare const MAX_DESCRIPTION_LENGTH = 1024;
export declare const MAX_SKILL_CONTENT_CHARS = 100000;
export declare const MAX_SKILL_FILE_BYTES = 1048576;
export interface SkillLimits {
    maxNameLength: number;
    maxDescriptionLength: number;
    maxSkillContentChars: number;
    maxSkillFileBytes: number;
}
export declare const DEFAULT_SKILL_LIMITS: SkillLimits;
export declare const SUPPORT_DIRS: readonly ["references", "templates", "scripts", "assets"];
export interface SkillSummary {
    name: string;
    description: string;
    path: string;
    protectedBy: string | null;
    managed: boolean;
    archived: boolean;
}
export interface SkillActionResult {
    ok: boolean;
    message: string;
    path?: string;
}
export declare function skillsRoot(env?: NodeJS.ProcessEnv): string;
export interface Frontmatter {
    name?: string;
    description?: string;
    [key: string]: unknown;
}
export declare function parseFrontmatter(content: string): {
    frontmatter: Frontmatter;
    body: string;
} | null;
export declare function validateFrontmatter(content: string, expectedName?: string, limits?: SkillLimits): string | null;
export declare class SkillLibrary {
    readonly root: string;
    readonly limits: SkillLimits;
    private readonly io;
    constructor(root?: string, io?: EvolutionIoLike, limits?: SkillLimits);
    list(): Promise<SkillSummary[]>;
    read(name: string): Promise<string | null>;
    writeProtection(name: string): Promise<string | null>;
    deleteProtection(name: string): Promise<string | null>;
    isManaged(name: string): Promise<boolean>;
    create(name: string, content: string, origin: 'foreground' | 'background_review'): Promise<SkillActionResult>;
    update(name: string, content: string): Promise<SkillActionResult>;
    patch(name: string, oldString: string, newString: string, filePath?: string, replaceAll?: boolean): Promise<SkillActionResult>;
    archive(name: string, absorbedInto?: string): Promise<SkillActionResult>;
    writeSupportFile(name: string, filePath: string, content: string): Promise<SkillActionResult>;
    removeSupportFile(name: string, filePath: string): Promise<SkillActionResult>;
    snapshotAll(reason?: string): Promise<string>;
    listSnapshots(): Promise<Array<{
        path: string;
        createdAt: string;
        reason: string;
    }>>;
    restoreLatestSnapshot(): Promise<SkillActionResult>;
}
//# sourceMappingURL=skill-store.d.ts.map