/**
 * Structural IO seam for the legacy facade stores.
 *
 * The facade accepts any object exposing this small async file-tree surface.
 * Native DSH packages pass `ctx.evolutionIo.provider()`; standalone consumers
 * (and the facade's own tests) can use `nodeEvolutionIo`.
 */
export interface EvolutionIoLike {
    readText(path: string): Promise<string | null>;
    writeText(path: string, content: string): Promise<void>;
    remove(path: string): Promise<void>;
    list(path: string): Promise<string[]>;
    exists(path: string): Promise<boolean>;
    rename(path: string, destination: string): Promise<void>;
    copy(path: string, destination: string): Promise<void>;
}
/** Lazy adapter over an IO provider registry, shared by every evolution consumer. */
export declare function evolutionIoAdapter(provider: () => EvolutionIoLike): EvolutionIoLike;
export declare function nodeEvolutionIo(): EvolutionIoLike;
/** Absolute path helper kept separate so stores stay platform-correct. */
export declare function childPath(parent: string, ...parts: string[]): string;
//# sourceMappingURL=io.d.ts.map