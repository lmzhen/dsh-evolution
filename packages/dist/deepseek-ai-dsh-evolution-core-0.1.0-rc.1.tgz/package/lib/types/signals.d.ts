/**
 * Deterministic review signal gate.
 *
 * Scans a DSH session event log for durable learning signals before any LLM
 * is spent. `turn/end` calls `observeTurn`; the returned review kind is
 * accumulated until a configured interval fires.
 */
import type { Session, SessionEvent } from '@deepseek-ai/dsh-session';
export type ReviewKind = 'memory' | 'skill' | 'combined';
export interface SignalConfig {
    memoryInterval: number;
    skillInterval: number;
    substantiveMinToolCalls: number;
    substantiveMinUserChars: number;
    substantiveMinAgentChars: number;
}
export interface TurnSignals {
    substantive: boolean;
    toolCalls: number;
    userChars: number;
    assistantChars: number;
    memorySignal: boolean;
    skillSignal: boolean;
}
export interface ReviewState {
    turnsSinceMemory: number;
    turnsSinceSkill: number;
    lastTurn: number;
}
/** Fold one session event into the current turn observation. */
export declare function observeEvent(signal: TurnSignals, event: SessionEvent): void;
/** Compute review cadence after `turn/end`. */
export declare function advanceReview(state: ReviewState, turn: number, signal: TurnSignals, config: SignalConfig): ReviewKind | null;
/** Fold all events between two sequence boundaries into one TurnSignals. */
export declare function foldTurn(session: Session, fromSeq: number): TurnSignals;
//# sourceMappingURL=signals.d.ts.map