/**
 * Threat scanning for agent-authored memory and skill content.
 *
 * Ported as a small, dependency-free subset of Hermes Agent's
 * `tools/threat_patterns.py` + hermes-claw `threats.ts`. The policy is the
 * load-bearing part: ANY in-scope hit blocks. Severity and category are
 * metadata for diagnostics only.
 */
export type ThreatScope = 'all' | 'context' | 'strict';
export interface ThreatFinding {
    label: string;
    category: string;
    scope: ThreatScope;
}
/**
 * Scan text at `scope`. Patterns are cumulative: `strict` includes all scopes.
 */
export declare function scanThreats(text: string, scope?: ThreatScope): ThreatFinding[];
/** Blocking policy: any hit blocks. `severity` is deliberately not a gate. */
export declare function evaluateThreat(text: string, scope?: ThreatScope): {
    blocked: boolean;
    findings: ThreatFinding[];
};
/** User-facing block message for memory writes. */
export declare function scanMemoryThreats(text: string): string | null;
/** User-facing block message for skill content writes. */
export declare function scanContentThreats(text: string): string | null;
//# sourceMappingURL=threats.d.ts.map