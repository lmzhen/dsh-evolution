/**
 * File-backed durable memory with Hermes-compatible semantics.
 * Stores are MEMORY.md and USER.md under $DSH_HOME/memories (~/.dsh/memories).
 */
import { type EvolutionIoLike } from './io.ts';
export declare const ENTRY_DELIMITER = "\n\u00A7\n";
export type MemoryTarget = 'memory' | 'user';
export interface MemoryOperation {
    action: 'add' | 'replace' | 'remove';
    facts?: string | undefined;
    old_text?: string | undefined;
}
export interface MemoryApplyResult {
    ok: boolean;
    message: string;
    entries: string[];
    chars: number;
    limit: number;
}
export declare function memoryRoot(env?: NodeJS.ProcessEnv): string;
export interface MemoryStoreOptions {
    memoryCharLimit?: number;
    userCharLimit?: number;
    addDatePrefix?: boolean;
    root?: string;
    maxConsolidationFailures?: number;
    io?: EvolutionIoLike;
}
export type { EvolutionIoLike };
export declare class MemoryStore {
    readonly memoryLimit: number;
    readonly userLimit: number;
    readonly addDatePrefix: boolean;
    readonly root: string;
    private readonly maxFailures;
    private readonly io;
    private failureCount;
    constructor(options?: MemoryStoreOptions);
    limitFor(target: MemoryTarget): number;
    read(target: MemoryTarget): Promise<string[]>;
    write(target: MemoryTarget, entries: string[]): Promise<void>;
    resetFailures(): void;
    private failure;
    add(target: MemoryTarget, facts: string): Promise<MemoryApplyResult>;
    replace(target: MemoryTarget, oldText: string, facts: string): Promise<MemoryApplyResult>;
    remove(target: MemoryTarget, oldText: string): Promise<MemoryApplyResult>;
    private mutate;
    applyBatch(target: MemoryTarget, operations: MemoryOperation[]): Promise<MemoryApplyResult>;
    renderContext(): Promise<string>;
    snapshot(): Promise<{
        memory: string[];
        user: string[];
    }>;
    restoreSnapshot(snapshot: {
        memory: string[];
        user: string[];
    }): Promise<void>;
    detectDrift(target: MemoryTarget): Promise<boolean>;
}
//# sourceMappingURL=memory-store.d.ts.map