/**
 * Deterministic skill curator: active → stale → archived transitions.
 * Pure function; file moves are performed by SkillLibrary.
 */
import type { UsageMap } from './usage.ts';
export interface CuratorConfig {
    staleAfterDays: number;
    archiveAfterDays: number;
    pruneBuiltins: boolean;
    /** Shorter stale threshold for quality-warned skills; archive threshold never changes. */
    qualityWarnStaleAfterDays?: number;
    /** Explicit skill names never considered for lifecycle transitions. */
    excludeSkillNames?: ReadonlySet<string>;
    /** When true, usage records without created_by='agent' also enter the lifecycle. */
    manageUnmanaged?: boolean;
}
export interface CuratorTransition {
    name: string;
    from: 'active' | 'stale' | 'archived';
    to: 'stale' | 'archived' | 'active';
    reason: string;
}
export interface CuratorResult {
    transitions: CuratorTransition[];
    archive: string[];
    reactivate: string[];
    markStale: string[];
}
export declare const PROTECTED_BUILTIN_SKILLS: ReadonlySet<string>;
export interface CuratorArchivedSkill {
    name: string;
    path: string;
    reason: string;
}
export interface CuratorFailedSkill {
    name: string;
    reason: string;
}
export interface CuratorRunReport {
    runId: string;
    startedAt: string;
    finishedAt: string;
    staleCandidates: string[];
    llmNominations: string[];
    archiveCandidates: string[];
    archived: CuratorArchivedSkill[];
    failed: CuratorFailedSkill[];
    snapshotPath?: string;
}
export interface CuratorReportInput {
    runId: string;
    startedAt: string;
    finishedAt: string;
    staleCandidates: readonly string[];
    llmNominations: readonly string[];
    archiveCandidates: readonly string[];
    archived: readonly CuratorArchivedSkill[];
    failed: readonly CuratorFailedSkill[];
    snapshotPath?: string;
}
export declare function buildCuratorRunReport(input: CuratorReportInput): CuratorRunReport;
export declare function computeLifecycleTransitions(usage: UsageMap, config: CuratorConfig, now?: Date): CuratorResult;
//# sourceMappingURL=curator.d.ts.map