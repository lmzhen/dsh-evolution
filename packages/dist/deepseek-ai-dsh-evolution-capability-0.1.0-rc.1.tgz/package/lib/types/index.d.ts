/**
 * Explicit, non-automatic capability evolution adapter.
 *
 * The DSH Creator mode already owns the trusted dynamic-package lifecycle.
 * This adapter adds the missing governance seam WITHOUT executing model code:
 * a capability package is validated, then submitted through the same staged
 * approval audit used by memory/skills. Human approval records the pending
 * package; the actual `cordis_define`/`cordis_run` work stays in Creator mode.
 * @module @deepseek-ai/dsh-evolution-capability
 */
import { Context, Service } from '@deepseek-ai/cordis';
import type Schema from '@deepseek-ai/schemastery';
import type { PendingRecord, PendingStatus } from '@deepseek-ai/dsh-evolution-state-storage';
declare module '@deepseek-ai/cordis' {
    interface Context {
        evolutionCapability: EvolutionCapability;
    }
}
export declare const CAPABILITY_NAME_RE: RegExp;
export interface CapabilityPackage {
    name: string;
    purpose: string;
    code: {
        host?: string;
        client?: string;
    };
}
export interface CapabilityValidation {
    ok: boolean;
    errors: string[];
}
export interface CapabilitySubmitResult {
    ok: boolean;
    pendingId?: string | undefined;
    message: string;
}
export interface Config {
    maxNameLength?: number;
    maxPurposeLength?: number;
    maxCodeChars?: number;
}
export declare class EvolutionCapability extends Service {
    static inject: string[];
    static Config: Schema<Config>;
    private readonly limits;
    constructor(ctx: Context, config?: Config);
    validate(pkg: unknown): CapabilityValidation;
    /** Stage one capability package. Execution is deliberately out of scope. */
    submit(pkg: CapabilityPackage, origin?: 'foreground' | 'background_review'): Promise<CapabilitySubmitResult>;
    listPending(status?: PendingStatus): Promise<PendingRecord[]>;
    /** Retrieve an approved package for manual Creator-mode activation. */
    approvedPackage(id: string): Promise<CapabilityPackage | null>;
}
export interface CapabilityLimits {
    maxNameLength: number;
    maxPurposeLength: number;
    maxCodeChars: number;
}
export declare function validateCapabilityPackage(pkg: unknown, limits?: CapabilityLimits): CapabilityValidation;
export default EvolutionCapability;
//# sourceMappingURL=index.d.ts.map