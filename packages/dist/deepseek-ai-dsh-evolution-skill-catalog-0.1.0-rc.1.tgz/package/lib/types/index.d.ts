/**
 * Native `ctx.skills` provider for the evolution-managed skill tree.
 *
 * `tool-skill-manage` writes skills through `ctx.evolutionIo`; this provider
 * publishes the same tree into DSH's skill registry and invalidates its
 * catalog synchronously on `evolution/skill-mutated`, removing the
 * filesystem-watcher latency/window from the write → visible loop.
 * @module @deepseek-ai/dsh-evolution-skill-catalog
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "evolution-skill-catalog";
export declare const inject: string[];
export interface Config {
    root?: string;
    /** Whether catalog skills are advertised/loadable by the model. */
    modelInvocable?: boolean;
    /** Whether catalog skills are advertised/loadable from user surfaces. */
    userInvocable?: boolean;
    /** Restrict the published catalog to these skill names (empty = all). */
    includeSkillNames?: string[];
    /** Hide these skill names from the published catalog. */
    excludeSkillNames?: string[];
}
export declare const Config: z<Config>;
/** Below filesystem's user rank so the evolution-owned tree wins duplicates. */
export declare const EVOLUTION_SKILL_RANK = 390;
export declare function apply(ctx: Context, rawConfig?: Config): void;
//# sourceMappingURL=index.d.ts.map