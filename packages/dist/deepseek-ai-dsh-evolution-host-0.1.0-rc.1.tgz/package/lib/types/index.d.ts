/**
 * @deepseek-ai/dsh-evolution-host — composition package.
 * The package's substance is its YAML composition files declared through the
 * package manifest; this module carries no runtime API.
 * @module @deepseek-ai/dsh-evolution-host
 */
export {};
//# sourceMappingURL=index.d.ts.map