# @deepseek-ai/dsh-memory

Memory provider registry for self-evolution

## Model Experience

### Indirect model surface

#### What the model sees

`@deepseek-ai/dsh-memory` registers no direct prompt or tool schema itself. Model-visible effects are owned by the packages that consume this service.

#### Token effect

Zero direct token effect from this package; consumers add any model-visible tokens.

#### KV Cache effect

Independent of request-prefix construction. This package does not alter the assembled prompt or tool list.

## Known Limitations and Deferred Work


- No known durable consumer gaps at this time. Runtime contracts are covered by package and boundary tests.
