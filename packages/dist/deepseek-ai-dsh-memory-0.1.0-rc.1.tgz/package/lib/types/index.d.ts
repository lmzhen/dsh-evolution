/**
 * Memory provider registry for the evolution family.
 * Service Definition role; concrete providers register here.
 * @module @deepseek-ai/dsh-memory
 */
import { Context, Service } from '@deepseek-ai/cordis';
export type MemoryTarget = 'memory' | 'user';
export interface MemoryOperation {
    action: 'add' | 'replace' | 'remove';
    facts?: string | undefined;
    content?: string | undefined;
    old_text?: string | undefined;
}
export interface MemoryApplyResult {
    ok: boolean;
    message: string;
    entries: string[];
    chars: number;
    limit: number;
}
export interface MemorySnapshot {
    version: number;
    sha256: string;
    memory: string[];
    user: string[];
}
export interface MemoryProvider {
    readonly name: string;
    read(target: MemoryTarget, signal?: AbortSignal): Promise<string[]>;
    applyBatch(target: MemoryTarget, operations: MemoryOperation[], signal?: AbortSignal): Promise<MemoryApplyResult>;
    snapshot(signal?: AbortSignal): Promise<MemorySnapshot>;
    renderContext(): Promise<string>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        memory: MemoryRegistry;
    }
}
export declare class MemoryRegistry extends Service {
    private readonly providers;
    constructor(ctx: Context);
    registerProvider(provider: MemoryProvider): () => void;
    private provider;
    read(target: MemoryTarget, signal?: AbortSignal): Promise<string[]>;
    applyBatch(target: MemoryTarget, operations: MemoryOperation[], signal?: AbortSignal): Promise<MemoryApplyResult>;
    snapshot(signal?: AbortSignal): Promise<MemorySnapshot>;
    renderContext(): Promise<string>;
}
export default MemoryRegistry;
//# sourceMappingURL=index.d.ts.map