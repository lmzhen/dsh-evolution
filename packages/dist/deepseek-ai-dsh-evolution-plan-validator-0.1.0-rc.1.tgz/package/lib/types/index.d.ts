/**
 * Deterministic validator for model-produced evolution plans.
 * The validator never calls the model and never mutates state.
 * @module @deepseek-ai/dsh-evolution-plan-validator
 */
export interface MemoryOp {
    target?: string;
    action?: string;
    facts?: string;
    content?: string;
    old_text?: string;
    evidence?: unknown[];
}
export interface SkillOp {
    action?: string;
    name?: string;
    content?: string;
    old_string?: string;
    new_string?: string;
    file_path?: string;
    absorbed_into?: string;
    evidence?: unknown[];
}
export interface EvolutionPlan {
    memoryOps?: MemoryOp[];
    skillOps?: SkillOp[];
    summary?: string;
}
export interface ValidationContext {
    /** Upper bound for the latest valid session seq. */
    sessionSeq: number;
    maxOpsPerPlan?: number;
    protectedSkillNames?: ReadonlySet<string>;
    maxMemoryChars?: number;
    maxUserChars?: number;
    maxSkillContentChars?: number;
}
export interface RejectedOp {
    index: number;
    kind: 'memory' | 'skill';
    reason: string;
}
export interface ValidationResult {
    accepted: EvolutionPlan;
    rejected: RejectedOp[];
    ok: boolean;
}
export declare function validateEvolutionPlan(plan: EvolutionPlan, context: ValidationContext): ValidationResult;
//# sourceMappingURL=index.d.ts.map