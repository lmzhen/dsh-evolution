/**
 * Background review orchestration: signal gate → one-shot subagent → trusted plan execution.
 * @module @deepseek-ai/dsh-evolution-review
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "evolution-review";
export declare const inject: string[];
export interface Config {
    reviewEnabled?: boolean;
    reviewMode?: string;
    memoryInterval?: number;
    skillInterval?: number;
    /** Tools the one-shot review subagent may use. Defaults include the Anchored Standard discovery pair. */
    reviewToolAllow?: string[];
    reviewTimeoutMs?: number;
    executionTimeoutMs?: number;
    reviewContextMessages?: number;
    reviewMessageChars?: number;
    reviewMaxDepth?: number;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, rawConfig: Config): void;
//# sourceMappingURL=index.d.ts.map