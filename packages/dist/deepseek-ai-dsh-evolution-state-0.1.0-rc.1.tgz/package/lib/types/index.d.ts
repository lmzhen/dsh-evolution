/**
 * Durable evolution state consumer.
 *
 * The service owns no medium and performs no IO. It resolves the mounted
 * provider from `ctx.evolutionStateStorage` (see evolution-state-json and
 * evolution-state-domain); `provider` config may pin one by name.
 * @module @deepseek-ai/dsh-evolution-state
 */
import { Context, Service } from '@deepseek-ai/cordis';
import type Schema from '@deepseek-ai/schemastery';
import type { CuratorStateRecord, PendingRecord, PendingStatus, ReviewStateRecord } from '@deepseek-ai/dsh-evolution-state-storage';
export type { CuratorStateRecord, EvolutionStateStorage, PendingRecord, PendingStatus, ReviewStateRecord, } from '@deepseek-ai/dsh-evolution-state-storage';
export { curatorStateSchema, EVOLUTION_DOMAIN, pendingSchema, reviewStateSchema, } from '@deepseek-ai/dsh-evolution-state-domain';
declare module '@deepseek-ai/cordis' {
    interface Context {
        evolutionState: EvolutionState;
    }
}
export interface Config {
    /** Pin a provider by name; empty = first registered provider. */
    provider?: string;
}
export declare class EvolutionState extends Service {
    static inject: string[];
    static Config: Schema<Config>;
    private readonly providerName;
    constructor(ctx: Context, config?: Config);
    private storage;
    loadReviewState(sessionId: string): Promise<ReviewStateRecord | null>;
    saveReviewState(sessionId: string, record: ReviewStateRecord): Promise<void>;
    loadCuratorState(): Promise<CuratorStateRecord | null>;
    saveCuratorState(record: CuratorStateRecord): Promise<void>;
    listPending(status?: PendingStatus): Promise<PendingRecord[]>;
    savePending(record: PendingRecord): Promise<void>;
    deletePending(id: string): Promise<void>;
    tryResolvePending(id: string, status: 'approved' | 'rejected'): Promise<import("@deepseek-ai/dsh-evolution-state-storage").PendingResolution>;
}
export default EvolutionState;
//# sourceMappingURL=index.d.ts.map