/**
 * Provider seam for durable evolution state.
 *
 * The state CONSUMER (`@deepseek-ai/dsh-evolution-state`) never touches a
 * medium. Providers register here: `domain` (storage-domain KV) and `json`
 * (IO-seam files) are the two shipped providers.
 * @module @deepseek-ai/dsh-evolution-state-storage
 */
import { Context, Service } from '@deepseek-ai/cordis';
export type PendingKind = 'memory' | 'skill' | 'skill_batch' | 'capability';
export type PendingStatus = 'pending' | 'approved' | 'rejected';
export interface ReviewStateRecord {
    turnsSinceMemory: number;
    turnsSinceSkill: number;
    lastTurn: number;
}
export interface CuratorStateRecord {
    lastRunAt: number;
    runCount: number;
    lastSummary: string;
    paused: boolean;
}
export interface PendingRecord {
    id: string;
    kind: PendingKind;
    summary: string;
    args: unknown;
    createdAt: string;
    status: PendingStatus;
    resolvedAt?: string | undefined;
}
export interface PendingResolution {
    record: PendingRecord | null;
    applied: boolean;
}
export interface EvolutionStateStorage {
    readonly name: string;
    loadReviewState(sessionId: string): Promise<ReviewStateRecord | null>;
    saveReviewState(sessionId: string, record: ReviewStateRecord): Promise<void>;
    loadCuratorState(): Promise<CuratorStateRecord | null>;
    saveCuratorState(record: CuratorStateRecord): Promise<void>;
    listPending(status?: PendingStatus): Promise<PendingRecord[]>;
    savePending(record: PendingRecord): Promise<void>;
    deletePending(id: string): Promise<void>;
    /** Atomically transition a pending record exactly once. */
    tryResolvePending(id: string, status: Exclude<PendingStatus, 'pending'>): Promise<PendingResolution>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        evolutionStateStorage: EvolutionStateStorageRegistry;
    }
}
export declare class EvolutionStateStorageRegistry extends Service {
    private readonly providers;
    constructor(ctx: Context);
    registerProvider(provider: EvolutionStateStorage): () => void;
    provider(name?: string): EvolutionStateStorage;
}
export default EvolutionStateStorageRegistry;
//# sourceMappingURL=index.d.ts.map