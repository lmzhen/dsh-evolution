/**
 * @deepseek-ai/dsh-evolution-agent — composition package.
 * The package's substance is its YAML composition files declared through the
 * package manifest; this module carries no runtime API.
 * @module @deepseek-ai/dsh-evolution-agent
 */
export {};
//# sourceMappingURL=index.d.ts.map