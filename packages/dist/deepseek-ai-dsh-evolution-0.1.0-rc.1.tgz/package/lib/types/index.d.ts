/**
 * dsh-evolution — Hermes-style self-evolution plugin for DeepSeek Harness.
 *
 * Components:
 * - durable MEMORY.md / USER.md memory with a model-facing `memory` tool
 * - `skill_manage` write tool over $DSH_HOME/skills
 * - deterministic post-turn review signal gate
 * - background review via an optional one-shot subagent; falls back to an
 *   injected in-session nudge when no subagent provider is mounted
 * - `.usage.json` skill telemetry and deterministic curator transitions
 * - threat scanning on every agent-authored write
 *
 * @module @deepseek-ai/dsh-evolution
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "dsh-evolution";
/** Services required for the model-facing and review paths. */
export declare const inject: string[];
export interface Config {
    memoryEnabled?: boolean;
    skillManageEnabled?: boolean;
    reviewEnabled?: boolean;
    reviewMode?: string;
    memoryInterval?: number;
    skillInterval?: number;
    memoryCharLimit?: number;
    userCharLimit?: number;
    memoryAddDatePrefix?: boolean;
    curatorEnabled?: boolean;
    curatorStaleAfterDays?: number;
    curatorIntervalHours?: number;
    curatorArchiveAfterDays?: number;
    skillsRootOverride?: string;
    /** Tools the one-shot review subagent may use (Anchored Standard defaults). */
    reviewToolAllow?: string[];
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, rawConfig: Config): void;
//# sourceMappingURL=index.d.ts.map