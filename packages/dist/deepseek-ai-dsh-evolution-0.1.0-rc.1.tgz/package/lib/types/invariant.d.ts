/**
 * Package-owned invariant companion for `@deepseek-ai/dsh-evolution`.
 * @module @deepseek-ai/dsh-evolution/invariant
 */
import type { Context } from '@deepseek-ai/cordis';
/** Cordis companion plugin name. */
export declare const name = "dsh-evolution-invariant";
/** Service required before the companion can reserve package ownership. */
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map