/**
 * Model-facing skill_manage tool over ctx.evolutionIo + ctx.skillUsage.
 *
 * Mutations pass through the evolution approval seam when it is mounted;
 * approved/staged background writes are replayed by the registered runner.
 * The skill library itself never hard-deletes: archive is the maximum
 * destructive action and every curator mutation is snapshot-reversible.
 * @module @deepseek-ai/dsh-tool-skill-manage
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "tool-skill-manage";
export declare const inject: string[];
export interface Config {
    /** Skill tree root; empty uses $DSH_HOME/skills. Align with skill-usage/catalog rows. */
    root?: string;
    maxSkillNameLength?: number;
    maxDescriptionLength?: number;
    maxSkillContentChars?: number;
    maxSkillFileBytes?: number;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, rawConfig?: Config): void;
//# sourceMappingURL=index.d.ts.map