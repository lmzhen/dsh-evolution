/**
 * Model-facing memory tool and runtime-context memory snapshot.
 * @module @deepseek-ai/dsh-tool-memory
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "tool-memory";
export declare const inject: string[];
export interface Config {
    memoryEnabled?: boolean;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, rawConfig: Config): Promise<void>;
//# sourceMappingURL=index.d.ts.map