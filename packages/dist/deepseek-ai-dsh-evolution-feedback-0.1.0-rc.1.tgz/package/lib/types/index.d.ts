/**
 * Feedback-to-quality scoring for self-evolution.
 *
 * Feedback is durable through `ctx.evolutionIo` (when mounted) and skill
 * feedback feeds `quality_score` / `quality_warn` on the usage record, so
 * curator decisions can consume it deterministically.
 * @module @deepseek-ai/dsh-evolution-feedback
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
declare module '@deepseek-ai/cordis' {
    interface Context {
        evolutionFeedback: EvolutionFeedback;
    }
}
export interface FeedbackRecord {
    positive: number;
    negative: number;
    lastNote?: string | undefined;
}
export interface FeedbackState {
    skills: Record<string, FeedbackRecord>;
    sessions: Record<string, FeedbackRecord>;
}
interface IoLike {
    readText(path: string): Promise<string | null>;
    writeText(path: string, content: string): Promise<void>;
}
export declare class EvolutionFeedback {
    private state;
    private chain;
    private readonly path?;
    constructor(io?: IoLike, home?: string, pathOverride?: string);
    private mutate;
    restore(io: IoLike): Promise<void>;
    record(target: string, rating: 'positive' | 'negative', note?: string, kind?: 'skill' | 'session', io?: IoLike): void;
    score(target: string, kind?: 'skill' | 'session'): number;
    snapshot(): FeedbackState;
    flush(io?: IoLike): Promise<void>;
}
export declare const name = "evolution-feedback";
export interface Config {
    /** Score below which curator receives quality_warn for a skill. */
    qualityWarnThreshold?: number;
    /** Explicit feedback file path; empty derives $DSH_HOME/evolution/feedback.json. */
    path?: string;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, rawConfig?: Config): void;
export default EvolutionFeedback;
//# sourceMappingURL=index.d.ts.map