/**
 * Immutable evolution policy service.
 * The policy is the control plane. Model plans may not change it.
 * @module @deepseek-ai/dsh-evolution-policy
 */
import { Context, Service } from '@deepseek-ai/cordis';
import type Schema from '@deepseek-ai/schemastery';
declare module '@deepseek-ai/cordis' {
    interface Context {
        evolutionPolicy: EvolutionPolicy;
    }
}
export interface PolicySnapshot {
    version: 1;
    reviewMemoryInterval: number;
    reviewSkillInterval: number;
    substantiveMinToolCalls: number;
    substantiveMinUserChars: number;
    substantiveMinAgentChars: number;
    reviewMode: 'subagent' | 'inject';
    memoryReviewModel: string;
    skillReviewModel: string;
    curatorModel: string;
    memoryChars: number;
    userChars: number;
    skillContentChars: number;
    maxOpsPerPlan: number;
    curatorIntervalHours: number;
    staleAfterDays: number;
    archiveAfterDays: number;
    protectedSkillNames: readonly string[];
    protectedPaths: readonly string[];
    promptHashes: Readonly<Record<string, string>>;
    features: Readonly<Record<string, boolean>>;
}
export interface Config {
    reviewMemoryInterval?: number;
    reviewSkillInterval?: number;
    substantiveMinToolCalls?: number;
    substantiveMinUserChars?: number;
    substantiveMinAgentChars?: number;
    reviewMode?: string;
    memoryReviewModel?: string;
    skillReviewModel?: string;
    curatorModel?: string;
    memoryChars?: number;
    userChars?: number;
    skillContentChars?: number;
    maxOpsPerPlan?: number;
    curatorIntervalHours?: number;
    staleAfterDays?: number;
    archiveAfterDays?: number;
    protectedSkillNames?: string[];
    protectedPaths?: string[];
    promptHashes?: Record<string, string>;
    features?: Record<string, boolean>;
}
export declare const Config: Schema<Config>;
export declare class EvolutionPolicy extends Service {
    static Config: Schema<Config>;
    readonly snapshot: PolicySnapshot;
    constructor(ctx: Context, config?: Config);
    get(): PolicySnapshot;
    isProtectedPath(path: unknown): boolean;
    guardReason(toolName: string, args: unknown): string | undefined;
}
export default EvolutionPolicy;
//# sourceMappingURL=index.d.ts.map