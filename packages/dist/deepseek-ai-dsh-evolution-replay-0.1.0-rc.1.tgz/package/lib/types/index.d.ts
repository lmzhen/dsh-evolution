/**
 * Replay/A-B evaluation for evolution plans.
 *
 * The pure scoring functions remain deterministic and runtime-free. The DSH
 * driver records every `evolution/plan-applied` session event into an
 * in-memory leaderboard and exposes `/evolution replay` for comparison, so a
 * human can A/B review policy/prompt changes against real plan outcomes.
 * @module @deepseek-ai/dsh-evolution-replay
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export interface ReplayPlan {
    policyId: string;
    acceptedOps: number;
    rejectedOps: number;
    memoryOps: number;
    skillOps: number;
    evidenceQuotes: number;
    estimatedInputChars: number;
}
export interface ReplayResult {
    winner: string | null;
    margin: number;
    plans: ReplayPlan[];
    report: string;
}
export interface ReplayWeights {
    accepted: number;
    rejectedPenalty: number;
    evidence: number;
    cost: number;
}
export declare const DEFAULT_WEIGHTS: ReplayWeights;
export interface Config {
    maxPlans?: number;
    weights?: ReplayWeights;
}
export declare const Config: z<Config>;
export declare function scorePlan(plan: ReplayPlan, weights?: ReplayWeights): number;
export declare function comparePlans(plans: ReplayPlan[], weights?: ReplayWeights): ReplayResult;
declare module '@deepseek-ai/cordis' {
    interface Context {
        evolutionReplay: EvolutionReplayDriver;
    }
}
export declare class EvolutionReplayDriver {
    private readonly plans;
    private readonly maxPlans;
    private readonly weights;
    constructor(config?: Config);
    record(event: {
        type: string;
        data: {
            planId: string;
            policyFingerprint?: string | undefined;
            memoryApplied: number;
            skillApplied: number;
            rejectedOps: number;
        };
    }): void;
    plansSnapshot(): ReplayPlan[];
    compare(weights?: ReplayWeights): ReplayResult;
}
export declare const name = "evolution-replay";
export declare function apply(ctx: Context, rawConfig?: Config): void;
export default EvolutionReplayDriver;
//# sourceMappingURL=index.d.ts.map