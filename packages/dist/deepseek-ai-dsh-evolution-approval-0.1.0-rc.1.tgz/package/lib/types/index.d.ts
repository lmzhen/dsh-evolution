/**
 * Stage/pending write approval for self-evolution mutations.
 *
 * DSH's native approval seam is one-shot only. This service adds the
 * Hermes-style staged queue: background review/curator writes are stored in
 * `ctx.evolutionState`, and a human approves or rejects them later. A runner
 * registry replays the exact mutation without passing through the gate a
 * second time. Resolved records are KEPT as audit history.
 *
 * @module @deepseek-ai/dsh-evolution-approval
 */
import { Context, Service } from '@deepseek-ai/cordis';
import type Schema from '@deepseek-ai/schemastery';
import type { PendingKind, PendingRecord, PendingStatus } from '@deepseek-ai/dsh-evolution-state-storage';
export type { PendingKind, PendingRecord, PendingStatus };
export type WriteRunner = (args: unknown) => Promise<{
    ok: boolean;
    message: string;
}>;
export interface ApprovalRequest {
    kind: PendingKind;
    summary: string;
    args: unknown;
    origin: 'foreground' | 'background_review';
}
export interface ApprovalDecision {
    action: 'allow' | 'staged';
    pendingId?: string;
    message: string;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        evolutionApproval: EvolutionApproval;
    }
}
export interface Config {
    /** Master switch. Default false matches Hermes write_approval default. */
    enabled?: boolean;
    /** Require approval for foreground writes as well. */
    stageForeground?: boolean;
}
export declare class EvolutionApproval extends Service {
    static inject: string[];
    static Config: Schema<Config>;
    private readonly enabled;
    private readonly stageForeground;
    private readonly runners;
    private readonly inFlight;
    constructor(ctx: Context, config?: Config);
    private state;
    /** Fail-closed capability adapters need to distinguish "allowed" from "enabled". */
    get isEnabled(): boolean;
    registerRunner(kind: PendingKind, runner: WriteRunner): () => void;
    /** Trusted plan-executor entry point: replay a write through the registered runner exactly once. */
    run(kind: PendingKind, args: unknown): Promise<{
        ok: boolean;
        message: string;
    }>;
    /** Evaluate one mutation. Returns allow, or stores the write and returns staged. */
    request(input: ApprovalRequest): Promise<ApprovalDecision>;
    list(status?: PendingStatus): Promise<PendingRecord[]>;
    approve(id: string): Promise<{
        ok: boolean;
        message: string;
    }>;
    reject(id: string): Promise<{
        ok: boolean;
        message: string;
    }>;
    private dedupe;
    private doApprove;
}
export default EvolutionApproval;
//# sourceMappingURL=index.d.ts.map