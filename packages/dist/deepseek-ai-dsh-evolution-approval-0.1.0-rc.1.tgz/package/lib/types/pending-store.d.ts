export type PendingKind = 'memory' | 'skill' | 'skill_batch';
export interface PendingRecord {
    id: string;
    kind: PendingKind;
    summary: string;
    args: unknown;
    createdAt: string;
    status: 'pending' | 'approved' | 'rejected';
    resolvedAt?: string;
}
export declare class PendingStore {
    private records;
    private readonly path;
    constructor(env?: NodeJS.ProcessEnv);
    private loadSync;
    private save;
    list(status?: 'pending' | 'approved' | 'rejected'): PendingRecord[];
    stage(kind: PendingKind, summary: string, args: unknown): Promise<PendingRecord>;
    resolve(id: string, status: 'approved' | 'rejected'): Promise<PendingRecord | null>;
    remove(id: string): Promise<void>;
    clear(): Promise<void>;
}
//# sourceMappingURL=pending-store.d.ts.map