/**
 * IO seam for evolution providers.
 * @module @deepseek-ai/dsh-evolution-io
 */
import { Context, Service } from '@deepseek-ai/cordis';
export interface EvolutionIo {
    readonly name: string;
    readText(path: string, signal?: AbortSignal): Promise<string | null>;
    writeText(path: string, content: string, signal?: AbortSignal): Promise<void>;
    remove(path: string): Promise<void>;
    list(path: string): Promise<string[]>;
    exists(path: string): Promise<boolean>;
    rename(path: string, destination: string): Promise<void>;
    copy(path: string, destination: string): Promise<void>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        evolutionIo: EvolutionIoRegistry;
    }
}
export declare class EvolutionIoRegistry extends Service {
    private readonly providers;
    constructor(ctx: Context);
    registerProvider(provider: EvolutionIo): () => void;
    provider(name?: string): EvolutionIo;
}
export default EvolutionIoRegistry;
//# sourceMappingURL=index.d.ts.map